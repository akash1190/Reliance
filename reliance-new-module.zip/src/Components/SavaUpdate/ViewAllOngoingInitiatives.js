import React, { useState, useEffect } from 'react';
import {
    Grid, Breadcrumbs, Card, CardMedia, CardContent, Typography, Button, Dialog,
    DialogTitle, IconButton
} from '@mui/material'
import SideMenu from '../SideMenu/SideMenu';
import { Link } from 'react-router-dom';
import { useLocation, useNavigate } from "react-router-dom";
import SevaUpdates from './SevaUpdates';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { useDispatch, useSelector } from 'react-redux';
import { getEventsList } from '../../store/action/eventsList';
import NoImageFound from "../../asserts/images/noImageFound.jpg";
import Moment from 'moment';
import InitiativeDetails from './AllInitiativeReports/initiativeDetails';
import ShareIcon from "@mui/icons-material/Share";
import CloseIcon from "@mui/icons-material/Close";
import Share from "../ReusableComponents.js/Share";
import { getMpProfile } from '../../store/action/individualMP';
import { getIds } from '../ReusableComponents.js/getIds';

const ViewAllOngoingInitiatives = ({ user, newUser }) => {
    const location = useLocation();
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const viewAllValue = location?.state?.viewAllValue;
    const cardsData = location?.state?.data;
    const isEdit = location?.state?.isEdit;
    const MpClick = location?.state?.MpClick;
    const title = location?.state?.title;
    const mpName = location?.state?.mpName;
    const mpId = location?.state?.mpId;
    const [openInitiativeDetailsDialog, setOpenInitiativeDetailsDialog] = useState(false);
    const [personDetails, setPersonDetails] = useState();
    const [onViewClick, setOnViewClick] = useState();
    const [mediaShare, setMediaShare] = useState(false)
    const [shareData, setShareData] = useState({});
    const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);

    useEffect(() => {
        //call api to update store
        dispatch(getMpProfile(getIds()))
    }, [])


    const onFolderClick = () => {
        navigate('/SevaUpdates', {
            state: {
                user: newUser
            }
        });
    }
    const handleCloseInitiativeDetails = () => {
        setOpenInitiativeDetailsDialog(false);
    }

    const handleOpenInitiativeDetails = (item, title) => {
        setPersonDetails(item);
        setOnViewClick(title);
        setOpenInitiativeDetailsDialog(true);
    }

    const handleCardClick = (data) => {
        navigate("/SevaUpdates/allInitiativeReports", {
            state: {
                user: user,
                // initiativeDetails: initiativeDetails,
                initiativeId: data?.id,
                initiativeName: data?.initiativeName,
                mpName: mpName,
                mpId: mpId
            }
        })
    }

    const handleShare = (e, data) => {
        e.stopPropagation()
        e.preventDefault()
        setShareData(data)
        setMediaShare(true);
    };

    return (
        <div className="page-wrapper d-flex">
            {/* component 1 */}

            {newUser ? <SideMenu active="Seva" user={newUser} profileData={mpProfileData} /> :
                <SideMenu active="Seva" user={user} profileData={mpProfileData} />}

            <div className="main-wrapper" style={{ width: "100%" }}>

                <Grid container>

                    {/* <div className="row"> */}
                    <h1 className="page-title mb-0" style={{ fontSize: "28px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#356F92", marginLeft: "10px" }}>{viewAllValue}</h1>
                    <Grid container sx={{ mb: 2, mt: 2 }}>
                        <Breadcrumbs aria-label="breadcrumb" separator={<NavigateNextIcon fontSize="small" sx={{ marginLeft: "-15px" }} />}>
                            <Button underline="hover" style={{ fontFamily: 'HK Grotesk', color: "#505050", fontWeight: "600", fontSize: "18px", textTransform: "capitalize" }} onClick={onFolderClick}>
                                Nationwide Seva Updates
                            </Button>
                            <Button underline="hover" style={{ fontFamily: 'HK Grotesk', color: "#EC6E29", fontWeight: "600", fontSize: "18px", marginLeft: "-15px", textTransform: "capitalize" }}>
                                {viewAllValue}
                            </Button>
                        </Breadcrumbs>
                    </Grid>
                    <div className='itemfixed4'>

                        {/* <Grid item xs={8}> */}
                        {cardsData?.map((item, index) =>
                            <Card sx={{ minWidth: 200, mr: 3, mb: 3, borderRadius: "14px", position: "relative", cursor: "pointer" }} onClick={() => mpName ? handleOpenInitiativeDetails(item, title, true) : handleCardClick(item)}>
                                <CardMedia
                                    component="img"
                                    height="150"
                                    width="190"
                                    className='classmaxmin'
                                    onError={e =>
                                        e.target.src = NoImageFound}
                                    src={JSON.parse(item?.coverimage)[0]}
                                    // image={(item?.media && JSON.parse(item?.media)[0])}
                                    // image={NoImageFound}
                                    alt="new Image"
                                />
                              
                                <CardContent  >
                                    <Typography sx={{ fontSize: "16px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#505050" }} className="ellipsewehe12-qw ">
                                        <b>{item.eventTitle}</b>
                                    </Typography>
                                    <Typography sx={{ fontSize: "14px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#505050" }}>
                                        {item.name}
                                    </Typography>
                                    <Typography sx={{ fontSize: "12px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#505050" }} className="ellipsewehe12-qw ">
                                        {item?.initiativeName}
                                    </Typography>
                                </CardContent>
                                <ShareIcon className='shareicon-fix' key={index} onClick={(e) => {
                                    handleShare(e, item)
                                }} />
                            </Card>
                        )}
                    </div>
                    <div style={{ display: "none" }}>
                        <InitiativeDetails
                            handleCloseInitiativeDetails={handleCloseInitiativeDetails}
                            openInitiativeDetailsDialog={openInitiativeDetailsDialog}
                            details={personDetails}
                            onViewClickTitle={onViewClick}
                            isEdit={isEdit}
                            MpClick={MpClick}
                            mpName={mpName}
                        />
                    </div>
                    <Dialog open={mediaShare} onClose={() => setMediaShare(false)}>
                        <DialogTitle>
                            <IconButton
                                aria-label="close"
                                onClick={() => setMediaShare(false)}
                                sx={{
                                    position: "absolute",
                                    right: 8,
                                    top: 8,
                                    color: (theme) => theme.palette.grey[500],
                                    border: "1px solid #9e9e9e",
                                    borderRadius: "50%",
                                    padding: "2px",
                                    cursor: "pointer",
                                }}
                            >
                                <CloseIcon />
                            </IconButton>
                            <Typography
                                sx={{
                                    display: "flex",
                                    justifyContent: "center",
                                    color: "#357092",
                                    fontFamily: "HK Grotesk",
                                    fontSize: "26px",
                                    fontWeight: "bold",
                                }}
                            >
                                Share to Social Media
                            </Typography>
                            <div
                                style={{
                                    display: "flex",
                                    justifyContent: "center",
                                    marginTop: "25px",
                                    gap: "40px",
                                }}
                            >
                                <Share data={shareData} title={"Ongoing Seva Initiatives"} />

                            </div>
                            {/* <CloseIcon onClick={() => setAddMembers(false)} /> */}
                        </DialogTitle>
                    </Dialog>
                </Grid >
            </div >
        </div >
    )
}

export default ViewAllOngoingInitiatives;