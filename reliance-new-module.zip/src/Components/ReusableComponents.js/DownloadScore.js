import axios from "axios";
import Constant from "../../utils/constant";
import { getIds } from "./getIds";

const DownloadScore = async (value) => {
  const loggedInId = getIds();
  const tkn = localStorage.getItem("tokenDetails");
  const payload = {
    score: value.toString(),
  };
  console.log("loggedInID", loggedInId);
  console.log("value", value);
  try {
    await axios
      .post(
        Constant.BASE_URL + `/api/mp/creativeScore/${loggedInId}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${tkn}`,
          },
        }
      )
      .then((response) => {
        // return response;
        console.log("response", response);
      });
  } catch (error) {
    console.log("Error", error);
  }
};

export default DownloadScore;
