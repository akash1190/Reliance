import axios from "axios";
import Constant from "../../utils/constant";
import {
  FETCH_MOST_RETWEETED_TWEETS_FAILURE,
  FETCH_MOST_RETWEETED_TWEETS_REQUEST,
  FETCH_MOST_RETWEETED_TWEETS_SUCCESS,
} from "./types";

export const fetchMostRetweetedTweetsRequest = () => {
  return {
    type: FETCH_MOST_RETWEETED_TWEETS_REQUEST,
  };
};
export const fetchMostRetweetedTweetsSuccess = (value) => {
  return {
    type: FETCH_MOST_RETWEETED_TWEETS_SUCCESS,
    payload: value,
  };
};
export const fetchMostRetweetedTweetsFailure = (error) => {
  return {
    type: FETCH_MOST_RETWEETED_TWEETS_FAILURE,
    payload: error,
  };
};

export const getMostRetweetedTweets = () => async (dispatch) => {
  const tkn = localStorage.getItem("tokenDetails");
  dispatch(fetchMostRetweetedTweetsRequest);
  await axios
    .get(Constant.BASE_URL + "/api/mp/tweets/topMostRetweetedTweets", {
      headers: {
        Authorization: `Bearer ${tkn}`,
      },
    })
    .then((response) => {
      const result = response.data;
      dispatch(fetchMostRetweetedTweetsSuccess(result));
    })
    .catch((error) => {
      const errorMsg = error.message;
      dispatch(fetchMostRetweetedTweetsFailure(errorMsg));
    });
};
