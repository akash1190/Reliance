import React, { useEffect, useState } from 'react';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import CloseIcon from '@mui/icons-material/Close';
import { FormControl, Grid, IconButton, InputLabel, Select, MenuItem, TextField, Button, FormHelperText, DialogContent, DialogActions } from '@mui/material';
import { Box } from '@mui/system';
import AddIcon from '@mui/icons-material/Add';
// import { textTemplatesSchema } from "../../../utils/Validations";
import { useForm, useFieldArray } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import { Height } from '@mui/icons-material';
import imagedelete from "../../../asserts/images/bin.png";
const AddTextTemplates = ({ handleCloseTextTemplateDialog, openTextTemplateDialog, setText, languages, editTextTemplateDetails,
}) => {
    const [editDetails, setEditDetails] = useState(editTextTemplateDetails);
    useEffect(() => {
        setEditDetails(editTextTemplateDetails);
    }, [editTextTemplateDetails])

    const { register, control, handleSubmit, formState: { errors, isDirty } } = useForm({
        defaultValues: {
            test: editDetails && editDetails?.length > 0 ? editDetails : [{ text: "", hashtag: "", language: "" }]
        }
    });
    const {
        fields,
        append,
        remove,
    } = useFieldArray({
        control,
        name: "test"
    });

    function createData(id, language, text, hashtag) {
        return { id, language, text, hashtag };
    }

    const onAddTextTemplateSubmit = (data) => {
        const rows = data?.test?.map((value, i) => {
            // let language = languages?.find(val => val.language === value.language)
            return createData(i + 1, value.language, value.text, value.hashtag)
        })
        // setText([]);
        setText((prevData) => [rows]);
        // setText(rows)
        handleCloseTextTemplateDialog();
    }

    // const handleLanguage = (e, index) => {
    //     setLangValue(...langValue, [langValue[index] = e.target.value]);
    // }

    const handleKeyDown = e => {
        if (e.key === " ") {
            e.preventDefault();
        }
    };

    return (
        // handleCloseTextTemplateDialog(isDirty)}
        <Dialog onClose={() => handleCloseTextTemplateDialog(isDirty)} open={openTextTemplateDialog}  >
            <DialogTitle sx={{ fontFamily: 'HK Grotesk', color: "#2e739c", fontWeight: "700", textAlign: "center", fontSize: "26px" }}>{editDetails?.length > 0 ? "Update" : "Add"} Text Templates</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={() => handleCloseTextTemplateDialog(isDirty)}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                    border: "1px solid #9e9e9e",
                    borderRadius: "50%"
                }}
            >
                <CloseIcon />
            </IconButton>
            <DialogContent>
                <Box sx={{}}>
                    <form>
                        {fields.map((item, index) => {
                            return (
                                <div className="box" key={item.id}>
                                    <div className="textcenterinbox">

                                        <div style={{marginTop:"-24px"}}>

                                            <b style={{ fontFamily: 'HK Grotesk', color: "#356F92", fontSize: "16px", display: "flex", justifyContent: "start", marginLeft: "8px", marginBottom: "5px" }}>Language</b>

                                            <FormControl size="small" fullWidth sx={{ "& .MuiInputBase-input": { width: "180px", height: "25px!important" }, "& .MuiOutlinedInput-notchedOutline": { borderRadius: "14px", paddingRight: "-32px" }, "& .MuiOutlinedInput-input": { paddingRight: "14px!important" } }}>
                                                <TextField
                                                    name={`test[${index}].language`}
                                                    select
                                                    fullWidth
                                                    size='small'
                                                    autoComplete='off'
                                                    defaultValue={item?.language}
                                                    {...register(`test.${index}.language`, { required: "Please select language of the text" })}
                                                >
                                                    {languages &&
                                                        languages.map((s) => {
                                                            return (
                                                                <MenuItem
                                                                    // native
                                                                    key={s.id}
                                                                    sx={{ width: "100%" }}
                                                                    value={s.language}
                                                                    size="small"
                                                                >
                                                                    {s.language}
                                                                </MenuItem>
                                                            );
                                                        })}
                                                </TextField>
                                                <Grid container>
                                                    <Grid item xs={8}>
                                                        <FormHelperText sx={{ color: "#D93025", position: "absolute", top: "100%", fontWeight: "bold" }}>
                                                            {errors && errors?.test && errors?.test[index] && errors?.test[index].language?.message}
                                                        </FormHelperText>
                                                    </Grid>
                                                </Grid>
                                            </FormControl>

                                        </div>
                                        <div style={{ marginTop: "14px" }}>

                                            <b style={{ fontFamily: 'HK Grotesk', color: "#356F92", fontSize: "16px", display: "flex", justifyContent: "start", marginLeft: "8px", marginBottom: "5px" }}>Text</b>
                                            <FormControl sx={{ "& .MuiInputBase-input": { width: "180px", height: "25px" }, }}>
                                                <TextField
                                                    className="stepperFormInput"
                                                    // label="Text"
                                                    // name={"text" + i}
                                                    fullWidth
                                                    placeholder="Enter text"
                                                    size="small"
                                                    multiline
                                                    maxRows={1}
                                                    required
                                                    sx={{
                                                        '& .MuiOutlinedInput-root': {
                                                            '& fieldset': {
                                                                borderRadius: "14px",

                                                            },
                                                        },
                                                    }}
                                                    inputProps={{
                                                        maxLength: 280,
                                                        style: {
                                                            height: "40px",
                                                            width: "180px",
                                                        }
                                                    }}
                                                    // value={x.text}
                                                    // onChange={e => handleInputChange(e, i)}

                                                    {...register(`test.${index}.text`, { required: "Please enter the text" })}
                                                    autoComplete="off"
                                                // error={errors?.text}
                                                // helperText={`${errors}?.test.${index}.text.message`}
                                                />
                                                <Grid container>
                                                    <Grid item xs={8}>
                                                        <FormHelperText sx={{ color: "#D93025", position: "absolute", top: "100%", fontWeight: "bold" }}>
                                                            {errors && errors?.test && errors?.test[index] && errors?.test[index].text?.message}
                                                        </FormHelperText>
                                                    </Grid>
                                                    <Grid item xs={8}>
                                                        <span style={{ color: "grey", fontSize: "14px", marginLeft: "30" }}>(Max length 280)</span>
                                                    </Grid>

                                                </Grid>

                                            </FormControl>

                                        </div>
                                        <div>

                                            <b style={{ fontFamily: 'HK Grotesk', color: "#356F92", fontSize: "16px", display: "flex", justifyContent: "start", marginLeft: "8px", marginBottom: "5px" }}>Hashtag</b>
                                            <FormControl >
                                                <TextField
                                                    className="stepperFormInput"
                                                    // label="Hashtag"
                                                    // name={"hashtag" + i}
                                                    fullWidth
                                                    // value={x.hashtag}
                                                    // onChange={e => handleInputChange(e, i)}
                                                    // placeholder="Enter text"
                                                    sx={{
                                                        '& .MuiOutlinedInput-root': {
                                                            '& fieldset': {
                                                                borderRadius: "14px",
                                                                marginTop: "-0.6px"
                                                            },
                                                        },
                                                    }}
                                                    onKeyDown={handleKeyDown}
                                                    inputProps={{
                                                        maxLength: 1000,
                                                        style: {
                                                            height: "25px",
                                                            width: "180px",

                                                        }
                                                    }}
                                                    size="small"
                                                    required
                                                    {...register(`test.${index}.hashtag`, { required: "Please create a hashtag" })}
                                                    multiline
                                                    maxRows={1}
                                                    autoComplete="off"
                                                />
                                                <Grid container>
                                                    <Grid item xs={8}>
                                                        <FormHelperText sx={{ color: "#D93025", position: "absolute", top: "100%", fontWeight: "bold" }}>
                                                            {errors && errors?.test && errors?.test[index] && errors?.test[index].hashtag?.message}
                                                        </FormHelperText>
                                                    </Grid>
                                                    <Grid item xs={8}>
                                                        <span style={{ color: "grey", fontSize: "14px" }}>(Max length 1000)</span>
                                                    </Grid>

                                                </Grid>

                                            </FormControl>

                                        </div>
                                        <div>

                                            {fields.length !== 1 && <img src={imagedelete} onClick={() => remove(index)} className="deleteimgcss cursorshow" alt="delete" />}

                                            {/* Remove display:none to show button */}
                                        </div>

                                    </div>
                                    <div style={{ display: "none" }}>
                                        <Grid item xs={3}>

                                            {fields.length !== index && index !== 0 && <Button
                                                variant="outlined"
                                                sx={{ borderRadius: 4 }}
                                                className="button-primary-alt-contained"
                                                // startIcon={<DeleteOutlinedIcon  />}
                                                onClick={() => {
                                                    remove(index)
                                                }}
                                            >
                                                Remove
                                            </Button>}
                                        </Grid>
                                    </div>
                                    <div className="btn-box">
                                        <React.Fragment>
                                            <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 3.5 }}>
                                                {fields.length - 1 === index && <Button
                                                    variant="outlined"
                                                    sx={{ boxShadow: "none" }}
                                                    className="button-tr-citizen-admin mglefto addMore"
                                                    startIcon={<AddIcon sx={{ mt: "5px" }} />}
                                                    // onClick={handleAddClick}
                                                    onClick={() => {
                                                        append({ text: "", hashtag: "", language: "" });
                                                    }}
                                                >
                                                    Add More
                                                </Button>}
                                                <Box sx={{ flex: "1 1 auto" }} />
                                            </Box>
                                        </React.Fragment>
                                    </div>
                                    {/* <div style={{ marginTop: 20 }}>{JSON.stringify(inputList)}</div> */}
                                </div>
                            );
                        })}
                    </form>

                </Box >
            </DialogContent>
            <DialogActions sx={{ justifyContent: "center" }}>
                <React.Fragment>
                    <Box sx={{ display: "flex", flexDirection: "row", justifyContent: "center", mb: 2, mt: 2, }}>
                        <Button
                            variant="contained"

                            sx={{
                                p: 1, mr: 1, backgroundColor: "#ef7335", borderRadius: 4, position: "relative",
                                width:"250px"
                            }}
                            className="button-tr-2 mgtopo"
                            onClick={handleSubmit(onAddTextTemplateSubmit)}
                        >
                           {editDetails?.length > 0 ?"Update Text Template": "Add Text Template"}
                        </Button>
                        <Box sx={{ flex: "1 1 auto" }} />
                    </Box>
                </React.Fragment>
            </DialogActions>
        </Dialog >
    );
}

export default AddTextTemplates;
