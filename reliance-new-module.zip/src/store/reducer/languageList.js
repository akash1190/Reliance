import { FETCH_LANGUAGE_LIST_REQUEST, FETCH_LANGUAGE_LIST_SUCCESS, FETCH_LANGUAGE_LIST_FAILURE } from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const LanguageListReducer = (state = initialState, action) => {
    switch (action.type) {
        case FETCH_LANGUAGE_LIST_REQUEST:
            return {
                ...state,
            }
        case FETCH_LANGUAGE_LIST_SUCCESS:
            return {
                data: action.payload
            }
        case FETCH_LANGUAGE_LIST_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}