import axios from "axios"
import Constant from "../../utils/constant"
import { FETCH_RANKS_COUNT_FAILURE, FETCH_RANKS_COUNT_REQUEST, FETCH_RANKS_COUNT_SUCCESS } from "./types"

export const fetchRanksCountRequest = () => {
    return {
        type: FETCH_RANKS_COUNT_REQUEST
    }
}
export const fetchRanksCountSuccess = data => {
    return {
        type: FETCH_RANKS_COUNT_SUCCESS,
        payload: data
    }
}
export const fetchRanksCountFailure = error => {
    return {
        type: FETCH_RANKS_COUNT_FAILURE,
        payload: error
    }
}

export const getRanksCount = (mpId) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchRanksCountRequest)
    await axios.get(Constant.BASE_URL + `/api/ranks/${mpId? mpId:0}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data
            dispatch(fetchRanksCountSuccess(result));
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchRanksCountFailure(errorMsg));
        })
}


