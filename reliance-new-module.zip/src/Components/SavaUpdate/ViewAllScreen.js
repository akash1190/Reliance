import React, { useState, useEffect } from 'react';
import {
    Grid, Breadcrumbs, Card, CardMedia, CardContent, Typography, Button, Divider,
    Dialog, DialogTitle, IconButton
} from '@mui/material'
import SideMenu from '../SideMenu/SideMenu';
import { Link } from 'react-router-dom';
import { useLocation, useNavigate } from "react-router-dom";
import SevaUpdates from './SevaUpdates';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { useDispatch, useSelector } from 'react-redux';
import { getEventsList } from '../../store/action/eventsList';
import NoImageFound from "../../asserts/images/noImageFound.jpg";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import Moment from 'moment';
import InitiativeDetails from './AllInitiativeReports/initiativeDetails';
import ShareIcon from "@mui/icons-material/Share";
import CloseIcon from "@mui/icons-material/Close";
import Share from "../ReusableComponents.js/Share";
import { getMpProfile } from '../../store/action/individualMP';
import { getIds } from '../ReusableComponents.js/getIds';

const ViewAllScreen = ({ user, newUser }) => {
    const location = useLocation();
    const navigate = useNavigate();
    const viewAllValue = location?.state?.viewAllValue;
    const cardsData = location?.state?.data;
    const isEdit = location?.state?.isEdit;
    const MpClick = location?.state?.MpClick;
    const title = location?.state?.title;
    const mpName = location?.state?.mpName;
    const dispatch = useDispatch();
    console.log("cardsData", cardsData, title)
    const [openInitiativeDetailsDialog, setOpenInitiativeDetailsDialog] = useState(false);
    const [personDetails, setPersonDetails] = useState();
    const [onViewClick, setOnViewClick] = useState();
    const [mediaShare, setMediaShare] = useState(false)
    const [shareData, setShareData] = useState({});
    const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
    // const dispatch = useDispatch();
    // const eventsList = useSelector((state) => state?.eventsList?.data);
    const onFolderClick = () => {
        navigate('/SevaUpdates', {
            state: {
                user: newUser
            }
        });
    }

    useEffect(() => {
        //call api to update store
        dispatch(getMpProfile(getIds()))
    }, [])

    const handleCloseInitiativeDetails = () => {
        setOpenInitiativeDetailsDialog(false);
    }

    const handleOpenInitiativeDetails = (item, title) => {
        setPersonDetails(item);
        setOnViewClick(title);
        setOpenInitiativeDetailsDialog(true);
    }

    const handleShare = (e, data) => {
        e.stopPropagation()
        e.preventDefault()
        setShareData(data)
        setMediaShare(true);
    };

    return (
        <div className="page-wrapper d-flex">
            {/* component 1 */}

            {newUser ? <SideMenu active="Seva" user={newUser} profileData={mpProfileData} /> :
                <SideMenu active="Seva" user={user} profileData={mpProfileData} />}

            <div className="main-wrapper" style={{ width: "100%" }}>

                <Grid container>

                    {/* <div className="row"> */}
                    <h1 className="page-title mb-0" style={{ fontSize: "28px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#356F92", marginLeft: "10px" }}>{viewAllValue}</h1>
                    <Grid container sx={{ mb: 2, mt: 2 }}>
                        <Breadcrumbs aria-label="breadcrumb" separator={<NavigateNextIcon fontSize="small" sx={{ marginLeft: "-15px" }} />}>
                            <Button underline="hover" style={{ fontFamily: 'HK Grotesk', color: "#505050", fontWeight: "600", fontSize: "18px", textTransform: "capitalize" }} onClick={onFolderClick}>
                                Nationwide Seva Updates
                            </Button>
                            <Button underline="hover" style={{ fontFamily: 'HK Grotesk', color: "#EC6E29", fontWeight: "600", fontSize: "18px", marginLeft: "-15px", textTransform: "capitalize", cursor: "auto" }}>
                                {viewAllValue}
                            </Button>
                        </Breadcrumbs>
                    </Grid>
                    <div className='itemfixed4 cursorshow'>

                        {/* <Grid item xs={8}> */}
                        {cardsData?.map((item, index) =>
                            <Card sx={{ minWidth: 200, mr: 3, mb: 3, borderRadius: "14px" }} onClick={() => handleOpenInitiativeDetails(item, title)}>

                                <CardMedia
                                    className='image2acrd'
                                    component="img"
                                    height="150"
                                    width="190"
                                    onError={e =>
                                        e.target.src = NoImageFound}
                                    src={title === "Seva aur Samarpan Campaign" ? item?.coverimage && JSON.parse(item?.coverimage)[0] :
                                        item?.media && JSON.parse(item?.media)[0]
                                    }
                                    // image={(item?.media && JSON.parse(item?.media)[0])}
                                    // image={NoImageFound}
                                    alt="new Image"
                                />
                                <ShareIcon className='shareicone2' key={index} onClick={(e) => {
                                    handleShare(e, item)
                                }} />
                                <CardContent sx={{ minHeight: "150px", maxHeight: "150px" }} >
                                    <div style={{ marginTop: "-35px" }}>
                                        <Typography sx={{ fontSize: "16px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#505050" }} className="ellipsewehe12-qw ">
                                            <b>{viewAllValue === "Seva Events" ? item.eventTitle : (viewAllValue === "OP-ed's, Books & Media Coverage" ? item?.title : item?.projecttitle)}</b>
                                        </Typography>
                                        <Typography sx={{ fontSize: "14px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#505050" }}>
                                            {viewAllValue === "OP-ed's, Books & Media Coverage" ? item?.type : (viewAllValue !== "Seva Events" ? item?.status : item?.location)}
                                        </Typography>
                                        <Typography sx={{ fontSize: "12px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#505050" }}>
                                            Date- {item.endDate ? Moment(item.endDate).format('DD/MM/YYYY') : Moment(item?.createdAt).format('DD/MM/YYYY')}
                                        </Typography>
                                        <Divider sx={{ padding: "5px" }} />
                                        <div style={{ display: "flex", marginTop: "10px" }}>
                                            <div>
                                                {item?.user?.user_avatar ? (<img
                                                    key={index}
                                                    src={item?.user?.user_avatar}
                                                    className="img-circle leader-circle-img mr-1 circularimage2"
                                                    width="40"
                                                    style={{ marginTop: "3px" }}
                                                // style={{ position: 'absol}}
                                                />): (
                                                    <div className="text-center">
                                                      <AccountCircleIcon
                                                        sx={{
                                                          fontSize: "xx-large",
                                                          width: "50px",
                                                          height: "auto",
                                                          border:0
                                                         
                                                          
                                                        }}                                               
                                                      />
                                                    </div>
)}
                                            </div>
                                            <div style={{ paddingLeft: "10px" }}>
                                                <Typography sx={{ fontSize: "14px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#356F92" }}>

                                                    {item.user?.user_name}
                                                </Typography>
                                                <Typography sx={{ fontSize: "12px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#797979" }}>
                                                    {item.user?.designation}
                                                </Typography>
                                                <Typography sx={{ fontSize: "12px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#797979" }}>
                                                    {item.user?.constituency_name} - {item.user?.state_name}
                                                </Typography>
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>


                            </Card>

                        )}
                        {/* {eventsList?.map((item, index) =>
                            <Card sx={{ minWidth: 200, mr: 3, mb: 3 }}>
                                <CardMedia
                                    component="img"
                                    height="150"
                                    width="190"
                                    image={item.media}
                                    alt="new Image"
                                />
                                <CardContent >
                                    <Typography variant="body2" color="text.secondary">
                                        <b>{item.eventTitle}</b>
                                    </Typography>
                                    <Typography color="text.secondary">
                                        {item.name}
                                    </Typography>
                                    <Typography color="text.secondary">
                                        {item.startDate}
                                    </Typography>
                                    <Divider />
                                    <Typography color="text.secondary">
                                        <img
                                            key={index}
                                            src={item.image}
                                            className="img-circle leader-circle-img mr-1"
                                            width="25"
                                        // style={{ position: 'absol}}
                                        />
                                        {item.personName}
                                    </Typography>
                                    <Typography color="text.secondary">
                                        {item.designation}
                                    </Typography>
                                    <Typography color="text.secondary">
                                        {item.location}
                                    </Typography>
                                </CardContent>
                            </Card>
                        )} */}
                        {/* </Grid> */}

                    </div>
                    <div style={{ display: "none" }}>
                        <InitiativeDetails
                            handleCloseInitiativeDetails={handleCloseInitiativeDetails}
                            openInitiativeDetailsDialog={openInitiativeDetailsDialog}
                            details={personDetails}
                            onViewClickTitle={onViewClick}
                            isEdit={isEdit}
                            MpClick={MpClick}
                            mpName={mpName}
                            mpProfileData={mpProfileData}
                            viewAllCheck={true}
                            user={user}
                        />

                    </div>
                    <Dialog open={mediaShare} onClose={() => setMediaShare(false)}>
                        <DialogTitle>
                            <IconButton
                                aria-label="close"
                                onClick={() => setMediaShare(false)}
                                sx={{
                                    position: "absolute",
                                    right: 8,
                                    top: 8,
                                    color: (theme) => theme.palette.grey[500],
                                    border: "1px solid #9e9e9e",
                                    borderRadius: "50%",
                                    padding: "2px",
                                    cursor: "pointer",
                                }}
                            >
                                <CloseIcon />
                            </IconButton>
                            <Typography
                                sx={{
                                    display: "flex",
                                    justifyContent: "center",
                                    color: "#357092",
                                    fontFamily: "HK Grotesk",
                                    fontSize: "26px",
                                    fontWeight: "bold",
                                }}
                            >
                                Share to Social Media
                            </Typography>

                            <div
                                style={{
                                    display: "flex",
                                    justifyContent: "center",
                                    marginTop: "25px",
                                    gap: "40px",
                                }}
                            >
                                <Share data={shareData} title={title} />

                            </div>
                            {/* <CloseIcon onClick={() => setAddMembers(false)} /> */}
                        </DialogTitle>
                    </Dialog>
                </Grid >
            </div >
        </div >
    )
}

export default ViewAllScreen;