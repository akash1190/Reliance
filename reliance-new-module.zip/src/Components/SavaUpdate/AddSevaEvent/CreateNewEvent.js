import React, { useState, useRef, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import AddIcon from "@mui/icons-material/Add";
import DialogActions from "@mui/material/DialogActions";
import closeIconp from "../../../asserts/images/close.png";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import {
  Select,
  MenuItem,
  Button,
  TextField,
  Grid,
  Box,
  FormControl,
  InputLabel,
  Card,
  CardContent,
  Paper,
  IconButton,
  FormHelperText,
  Typography,
  DialogContent,
} from "@mui/material";
import { useForm } from "react-hook-form";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import UploadIcon from "@mui/icons-material/Upload";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { useDispatch, useSelector } from "react-redux";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import CloseIcon from "@mui/icons-material/Close";
import { postCreateEvent } from "../../../store/action/createNewEvent";
import Moment from "moment";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";
import Constant from "../../../utils/constant";
import {
  getEventsListByMpId,
  getEventsList,
} from "../../../store/action/eventsList";
import AccessTimeFilledIcon from "@mui/icons-material/AccessTimeFilled";
import { getIntiativesReportByIdList } from "../../../store/action/ongoingSevaInitiativesList";
import imagedelete from "../../../asserts/images/bin-1.png";
import DeleteIndividualEventDialog from "./DeleteIndividualEventDialog";
import { getIds } from "../../ReusableComponents.js/getIds";
import { validateNotEmpty } from "../../ReusableComponents.js/reuseMethods";

const CreateNewEvent = ({
  handleCloseCreateEvent,
  openCreateEventDialog,
  isSevaEventEdit,
  details,
  handleCloseInitiativeDetails,
  mpId,
  initiativeId,
  initiativeName,
  eventByMpId,
  editEventDetails,
  handleCloseEventDetailsDialog,
}) => {
  const { setLoading } = useLoading();
  const { showNotification } = useNotificationContext();
  const [images, setImages] = useState([]);
  const [files, setFiles] = useState([]);
  const [value, setValue] = useState(0);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);
  const [coverImage, setCoverImage] = useState(null);
  const [coverImageName, setCoverImageName] = useState("");
  const [image, setImage] = useState(null);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [deleteClick, setDeleteClick] = useState(false);
  const [checkCoverImage, setCheckCoverImage] = useState(false);
  const [checkUpdateChanges, setCheckUpdateChanges] = useState(true);
  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  const {
    register,
    handleSubmit,
    formState: { errors },
    resetField,
    reset,
  } = useForm();
  const hiddenFileInput = useRef(null);
  const hiddenCoverImageInput = useRef(null);
  const dispatch = useDispatch();
  const fileFormats = ["image/png", "image/jpeg", "image/jpg"];
  const loggedInId = getIds();
  // const handleChange = (event, newValue) => {
  //     setValue(newValue);
  // };
  useEffect(() => {
    if (details) {
      setCoverImage(details?.coverimage && JSON.parse(details?.coverimage));
      if (details?.media !== null) {
        setImages(details?.media && JSON.parse(details?.media));
      }
    }
  }, [details]);

  useEffect(() => {
    if (deleteClick) {
      handleCloseCreateEvent(
        reset,
        setImages,
        setFiles,
        setStartDate,
        setEndDate,
        setStartTime,
        setEndTime
      );
    }
  }, [deleteClick]);
  useEffect(() => {
    if (details) {
      setStartDate(details?.startDate);
      setEndDate(details?.endDate);
      setStartTime(details && details?.statTime);
      setEndTime(details && details?.endTime);
    }
  }, []);

  const addImagesToFormData = async (formData, images) => {
    for (let i = 0; i < images.length; i++) {
      const response = await fetch(images[i].src);
      const blob = await response.blob();
      const file = new File([blob], `image${i}.jpg`, { type: "image/*" });
      formData.append(`media`, file, file.name);
    }
  };

  const addCoverImageToFormData = async (formData, coverImage) => {
    const response = await fetch(coverImage);
    const blob = await response.blob();
    const file = new File([blob], `image.jpg`, { type: blob.type });
    formData.append(`coverimage`, file, file.name);
  };

  const onAddSevaEvent = async (data) => {
    // if (isSevaEventEdit && images.length === 0) {
    //   showNotification("Error", "Please add event images");
    //   return;
    // }
    if (!coverImageName && !coverImage) return;
    setLoading(true);
    const tkn = localStorage.getItem("tokenDetails");
    const sTime = startTime;
    const st = new Date(sTime);
    const eTime = endTime;
    const et = new Date(eTime);
    const imgList = document.querySelectorAll(".imageupload");
    const formData = new FormData();

    formData.append("eventTitle", data?.eventTitle);
    formData.append("location", data?.location);
    formData.append("startDate", Moment(startDate).format("YYYY-MM-DD"));
    endDate && formData.append("endDate", Moment(endDate).format("YYYY-MM-DD"));
    formData.append(
      "startTime",
      isSevaEventEdit ? startTime : st.toISOString()
    );
    endTime && formData.append("endTime", isSevaEventEdit ? endTime : et.toISOString());
    formData.append("mpmodelId", loggedInId);
    formData.append("desc", data?.desc);
    formData.append("initiativeId", initiativeId ? initiativeId : 0);
    !isSevaEventEdit && formData.append("coverimage", image, coverImageName);
    isSevaEventEdit && (await addImagesToFormData(formData, imgList));
    isSevaEventEdit && (await addCoverImageToFormData(formData, coverImage));
    // Array.from(files).forEach((file) => {
    //   console.log("imglis", file);
    //   formData.append(`media`, file, file.name);
    // });

    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${tkn}`,
      },
    };

    const id = details?.id ? details?.id : 0;

    try {
      // setLoading(true);
      // if (!isSevaEventEdit && files.length === 0)
      const response = await dispatch(postCreateEvent(id, formData, config));
      if (response.status === 200 || response.status === 201) {
        showNotification("Success", response.data.message, "success");
        handleCloseCreateEvent(
          reset,
          setImages,
          setFiles,
          setStartDate,
          setEndDate,
          setStartTime,
          setEndTime
        );
        if (details) {
          handleCloseInitiativeDetails && handleCloseInitiativeDetails();
        }
        if (editEventDetails) {
          handleCloseEventDetailsDialog();
          dispatch(getIntiativesReportByIdList(initiativeId));
        }
        if (eventByMpId) {
          dispatch(getEventsListByMpId(mpId));
        } else {
          dispatch(getEventsList(0));
        }
        Object.keys(data).map((val) => resetField(val));
        setImages([]);
        setFiles([]);
      }
    } catch (error) {
      showNotification("Error", "Failed to send data");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (index) => {
    hiddenFileInput.current.value = "";
    const tempImages = [...images];
    tempImages.splice(index, 1);
    setImages(tempImages);
    const tempFiles = [...files];
    tempFiles.splice(index, 1);
    setFiles(tempFiles);
    setCheckUpdateChanges(false);
  };

  const handleImageChange = (e) => {
    const uploadedFiles = e.target.files;
    setFiles([...files, ...uploadedFiles]);
    let newImages = [];
    for (let i = 0; i < uploadedFiles.length; i++) {
      const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
        newImages.push({ url: reader.result, file: uploadedFiles[i] });
        if (i === uploadedFiles.length - 1) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          setCheckUpdateChanges(false);
          setImages([...newImages, ...images]);
        }
      };
    }
  };


  const handleCoverImageChange = (event) => {
    const type = event.target.files[0].type;
    const isRightFormat = fileFormats.includes(type);
    if (!isRightFormat) {
      showNotification(
        "Error",
        "You can only upload jpg, jpeg and png image",
        "error"
      );
      return;
    }
    const files = event.target.files[0];
    setImage(event.target.files[0]);
    setCheckUpdateChanges(false);
    setCoverImage(URL.createObjectURL(files));
    setCoverImageName(event.target.files[0].name);
  };

  const handleDeleteCoverImage = () => {
    setImage(null);
    setCoverImage("");
    setCoverImageName(null);
    setCheckUpdateChanges(false);
  };
  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };

  const handleCoverImageClick = (event) => {
    hiddenCoverImageInput.current.click();
  };

  const dateConvert = (dateStr) => {
    const date = new Date(dateStr);
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let year = date.getFullYear();
    const formattedDate = `${month < 10 ? "0" + month : month}/${day < 10 ? "0" + day : day
      }/${year}`;
    return formattedDate;
  };

  const handleClickOpenDeleteDialog = () => {
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => setOpenDeleteDialog(false);

  return (
    <>
      <Dialog
        open={openCreateEventDialog}
        onClose={() =>
          handleCloseCreateEvent(
            reset,
            setImages,
            setFiles,
            setStartDate,
            setEndDate,
            setStartTime,
            setEndTime
          )
        }
        className="card-modal-height"
        sx={{ mt: 2 }}
      >
        <DialogTitle>
          <Box
            sx={{
              display: "flex",
              justifyContent: "flex-start",
              color: "#357092",
              ml: "25px",
            }}
          >
            <div
              style={{
                fontFamily: "HK Grotesk",
                color: "#2C2C2C",
                fontSize: "26px",
                fontWeight: "bold",
              }}
            >
              {initiativeName ? (
                <>
                  <b
                    style={{
                      fontFamily: "HK Grotesk",
                      color: "#2C2C2C",
                      fontSize: "22px",
                      fontWeight: "bold",
                    }}
                  >
                    {isSevaEventEdit ? "Edit" : "Create"} an Event for
                  </b>
                  <br />
                  <b
                    style={{
                      fontFamily: "HK Grotesk",
                      color: "#357092",
                      fontSize: "26px",
                      fontWeight: "bold",
                    }}
                    className="ellipsewehe12 "
                  >
                    {initiativeName}
                  </b>
                </>
              ) : (
                <b>
                  {isSevaEventEdit || editEventDetails ? "Edit" : "Create"} an
                  Event
                </b>
              )}
            </div>
            <CloseIcon
              className="pageHeader"
              onClick={() =>
                handleCloseCreateEvent(
                  reset,
                  setImages,
                  setFiles,
                  setStartDate,
                  setEndDate,
                  setStartTime,
                  setEndTime
                )
              }
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
                border: "1px solid #9e9e9e",
                borderRadius: "50%",
                padding: "2px",
                cursor: "pointer",
              }}
            />
          </Box>
        </DialogTitle>
        <DialogContent>
          <Grid container className="bg-white">
            <Grid item xs={12} md={12}>
              <Grid item xs={12} md={12} sx={{ p: 4 }}>
                <Box>
                  <form>
                    <Grid
                      container
                      spacing={1}
                      justifyContent="left"
                      alignItems="center"
                    >
                      <Grid container sx={{ mb: 2 }}>
                        <Grid item xs={12} sx={{ pr: 1 }}>
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b>Event Title*</b>
                          </div>
                          <FormControl
                            fullWidth
                            sx={{
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderRadius: "14px",
                              },
                            }}
                          >
                            <TextField
                              className="stepperFormInput"
                              // label="Event Title"
                              name="eventTitle"
                              fullWidth
                              placeholder="Enter title"
                              size="small"
                              required
                              maxLength={2}
                              defaultValue={details && details?.eventTitle}
                              autoComplete="off"
                              inputProps={{
                                maxLength: 300,
                              }}
                              {...register("eventTitle", {
                                required: "Please enter title",
                                maxLength: {
                                  value: 300,
                                  message: "Maximum character length is 300",
                                },
                                validate: (value) =>
                                  validateNotEmpty(value, "event title"),
                              })}
                              //   error={Boolean(errors?.employeeId?.message)}
                              //   helperText={errors?.employeeId?.message}
                              onChange={() => setCheckUpdateChanges(false)}
                            />
                          </FormControl>
                          <FormHelperText sx={{ color: "#d32f2f" }}>
                            {errors && errors?.eventTitle?.message}
                          </FormHelperText>
                        </Grid>
                      </Grid>
                      <Grid container sx={{ mb: 2 }}>
                        <Grid item xs={12} sx={{ pr: 1 }}>
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b>Location*</b>
                          </div>
                          <FormControl
                            fullWidth
                            sx={{
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderRadius: "14px",
                              },
                            }}
                          >
                            <TextField
                              className="stepperFormInput"
                              // label="Location"
                              name="location"
                              fullWidth
                              placeholder="Enter location"
                              size="small"
                              required
                              defaultValue={details && details?.location}
                              autoComplete="off"
                              inputProps={{
                                maxLength: 100,
                              }}
                              {...register("location", {
                                required: "Please enter a valid address",
                                maxLength: {
                                  value: 100,
                                  message: "Maximum character length is 100",
                                },
                                minLength: {
                                  value: 5,
                                  message: "Location should contain at-least 5 characters"
                                },
                                pattern: {
                                  value: /^[A-Z][a-zA-Z0-9.,$\n\r\s]+$/,
                                  message: "First character should be alphabet in upper-case"
                                },
                                validate: (value) =>
                                  validateNotEmpty(value, "location"),
                              })}
                              onChange={() => setCheckUpdateChanges(false)}
                            //   error={Boolean(errors?.employeeId?.message)}
                            //   helperText={errors?.employeeId?.message}
                            />
                          </FormControl>
                          <FormHelperText sx={{ color: "#d32f2f" }}>
                            {errors && errors?.location?.message}
                          </FormHelperText>
                        </Grid>
                      </Grid>
                      {/* <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}> */}
                      {/* <FormControl fullWidth>
                                                    <InputLabel
                                                        id="demo-simple-select-label"
                                                        sx={{ marginTop: "-6px" }}
                                                    >
                                                        Location
                                                    </InputLabel> */}
                      {/* <Select
                                                        className="stepperFormInput"
                                                        label="Location"
                                                        name="location"
                                                        fullWidth
                                                        placeholder="Enter location"
                                                        defaultValue={details?.location}
                                                        required
                                                        size="small"
                                                        autoComplete="off"
                                                        {...register("location", { required: true })} */}
                      {/* // error={errors?.roleId}
                                                    // helperText={errors?.roleId?.message}
                                                    // onChange={() => setIsUpdateButton(false)}
                                                    // > */}
                      {/* {types &&
                                                            types.map((s) => {
                                                                return (
                                                                    <MenuItem
                                                                        native
                                                                        key={s.id}
                                                                        sx={{ width: "100%" }}
                                                                        value={s.id}
                                                                        size="small"
                                                                    >
                                                                        {s.value}
                                                                    </MenuItem>
                                                                );
                                                            })}
                                                    </Select> */}
                      {/* <FormHelperText sx={{ color: "#d32f2f" }}>
                                                        {errors && errors?.roleId?.message}
                                                    </FormHelperText> */}
                      {/* </FormControl>
                                            </Grid>
                                        </Grid> */}
                      <Grid container sx={{ mb: 2 }}>
                        <Grid item xs={6} sx={{ pr: 1 }}>
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b>Start Date*</b>
                          </div>
                          <LocalizationProvider
                            dateAdapter={AdapterDayjs}
                            sx={{
                              "& .MuiInputBase-input": {
                                width: "180px",
                                height: "25px!important",
                              },
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderRadius: "14px",
                                paddingRight: "-32px",
                              },
                              "& .MuiOutlinedInput-input": {
                                borderRadius: "14px",
                                paddingRight: "14px!important",
                              },
                            }}
                          >
                            <DatePicker
                              inputFormat="DD-MM-YYYY"
                              // label="Start Date"
                              components={{
                                OpenPickerIcon: CalendarMonthIcon,
                              }}
                              InputProps={{
                                sx: {
                                  "& .MuiSvgIcon-root": {
                                    color: "#fff",
                                    background: "#356f92",
                                    width: "35px",
                                    height: "35px",
                                    padding: "5px",
                                    borderRadius: "5px",
                                  },
                                },
                              }}
                              value={startDate}
                              onChange={(newValue) => {
                                setStartDate(dateConvert(newValue));
                                setCheckUpdateChanges(false);
                              }}
                              minDate={new Date()}
                              defaultValue={startDate}
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  className="bdrdate"
                                  {...register("startDate", {
                                    required: !startDate
                                      ? "Please set a start date"
                                      : false,
                                  })}
                                  onKeyDown={(e) => {
                                    e.preventDefault();
                                  }}
                                  error={
                                    !startDate &&
                                    Boolean(errors?.startDate?.message)
                                  }
                                  helperText={
                                    !startDate && errors?.startDate?.message
                                  }
                                />
                              )}
                            />
                          </LocalizationProvider>
                        </Grid>
                        <Grid item xs={6}>
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b>End Date</b>
                          </div>
                          <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <DatePicker
                              inputFormat="DD-MM-YYYY"
                              // label="End Date"
                              components={{
                                OpenPickerIcon: CalendarMonthIcon,
                              }}
                              InputProps={{
                                sx: {
                                  "& .MuiSvgIcon-root": {
                                    color: "#fff",
                                    background: "#356f92",
                                    width: "35px",
                                    height: "35px",
                                    padding: "5px",
                                    borderRadius: "5px",
                                  },
                                },
                              }}
                              value={endDate}
                              onChange={(newValue) => {
                                setEndDate(dateConvert(newValue));
                                setCheckUpdateChanges(false);
                              }}
                              minDate={startDate}
                              defaultValue={endDate}
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  className="bdrdate"
                                  // {...register("endDate", {
                                  //   required: !endDate
                                  //     ? "End date is required"
                                  //     : false,
                                  // })}
                                  onKeyDown={(e) => {
                                    e.preventDefault();
                                  }}
                                // error={
                                //   !endDate &&
                                //   Boolean(errors?.endDate?.message)
                                // }
                                // helperText={
                                //   !endDate && errors?.endDate?.message
                                // }
                                />
                              )}
                            />
                          </LocalizationProvider>
                        </Grid>
                      </Grid>
                      <Grid container sx={{ mb: 2 }}>
                        <Grid item xs={6} sx={{ pr: 1 }}>
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b>Start Time*</b>
                          </div>
                          <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <TimePicker
                              components={{
                                OpenPickerIcon: AccessTimeFilledIcon,
                              }}
                              // label="Start Time"
                              value={startTime}
                              onChange={(newValue) => {
                                setStartTime(newValue);
                                setCheckUpdateChanges(false);
                              }}
                              inputProps={{
                                placeholder: 'hh:mm am/pm', // Add a placeholder text
                              }}
                              InputProps={{
                                sx: {
                                  "& .MuiSvgIcon-root": {
                                    color: "#fff",
                                    background: "#356f92",
                                    width: "35px",
                                    height: "35px",
                                    padding: "5px",
                                    borderRadius: "5px",
                                  },
                                },
                              }}
                              // defaultValue={startTime}
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  className="bdrdate"
                                  {...register("startTime", {
                                    required: !startTime
                                      ? "Please set a start time"
                                      : false,
                                  })}
                                  onKeyDown={(e) => {
                                    e.preventDefault();
                                  }}
                                  error={
                                    !startTime &&
                                    Boolean(errors?.startTime?.message)
                                  }
                                  helperText={
                                    !startTime && errors?.startTime?.message
                                  }
                                />
                              )}
                            />
                          </LocalizationProvider>
                        </Grid>
                        <Grid item xs={6}>
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b>End Time</b>
                          </div>

                          <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <TimePicker
                              components={{
                                OpenPickerIcon: AccessTimeFilledIcon,
                              }}
                              inputProps={{
                                placeholder: 'hh:mm am/pm', // Add a placeholder text
                              }}
                              InputProps={{
                                sx: {
                                  "& .MuiSvgIcon-root": {
                                    color: "#fff",
                                    background: "#356f92",
                                    width: "35px",
                                    height: "35px",
                                    padding: "5px",
                                    borderRadius: "5px",
                                  },
                                },
                              }}
                              // label="End Time"
                              value={endTime}
                              onChange={(newValue) => {
                                setEndTime(newValue);
                                setCheckUpdateChanges(false);
                              }}
                              // minTime={startTime && startTime}
                              // defaultValue={endTime}
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  className="bdrdate"
                                  // {...register("endTime", {
                                  //   required: !endTime
                                  //     ? "End time is required"
                                  //     : false,
                                  // })}
                                  onKeyDown={(e) => {
                                    e.preventDefault();
                                  }}
                                // error={
                                //   !endTime &&
                                //   Boolean(errors?.endTime?.message)
                                // }
                                // helperText={
                                //   !endTime && errors?.endTime?.message
                                // }
                                />
                              )}
                            />
                          </LocalizationProvider>
                        </Grid>
                      </Grid>
                      <Grid container sx={{ mb: 2, mt: 1 }}>
                        <Grid item xs={12} sx={{ pr: 1 }}>
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b>About Event*</b>
                          </div>
                          <FormControl
                            fullWidth
                            sx={{
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderRadius: "14px",
                              },
                            }}
                          >
                            <TextField
                              className="stepperFormInput"
                              // label="Event Description"
                              InputProps={{ sx: { height: 80 } }}
                              name="desc"
                              placeholder="About Event"
                              fullWidth
                              required
                              multiline
                              rows={3}
                              defaultValue={details?.desc}
                              size="small"
                              autoComplete="off"
                              inputProps={{
                                maxLength: 1000,
                              }}
                              {...register("desc", {
                                required: "Please enter description",
                                maxLength: {
                                  value: 1000,
                                  message: "Maximum character length is 1000",
                                },
                                validate: (value) =>
                                  validateNotEmpty(value, "description"),
                              })}
                            //   error={Boolean(errors?.mobileNumber)}
                            //   helperText={errors?.mobileNumber?.message}
                              onChange={() => setCheckUpdateChanges(false)}
                            />
                          </FormControl>
                          <FormHelperText sx={{ color: "#d32f2f" }}>
                            {errors && errors?.desc?.message}
                          </FormHelperText>
                        </Grid>
                      </Grid>
                      {
                        <>
                          {" "}
                          <Grid container>
                            <div style={{ marginLeft: "5px", marginBottom: "10px" }}>
                              <div
                                style={{
                                  fontFamily: "HK Grotesk",
                                  color: "#356F92",
                                  fontSize: "16px",
                                  fontWeight: "bold",
                                }}
                              >
                                <b>Upload Cover Image*</b>
                              </div>
                            </div>
                          </Grid>
                          {coverImage && (
                            <>
                              {" "}
                              <img
                                src={coverImage && coverImage}
                                alt=""
                                className="form-img__img-preview-4 "
                              />
                              <img
                                src={closeIconp}
                                onClick={handleDeleteCoverImage}
                                className="imageclose-2-spac"
                              />
                            </>
                          )}
                          <Grid item xs={6} sx={{ pr: 1, pl: 1 }}>
                            {!coverImage && (
                              <>
                                <div className="cls-input-sty">
                                  <input
                                    type="file"
                                    accept="image/png, image/jpeg, image/jpg"
                                    ref={hiddenCoverImageInput}
                                    style={{ display: "none" }}
                                    onChange={handleCoverImageChange}
                                  />
                                  <div
                                    style={{
                                      display: "flex",
                                      alignItems: "center",
                                    }}
                                  >
                                    <Button
                                      onClick={handleCoverImageClick}
                                      style={{
                                        fontFamily: "HK Grotesk",
                                        background: "#e3f5ff",
                                        marginTop: "4px",
                                        marginLeft: "5px",
                                        borderRadius: "8px",
                                        height: "28px",
                                        textTransform: "initial",
                                        marginRight: "10px",
                                      }}
                                    >
                                      {"Browse"}
                                    </Button>
                                    {coverImageName ? (
                                      <Typography
                                        sx={{
                                          display: "block",
                                          fontSize: "14px",
                                        }}
                                        className="ellipsewehe"
                                      >
                                        {coverImageName}
                                      </Typography>
                                    ) : null}
                                  </div>
                                </div>
                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                  {checkCoverImage && !coverImageName && "Please upload cover image"}
                                </FormHelperText>
                              </>
                            )}
                          </Grid>
                        </>
                      }
                      {isSevaEventEdit && images?.length > 0 && (
                        <>
                          <Grid container>
                            <div style={{ marginLeft: "5px", marginTop: "20px" }}>
                              <div
                                style={{
                                  fontFamily: "HK Grotesk",
                                  color: "#356F92",
                                  fontSize: "16px",
                                  fontWeight: "bold",
                                }}
                              >
                                <b>Upload Event Image</b>
                              </div>
                              <div
                                style={{
                                  fontFamily: "HK Grotesk",
                                  color: "#2C2C2C",
                                  fontSize: "14px",
                                  fontWeight: "bold",
                                }}
                              >
                                <b>
                                  Note: Select one of the image as a cover
                                  photo​*
                                </b>
                              </div>
                            </div>
                          </Grid>
                          <div style={{ marginLeft: "-10px" }}>
                            {images?.length > 0 ? (
                              <Grid item xs={6} sx={{ pr: 1 }}>
                                <div
                                  style={{ width: "700px", overflow: "inherit" }}
                                  className="postionabs itemfixed3 "
                                >
                                  {images?.length > 1 ? (
                                    <div style={{ marginLeft: "-36px" }}>
                                      <Tabs
                                        // value={value}
                                        // onChange={handleChange}

                                        variant="scrollable"
                                        scrollButtons
                                        aria-label="visible arrows tabs example"
                                        sx={{
                                          [`& .${tabsClasses.scrollButtons}`]: {
                                            "&.Mui-disabled": { opacity: 0.3 },
                                          },


                                        }}
                                      >
                                        {images?.map((image, index) => (
                                          <Card
                                            sx={{
                                              minWidth: 200,
                                              borderRadius: 0,
                                              boxShadow: "none",
                                            }}
                                            className="  "
                                          >
                                            <CardContent>
                                              {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                              <img
                                                key={index}
                                                src={
                                                  typeof image === "string"
                                                    ? image
                                                    : image.url
                                                }
                                                alt=""
                                                id="imageupload"
                                                className="imageupload form-img__img-preview-4 "
                                              />
                                              {/* <Button onClick={() => handleDelete(index)}>delete</Button> */}
                                              <img
                                                src={closeIconp}
                                                onClick={() =>
                                                  handleDelete(index)
                                                }
                                                className="imageclose-2"
                                              />
                                            </CardContent>
                                          </Card>
                                        ))}
                                      </Tabs>
                                    </div>
                                  ) : (
                                    images?.map((image, index) => (
                                      <Card
                                        sx={{ minWidth: 200, borderRadius: 0, boxShadow: "none" }}
                                        className=" "
                                      >
                                        <CardContent>
                                          {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                          <img
                                            id="imageupload"
                                            key={index}
                                            src={
                                              typeof image === "string"
                                                ? image
                                                : image.url
                                            }
                                            alt=""
                                            className="imageupload form-img__img-preview-4"
                                          />
                                          {/* <Button onClick={() => handleDelete(index)}>delete</Button> */}
                                          <img
                                            src={closeIconp}
                                            onClick={() => handleDelete(index)}
                                            className="imageclose-2"
                                          />
                                        </CardContent>
                                      </Card>
                                    ))
                                  )}
                                </div>
                                {/* <h6>Event Images</h6>
<input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} />
<div>
{images.map((image, index) => (
    <img key={index} src={image.url} alt="" className="form-img__img-preview" />
))}
</div> */}
                              </Grid>
                            ) : null}
                            {/* <div  style={{ fontFamily: 'HK Grotesk', color: "#356F92", fontSize: "18px", fontWeight: 'bold',marginLeft:"16px" }}> <span  style={{marginRight:"10px",fontSize: "22px",fontWeight: 'bold'}}>+</span>Add More </div> */}
                          </div>
                        </>
                      )}
                    </Grid>
                    <Grid item xs={6} sx={{ pr: 1, pl: 1 }}>
                      <FormControl>
                        <input
                          type="file"
                          ref={hiddenFileInput}
                          style={{
                            display: "none",
                            margin: "0 auto",
                            border: "dotted 3px #1976d2",
                            padding: "50px",
                            width: "40%",
                            borderRadius: "14px",
                          }}
                          multiple
                          onChange={handleImageChange}
                          accept="image/png, image/jpeg, image/jpg"
                        // {...register("coverImage", {
                        //   required: "Please add cover image",
                        // })}
                        />
                        {/* <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.coverImage?.message}
                        </FormHelperText> */}
                      </FormControl>
                      {/* <Box
                              sx={{
                                display: "flex",
                                "& > :not(style)": {
                                  m: 1,
                                  width: 160,
                                  height: 140,
                                },
                              }}
                            >
                              <Paper
                                variant="outlined"
                                square
                                sx={{
                                  margin: "0 auto",
                                  border: "dotted 3px #1976d2",
                                  padding: "50px",
                                  width: "40%",
                                  borderRadius: "14px",
                                }}
                              >
                                <IconButton
                                  color="primary"
                                  aria-label="Upload"
                                  onClick={handleClick}
                                  sx={{
                                    display: "flex",
                                    justifyContent: "center",
                                    position: "relative",
                                    top: "25%",
                                    margin: "0 auto",
                                  }}
                                >
                                  <UploadIcon />
                                </IconButton>
                                <b
                                  style={{
                                    display: "flex",
                                    justifyContent: "center",
                                    position: "relative",
                                    top: "25%",
                                    whiteSpace: "nowrap",
                                    padding: "10px",
                                  }}
                                >
                                  {" "}
                                  Add More Images
                                </b>
                              </Paper>
                            </Box> */}
                    </Grid>
                  </form>
                </Box>
              </Grid>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ justifyContent: "center", marginBottom: "10px",alignItems:"center"}}>
          <React.Fragment>
            <div className="d-flex">
              {isSevaEventEdit ? (
                <Button
                  className= {`button-tr-2-12-disa ${checkUpdateChanges ? 'button-tr-2' : ''}`}
                  onClick={handleSubmit(onAddSevaEvent)}
                  onFocus={() => setCheckCoverImage(true)}
                  disabled={checkUpdateChanges}
                >
                  Update
                </Button>
              ) : (
                <Button
                  className="button-tr-2-12 "
                  onClick={handleSubmit(onAddSevaEvent)}
                  onFocus={() => setCheckCoverImage(true)}
                // disabled={image ? false : true}
                >
                  Save
                </Button>
              )}

              {isSevaEventEdit && (
                <Button
                  className="button-tr-citizen-cancel-upl"
                  // sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                  // className="button-tr-4 "
                  onClick={handleClick}
                >
                  Upload Event Images
                </Button>
              )}
              <div style={{ marginTop: "12px" }}>
                {isSevaEventEdit && (
                  <img
                    src={imagedelete}
                    onClick={handleClickOpenDeleteDialog}
                    className="deleteimgcss1 cursorshow"
                    style={{ marginTop: "0px", marginLeft: "15px",width:"30px",height:"30px",padding:"6px",border:"1px solid #356F92" }}
                    alt="delete"
                  />
                )}
              </div>
            </div>
          </React.Fragment>
          {openDeleteDialog && (
            <DeleteIndividualEventDialog
              openDeleteDialog={openDeleteDialog}
              handleCloseDeleteDialog={handleCloseDeleteDialog}
              eventId={details?.id}
              mpId={mpProfileData?.id}
              handleCloseEventDetailsDialog={handleCloseEventDetailsDialog}
              editEventDetails={editEventDetails}
              eventByMpId={eventByMpId}
              initiativeId={initiativeId}
              handleCloseInitiativeDetails={handleCloseInitiativeDetails}
              details={details}
              setDeleteClick={setDeleteClick}
              isSevaEventEdit={isSevaEventEdit}
            />
          )}
        </DialogActions>
      </Dialog>
    </>
  );
};

export default CreateNewEvent;
