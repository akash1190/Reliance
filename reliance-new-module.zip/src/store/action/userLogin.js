import axios from "axios"
import { useNavigate } from "react-router-dom"
import Constant from "../../utils/constant"
import {  GET_LOGIN_FAILURE, GET_LOGIN_REQUEST, GET_LOGIN_SUCCESS} from "./types"

export const fetchLoginRequest = () => {
    return {
        type:  GET_LOGIN_REQUEST
    }
}
export const fetchLoginSuccess = (token, username, password) => async (dispatch) => {
    dispatch({
      type: 
      GET_LOGIN_SUCCESS,
      payload: {
        token,
      },
    });
    debugger
    const navigate=useNavigate()
    debugger 
    if (username === "admin" && password === "admin") {
        navigate("/AdminHome");
    } else if (username === "mp" && password === "mp") {
        navigate("/MPHome");
    } else if (username === "leader" && password === "leader") {
        navigate("/AdminHome");
    }
    // return {
    //     type:  GET_LOGIN_SUCCESS,
    //     payload: value
    // }
}
export const fetchLoginFailure = error => {
    return {
        type:  GET_LOGIN_FAILURE,
        payload: error
    }
}

const useNavigateToPage = (username, password) => {
    debugger
    const navigate=useNavigate()
    debugger 
    if (username === "admin" && password === "admin") {
        navigate("/AdminHome");
    } else if (username === "mp" && password === "mp") {
        navigate("/MPHome");
    } else if (username === "leader" && password === "leader") {
        navigate("/AdminHome");
    }
};
export const getToken = (payload) => async (dispatch) => {
    
    dispatch(fetchLoginRequest)
    const {username,password}=payload
   
    await axios.post(Constant.BASE_URL + `/api/auth/signin`,payload)
   
    
    .then(response => {
        
        localStorage.setItem("tokenDetails",response.data?.token)
        dispatch(fetchLoginSuccess(response.data?.token))
        useNavigateToPage(username, password);
        // if(username==="admin" && password==="admin"){
        //     navigate("/AdminHome")
        //     }
        //     else if(username==="mp" && password==="mp"){
        //       navigate("/MPHome",0)
        //     }
        //     else if(username==="leader" && password==="leader"){
        //       navigate("/AdminHome")
        //     }
    })
    .catch(error => {
        debugger
        const errorMsg = error.message
        dispatch(fetchLoginFailure(errorMsg))
    })
}




// export const getToken = (payload) => async (dispatch) => {
    
//     await axios.post(Constant.BASE_URL + `/api/auth/signin`,payload)
//     .then(response => {
//         localStorage.setItem("tokenDetails",response.data?.token)
//     })
//     .catch(error => {
//         const errorMsg = error.message
//         dispatch(fetchLoginFailure(errorMsg))
//     })
// }