class Constant {
  static BASE_URL = "https://rnm-api.mobileprogramming.net";
  static idKey = "30221"
  static roleKey = "49221"
 
}

export default Constant;