import React, { useEffect, useState } from "react";
import PropTypes from 'prop-types';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import { IconButton, Box, Card, CardContent, CardMedia } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import one from "../../../asserts/images/1.jpg"
import two from "../../../asserts/images/4.jpg";
import three from "../../../asserts/images/2.jpg";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";
import ShareIcon from '@mui/icons-material/Share';
import CancelSharpIcon from '@mui/icons-material/CancelSharp';
import BorderColorIcon from "../../../asserts/images/Create.svg";
import "./AddSevaEvent.css";
import CreateNewEvent from "./CreateNewEvent";
import { useDispatch, useSelector } from "react-redux";
import { getInitiativeList } from "../../../store/action/initiativeList";
import { getOngoingSevaIntiativesListByMpId } from "../../../store/action/ongoingSevaInitiativesList";
import Constant from "../../../utils/constant";
import { getIds } from "../../ReusableComponents.js/getIds";

const AddSevaEvent = ({ handleCloseSevaEvent, openSevaEvent, details, eventByMpId, mpId }) => {
    const [value, setValue] = useState(0);
    const initiativeList = useSelector((state) => state?.ongoingSevaInitiativesListByMpId?.data)
    const [openCreateEventDialog, setOpenCreateEventDialog] = useState(false);
    const [initiativeId, setInitiativeId] = useState(null);
    const [initiativeName, setInitiativeName] = useState(null);
    const dispatch = useDispatch()
    const loggedInId=getIds()
    useEffect(() => {
        dispatch(getOngoingSevaIntiativesListByMpId(loggedInId));
        // dispatch(getInitiativeList())
    }, [])
    const handleOpenCreateEvent = (initiativeId, initiativeName) => {
        setInitiativeId(initiativeId);
        setInitiativeName(initiativeName);
        setOpenCreateEventDialog(true);
        handleCloseSevaEvent();
    }
    const handleCloseCreateEvent = (reset, setImages, setFiles, setStartDate, setEndDate, setStartTime, setEndTime) => {
        setInitiativeId(null);
        reset();
        setImages([]);
        setFiles([]);
        setStartDate(null);
        setEndDate(null);
        setStartTime(null);
        setEndTime(null);
        setInitiativeName(null);
        setOpenCreateEventDialog(false);
    }

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const BootstrapDialog = styled(Dialog)(({ theme }) => ({
        '& .MuiDialogContent-root': {
            padding: theme.spacing(2),
        },
        '& .MuiDialogActions-root': {
            padding: theme.spacing(1),
        },
    }));
    function BootstrapDialogTitle(props) {
        const { children, onClose, ...other } = props;

        return (
            <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
                {children}
                {onClose ? (
                    <IconButton
                        aria-label="close"
                        onClick={onClose}
                        sx={{
                            position: 'absolute',
                            right: 8,
                            top: 8,
                            // color: (theme) => theme.palette.grey[500],
                            border: "1px solid #9e9e9e",
                            borderRadius: "50%"
                        }}
                    >
                        <CloseIcon />
                    </IconButton>
                ) : null}
            </DialogTitle>
        );
    }

    BootstrapDialogTitle.propTypes = {
        children: PropTypes.node,
        onClose: PropTypes.func.isRequired,
    };

    return (
        <div style={{
            margin: "0 50% 0 50%",
            // padding:"40px",
            minHeight: "95vh"
        }}>
            <BootstrapDialog
                onClose={handleCloseSevaEvent}
                aria-labelledby="customized-dialog-title"
                open={openSevaEvent}
                sx={{
                    "& .MuiDialog-container": {
                      "& .MuiPaper-root": {
                        width: "100%",
                        maxWidth: "63%!important",  // Set your width here
                      },
                    },
                  }}

            >
                <BootstrapDialogTitle id="customized-dialog-title" onClose={handleCloseSevaEvent}>
                    <h5 style={{ fontFamily: "HK Grotesk", fontSize: "20px", color: "#356F92", fontWeight: 'bold', marginRight: 2 }}>Choose an initiative for which you would<br /> like to create an event for</h5>
                </BootstrapDialogTitle>
                <DialogContent>
                    <div className="d-flex justify-content-between leaders-cards">
                        <Box
                            sx={{
                                flexGrow: 1,
                                minWidth: { xs: 400, sm: 400 },
                                // bgcolor: 'background.paper',
                                // marginTop:"-10px"
                            }}
                        >
                            <Tabs
                                value={value}
                                onChange={handleChange}
                                variant="scrollable"
                                scrollButtons
                                aria-label="visible arrows tabs example"
                                sx={{
                                    [`& .${tabsClasses.scrollButtons}`]: {
                                        '&.Mui-disabled': { opacity: 0.3 },
                                    },
                                    '& .MuiTabs-indicator': { display: 'none' } 
                                }}
                            >
                                {initiativeList && initiativeList?.map((data, index) =>
                                    <Card sx={{ minWidth: 200, width:"200px!important", mr: 2, borderRadius: "14px" }} onClick={() => handleOpenCreateEvent(data?.id, data?.initiativeName)}>
                                        <div style={{ position: "relative" }}>
                                            <CardMedia
                                                sx={{
                                                    // filter: "brightness(50%)",
                                                    // backgroundColor: "rgb(0 0 0 / 30%)",
                                                    // borderRadius: "7px",
                                                    

                                                }}
                                                id={index}
                                                component="img"
                                                height="150"
                                                
                                                src={JSON.parse(data?.coverimage)[0]}
                                                onError={e =>
                                                    e.target.src = NoImageFound}
                                                alt="new Image"
                                                className='blackoverlay'
                                            />
                                              <div className="dibgover" style={{marginTop:"17%"}}></div>
                                            <div className="ecclipseonwidthnewrow-uyt" style={{ position: "absolute", color: "white", top: 100, left: "16%", transform: "translateX(-10%)",zIndex:"999" }}> {data?.initiativeName}</div>
                                        </div>
                                    </Card>
                                )}
                            </Tabs>
                        </Box>
                    </div>
                </DialogContent>
                <div style={{ display: "flex", justifyContent: "flex-start", marginLeft: "16px", paddingBottom: "20px" }}>
                    <DialogActions>
                        <div style={{ fontFamily: "HK Grotesk", fontSize: "18px", color: "#356F92", fontWeight: 'bold' }}> OR</div>
                        <Button className="button-tr-01" sx={{ ml: 2 }} onClick={() => handleOpenCreateEvent(null, null)}>
                            <b style={{ fontFamily: "HK Grotesk", fontSize: "14px", textTransform: "capitalize", letterSpacing: "1px", marginRight: "10px" }}>Create an Individual Event</b>
                            <img src={BorderColorIcon} width="20px" style={{ marginBottom: "4px" }} />
                        </Button>
                    </DialogActions>
                </div>
            </BootstrapDialog>
            {openCreateEventDialog && <CreateNewEvent
                openCreateEventDialog={openCreateEventDialog}
                handleCloseCreateEvent={handleCloseCreateEvent}
                initiativeId={initiativeId}
                initiativeName={initiativeName}
                eventByMpId={eventByMpId}
                mpId={mpId}
            />}
        </div>
    );
}

export default AddSevaEvent;