import React, { useEffect, useRef, useState, createRef } from "react";
import DialogTitle from "@mui/material/DialogTitle";
import Dialog from "@mui/material/Dialog";
import CloseIcon from "@mui/icons-material/Close";
import {
  FormControl,
  Grid,
  IconButton,
  InputLabel,
  Select,
  MenuItem,
  Button,
  FormHelperText,
  DialogActions,
} from "@mui/material";
import { Box, getValue } from "@mui/system";
import AddIcon from "@mui/icons-material/Add";
import UploadIcon from "@mui/icons-material/Upload";
import UploadImages from "./UploadImageDialog";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import closeIconp from "../../../../asserts/images/close-1.png";
import { useNotificationContext } from "../../../../utils/NotificationContext";

const AddImageTemplates = ({
  handleCloseImageTemplateDialog,
  openImageTemplateDialog,
  setImageData,
  languages,
  editDetails,
  imageData,
  setUpdateValue,
  createNewClick,
}) => {
  const {
    register,
    unregister,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
    reset,
  } = useForm();
  const fileFormats = ["image/png", "image/jpeg", "image/jpg"];
  const { showNotification } = useNotificationContext();
  const [checkWarningPopup, setCheckWarningPopup] = useState(false);

  const [dialogState, setDialogState] = useState({
    open: false,
    for: undefined,
  });
  useEffect(() => { }, [imageData]);
  const uploadImageRefMain = useRef();
  const [fileRefs, setFileRefs] = useState([]);
  const [images, setImages] = useState([]);
  const [files, setFiles] = useState([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(-1);
  const [initialId, setInitialId] = useState(-1);
  const [inputState, setInputState] = useState([
    {
      id: Date.now(),
      inputType: true,
      bannerSize: false,
      language: true,
      upload: true,
      remove: true,
    },
  ]);
  const bannerSize = [
    { id: 1, value: "1:1" },
    { id: 2, value: "16:9" },
    { id: 3, value: "3:6" },
  ];

  useEffect(() => {
    setFileRefs(inputState.map(() => createRef()));
  }, []);


  useEffect(() => {
    if (editDetails) {
      const temp = [];
      editDetails?.forEach((template, i) => {
        temp.push({
          id: i,
          inputType: true,
          inputTypeValue: template.typeof_image,
          bannerSize: template.typeof_image === "Outdoor Banner",
          bannerSizeValue:
            template.banner_size !== null ? template.banner_size.trim() : "",
          language: true,
          languageValue: template.imageLanguage,
          upload: true,
          remove: true,
          imagesData:
            typeof template.url === "string"
              ? JSON.parse(template.url)
              : template.url,
        });
        !getValues(`${i}`)?.length > 0 &&
          setValue(
            `${i}.images`,
            typeof template.url === "string"
              ? JSON.parse(template.url)
              : template.url
          );
        !getValues(`${i}`)?.length > 0 &&
          setValue(`${i}.imageType`, template.typeof_image);
        !getValues(`${i}`)?.length > 0 &&
          setValue(`${i}.language`, template.imageLanguage);
      });
      setInputState(temp);
      setFileRefs(temp.map(() => createRef()));
    }
  }, [editDetails]);

  const imagesTypes = [
    { id: 1, value: "Certificate" },
    { id: 2, value: "Social Media" },
    { id: 3, value: "Outdoor Banner" },
  ];

  const removeInput = (id) => {
    const tempData = [...inputState];
    const newData = tempData.filter((input) => input.id !== id);
    const index = inputState.findIndex((data) => data.id === id);
    const newRefs = fileRefs.filter((_, i) => tempData[i].id !== id);
    unregister(index.toString());
    setInputState(newData);
    setFileRefs(newRefs);
    const newFormData = {};
    const formData = getValues();
    const formDataValues = Object.values(formData);
    formDataValues.forEach((item, ind) => {
      newFormData[ind] = item;
    });
    reset(newFormData);
  };

  const addInput = () => {
    const newInput = {
      id: inputState.length,
      inputType: true,
      bannerSize: false,
      language: true,
      upload: true,
      remove: true,
    };
    setInputState((prevState) => [...prevState, newInput]);
    setFileRefs((prevRefs) => [...prevRefs, createRef()]);
  };

  const showBannerField = (e, input) => {
    const tempData = [...inputState];
    const index = tempData.findIndex((data) => data.id === input.id);
    if (e.target.value === "Outdoor Banner") {
      tempData[index].bannerSize = true;
    } else {
      tempData[index].bannerSize = false;
    }
    setInputState(tempData);
  };

  const isUploadImageEnabledOrNot = (i) => {
    const typeOfImage = getValues(`${i}.imageType`)
    const typeOfBanner = getValues(`${i}.bannerSize`)
    const language = getValues(`${i}.language`)
    let isDisabled = false;
    if (typeOfImage === "Outdoor Banner") {
      isDisabled = Boolean(typeOfImage && typeOfBanner && language)
    } else {
      isDisabled = Boolean(typeOfImage && language)
    }
    return isDisabled;
  }

  const handleClick = (e, i) => {
    setImages([]);
    // uploadImageRefMain.current?.click();
    isUploadImageEnabledOrNot(i) && fileRefs[i].current?.click();
    e?.stopPropagation();
  };
  const handleDelete = (i) => {
    // setInitialId(i)
    // if(images.length<1){
    //     setImages([])
    // }
    // else{
    setCheckWarningPopup(true);
    const tempImages = [...images];
    tempImages.splice(0, 1);
    setImages(tempImages);
    if (inputState.length > 0) {
      let updatedInputState = [...inputState]; // create a copy of inputState
      updatedInputState[i] = {
        // update the object at index i
        ...updatedInputState[i], // spread the current object's properties
        imagesData: inputState[i].imagesData.slice(1), // create a new array without the first element
      };
      setInputState(updatedInputState);
      let val = getValues(`${i}`);

      delete val.images[0];
      val.images.splice(0, 1);
      setValue(`${i}.images`, val.images);
    } else {
      let val = getValues(`${i}`);

      delete val.images[0];
      val.images.splice(0, 1);
      setValue(`${i}.images`, val.images);
    }
  };
  const handleImageChange = (e, i) => {
    const uploadedFiles = e.target.files;
    if (uploadedFiles.length > 0) {
      setCheckWarningPopup(true);
    }
    setFiles([...files, ...uploadedFiles]);
    let newFiles = [];
    for (let i = 0; i < uploadedFiles.length; i++) {
      const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
        newFiles.push({
          type: "image",
          url: reader.result,
          file: uploadedFiles[i],
        });
        if (i === uploadedFiles.length - 1) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          setImages([...newFiles]);
          // setValue(`${currentImageIndex}.images`,[...images, ...newFiles])
        }
      };
    }

    handleOpenUploadDialog(`${currentImageIndex}`);
  };
  const handleOpenUploadDialog = (id, edit = false, images = []) => {
    if (!edit) {
      setImages(getValues(id));
      setDialogState({ open: true, for: id });
    } else {
      setImages(images);
      setDialogState({ open: true, images, for: id });
    }
  };
  const handleCloseUploadDialog = () =>
    setDialogState({ open: false, for: undefined });

  const onSubmit = (data) => {
    const objectArray = Object.values(data);
    // setImageData(objectArray)
    setImageData([]);
    setImageData((prevData) => [
      ...prevData,
      prevData.length > 0
        ? objectArray?.map((val) => prevData[0]?.push(val))
        : objectArray,
    ]);
    setUpdateValue(true);
    handleCloseImageTemplateDialog();
  };

  return (
    <Dialog
      onClose={() => handleCloseImageTemplateDialog(checkWarningPopup)}
      // onClose={() => handleCloseImageTemplateDialog()}
      open={openImageTemplateDialog}
      sx={{ height: "90vh", marginTop: "25px" }}
    >
      <DialogTitle
        sx={{
          fontFamily: "HK Grotesk",
          color: "#2e739c",
          fontWeight: "700",
          textAlign: "center",
          fontSize: "26px",
        }}
      >
        {editDetails?.length > 0 ? "Update" : "Add"} Image Templates
      </DialogTitle>
      <IconButton
        aria-label="close"
        onClick={() => handleCloseImageTemplateDialog(checkWarningPopup)}
        // onClick={() => handleCloseImageTemplateDialog()}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
          border: "1px solid #9e9e9e",
          borderRadius: "50%",
        }}
      >
        <CloseIcon />
      </IconButton>
      <Box sx={{ m: 3, overflowX: "hidden" }}>
        <form>
          {inputState?.map((input, i) => {
            return (
              <div className="box" key={input.id}>
                <Grid container>
                  <Grid item xs={6} md={6} lg={6} xl={6}>
                    {input.inputType && (
                      <Grid container spacing={2} sx={{ mt: 1 }}>
                        <Grid
                          item
                          xs={12}
                          md={12}
                          lg={12}
                          xl={12}
                          sx={{ width: "280px" }}
                        >
                          <b
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              marginLeft: "8px",
                              position: "relative",
                              bottom: "5px",
                            }}
                          >
                            Type of Images
                          </b>
                          <FormControl
                            size="small"
                            fullWidth
                            sx={{
                              "& .MuiInputBase-input": {
                                borderRadius: "14px!important",
                              },
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderRadius: "14px",
                              },
                            }}
                          >
                            {/* <InputLabel id="demo-select-small" ></InputLabel> */}
                            <Select
                              labelId="demo-select-small"
                              id="demo-select-small"
                              // label="Type of Images"
                              // required
                              {...register(`${i}.imageType`, {
                                required: "Please select the Type of Image",
                              })}
                              onChange={(e) => {
                                showBannerField(e, input);
                                setCheckWarningPopup(true);
                              }}
                              defaultValue={input?.inputTypeValue}
                            >
                              {imagesTypes &&
                                imagesTypes.map((s) => {
                                  return (
                                    <MenuItem
                                      native="true"
                                      key={s.value}
                                      sx={{ width: "100%" }}
                                      value={s.value}
                                      size="small"
                                    >
                                      {s.value}
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                            <FormHelperText
                              sx={{ color: "#D93025" }}
                              class="p-error"
                            >
                              {errors &&
                                errors[i] &&
                                errors[i].imageType?.message}
                            </FormHelperText>
                          </FormControl>
                        </Grid>
                      </Grid>
                    )}
                    {input.bannerSize && (
                      <Grid container spacing={2} sx={{ mt: 1 }}>
                        <Grid item xs={12} md={12} lg={12} xl={12}>
                          <FormControl
                            size="small"
                            fullWidth
                            sx={{
                              "& .MuiInputBase-input": {
                                borderRadius: "14px!important",
                              },
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderRadius: "14px",
                              },
                            }}
                          >
                            <b
                              style={{
                                fontFamily: "HK Grotesk",
                                color: "#356F92",
                                fontSize: "16px",
                                marginLeft: "8px",
                                position: "relative",
                                bottom: "5px",
                              }}
                            >
                              Banner Size
                            </b>
                            <Select
                              labelId="demo-select-small"
                              // label="Banner Size"
                              required
                              {...register(`${i}.bannerSize`, {
                                required: "Please select a Banner Size",
                              })}
                              defaultValue={input?.bannerSizeValue}
                              onChange={() => setCheckWarningPopup(true)}
                            >
                              {bannerSize &&
                                bannerSize.map((s) => {
                                  return (
                                    <MenuItem
                                      native="true"
                                      key={s.value}
                                      sx={{ width: "100%" }}
                                      value={s.value}
                                      size="small"
                                    >
                                      {s.value}
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                            <FormHelperText
                              sx={{ color: "#D93025" }}
                              class="p-error"
                            >
                              {errors &&
                                errors[i] &&
                                errors[i].bannerSize?.message}
                            </FormHelperText>
                          </FormControl>
                        </Grid>
                      </Grid>
                    )}
                    {input.language && (
                      <Grid container spacing={2} sx={{ mt: 1 }}>
                        <Grid item xs={12} md={12} lg={12} xl={12}>
                          <b
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#356F92",
                              fontSize: "16px",
                              marginLeft: "8px",
                              position: "relative",
                              bottom: "5px",
                            }}
                          >
                            Language
                          </b>
                          <FormControl
                            size="small"
                            fullWidth
                            sx={{
                              "& .MuiInputBase-input": {
                                borderRadius: "14px!important",
                              },
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderRadius: "14px",
                              },
                            }}
                          >
                            {/* <InputLabel id="demo-select-small">Language</InputLabel> */}
                            <Select
                              labelId="demo-select-small"
                              id="demo-select-small"
                              // label="Langauge"
                              required
                              {...register(`${i}.language`, {
                                required:
                                  "Please select Language of the banner",
                              })}
                              defaultValue={input?.languageValue}
                              onChange={() => setCheckWarningPopup(true)}
                            >
                              {languages &&
                                languages.map((s) => {
                                  return (
                                    <MenuItem
                                      native
                                      key={s.id}
                                      sx={{ width: "100%" }}
                                      value={s.language}
                                      size="small"
                                    >
                                      {s.language}
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                            <FormHelperText
                              sx={{ color: "#D93025" }}
                              class="p-error"
                            >
                              {errors &&
                                errors[i] &&
                                errors[i].language?.message}
                            </FormHelperText>
                          </FormControl>
                        </Grid>
                      </Grid>
                    )}

                    {input.remove && inputState.length !== 1 && (
                      <Grid item xs={3} sx={{ mt: 1, marginLeft: "-15px" }}>
                        <Button
                          variant="outlined"
                          sx={{ borderRadius: 4 }}
                          className="button-tr-citizen-admin-dl"
                          onClick={() => {
                            removeInput(input.id);
                            setCheckWarningPopup(true);
                          }}
                        >
                          Delete Row
                        </Button>
                        {/* } */}
                      </Grid>
                    )}
                  </Grid>
                  <Grid
                    item
                    xs={6}
                    md={6}
                    lg={6}
                    xl={6}
                    sx={{ marginTop: "45px" }}
                  >
                    <div
                      style={{
                        fontFamily: "HK Grotesk",
                        color: "#356F92",
                        fontSize: "16px",
                        fontWeight: "bold",
                        display: "flex",
                        justifyContent: "center",
                        whiteSpace: "nowrap",
                        position: "relative",
                        bottom: "10px",
                        color: "#356F92",
                      }}
                    >
                      Image Preview
                    </div>
                    {input.upload && (
                      <Grid
                        item
                        sx={{
                          pr: 1,
                          pl: 1,
                          margin: "0 auto",
                          border: "dotted 3px #1976d2",
                          padding: "50px",
                          width: "40%",
                          borderRadius: "14px",
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            "& > :not(style)": {
                              width: 30,
                              height: 30,
                            },
                          }}
                        >
                          <div>
                            <IconButton
                              color="primary"
                              aria-label="Upload"
                              onClick={
                                (e) => {
                                  handleClick(e, i);
                                  setCurrentImageIndex(i);
                                }
                                // handleOpenUploadDialog(`${i}.images`)
                              }
                              sx={{}}
                            >
                              <UploadIcon />
                            </IconButton>
                            <br />
                            <input
                              type="file"
                              multiple
                              {...register(`${i}.images`, {
                                required: "Please add images",
                              })}
                              accept="image/png, image/jpeg, image/jpg"
                              ref={fileRefs[i]}
                              style={{ display: "none" }}
                              onChange={(e) => {
                                handleImageChange(e, i);
                              }}
                            />
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "center",
                                whiteSpace: "nowrap",
                                marginLeft: "4px",
                              }}
                            >
                              Add Images
                            </div>
                          </div>
                          {/* {
                                                    getValues(`${i}.images`)?.length > 0 && (
                                                        <div>
                                                            <img src={getValues(`${i}.images`)[0].url} onClick={() => handleOpenUploadDialog(`${i}.images`)} alt=""
                                                                style={{ width: 210, height: 144, position: "relative", top: "45%", left: "0", transform: "translate(-50%, -50%)" }} />
                                                            <img src={closeIconp} id={i} onClick={() => handleDelete(i)} className="imageclose-imge" />
                                                            {
                                                                getValues(`${i}.images`)?.length > 1 ? <Link style={{ whiteSpace: 'nowrap', marginLeft: "-50px", position: "relative", top: "-240%" }} onClick={() => handleOpenUploadDialog(`${i}.images`)}>+{getValues(`${i}.images`).length - 1} More {getValues(`${i}.images`).length > 2 ? "Images" : "Image"} </Link> :
                                                                    <Link style={{ whiteSpace: 'nowrap', marginLeft: "-50px", position: "relative", top: "-240%" }} onClick={() => handleOpenUploadDialog(`${i}.images`)}>Add More Images </Link>
                                                            }
                                                        </div>
                                                    )
                                                } */}
                          {input?.imagesData?.length > 0 && (
                            <div>
                              <img
                                src={
                                  input?.imagesData[0].url
                                    ? input?.imagesData[0].url
                                    : input?.imagesData[0]
                                }
                                onClick={() =>
                                  handleOpenUploadDialog(
                                    i,
                                    true,
                                    input?.imagesData
                                  )
                                }
                                alt=""
                                style={{
                                  width: 210,
                                  height: 144,
                                  position: "relative",
                                  top: "45%",
                                  left: "0",
                                  transform: "translate(-50%, -50%)",
                                }}
                              />
                              <img
                                src={closeIconp}
                                id={i}
                                onClick={() => handleDelete(i)}
                                className="imageclose-imge"
                              />
                              {input?.imagesData?.length > 1 ? (
                                <Link
                                  style={{
                                    whiteSpace: "nowrap",
                                    marginLeft: "-50px",
                                    position: "relative",
                                    top: "-240%",
                                  }}
                                  onClick={() =>
                                    handleOpenUploadDialog(
                                      i,
                                      true,
                                      input?.imagesData
                                    )
                                  }
                                >
                                  +{input?.imagesData?.length - 1} More{" "}
                                  {input?.imagesData?.length > 2
                                    ? "Images"
                                    : "Image"}{" "}
                                </Link>
                              ) : (
                                <Link
                                  style={{
                                    whiteSpace: "nowrap",
                                    marginLeft: "-50px",
                                    position: "relative",
                                    top: "-240%",
                                  }}
                                  onClick={() =>
                                    handleOpenUploadDialog(
                                      i,
                                      true,
                                      input?.imagesData
                                    )
                                  }
                                >
                                  Add More Images{" "}
                                </Link>
                              )}
                            </div>
                          )}
                        </Box>
                        {/* <b style={{ fontFamily: 'HK Grotesk',color:"#505050",fontSize:"15px",position:"relative",left:"5%"}}>Add Images</b> */}
                      </Grid>
                    )}
                    {errors[i] && (
                      <FormHelperText class="p-error center">
                        {errors && errors[i] && errors[i].images?.message}
                      </FormHelperText>
                    )}
                  </Grid>
                  <hr style={{ width: "96%", marginTop: "45px" }}></hr>
                </Grid>
              </div>
            );
          })}
        </form>
        <div style={{ marginLeft: "4px", marginTop: "45px" }}>
          <b>
            Note: Upload banner image in JPG or PNG or JPEG file Format only
          </b>
        </div>
        <div className="btn-box">
          <React.Fragment>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                mb: 2,
                mt: 2,
                marginLeft: "-15px",
              }}
            >
              <Button
                variant="outlined"
                className="button-tr-citizen-admin"
                startIcon={<AddIcon sx={{ mt: "5px" }} />}
                onClick={() => {
                  addInput();
                }}
              >
                Add Row
              </Button>
              <Box sx={{ flex: "1 1 auto" }} />
            </Box>
          </React.Fragment>
        </div>
      </Box>

      <DialogActions sx={{justifyContent:"center"}} >
        <Button
          sx={{
            p: 1,
            backgroundColor: "#ef7335",
            borderRadius: 4,
            width:"250px"
          }}
          className="button-tr-2"
          type="submit"
          onClick={handleSubmit(onSubmit)}
        >
          {editDetails?.length > 0 ? "Update Image Template" : "Add Image Template"}
        </Button>
        {/* <Box sx={{ flex: "1 1 auto" }} /> */}
      </DialogActions>
      {images?.length > 0 && (
        <UploadImages
          handleCloseUploadDialog={handleCloseUploadDialog}
          state={dialogState}
          setValue={setValue}
          getValue={getValues}
          setImagesNew={setImages}
          initialImages={
            dialogState.for === "edit" ? dialogState.images : images
          }
          initialId={initialId}
          setInputData={setInputState}
          inputData={inputState}
          fileFormats={fileFormats}
          setCheckWarningPopup={setCheckWarningPopup}
        />
      )}
    </Dialog>
  );
};

export default AddImageTemplates;
