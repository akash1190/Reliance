import React from "react";
import { useState, useEffect } from "react";
import "./sharingTextBox.css";
import ShareIcon from "@mui/icons-material/Share";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { toast } from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";
import { getTextData } from '../../store/action/text';
import { Dialog, DialogTitle, IconButton, Typography } from "@mui/material";
import Share from "../ReusableComponents.js/Share";
import CloseIcon from "@mui/icons-material/Close";
import  CopyAndShareClick  from "../ReusableComponents.js/CopyAndShareAPI";

function SharingTextBox({ language }) {
  const [textData, setTextData] = useState([])
  const texttemplates = useSelector((state) => state?.socialMediaKit?.data !== [] && state?.socialMediaKit?.data?.texttemplates);
  const [filterData, setFilterData] = useState([])
  const [openShare, setOpenShare] = useState(false);
  const [Content, setContent] = useState("");
  const dispatch = useDispatch();
  const tkn = localStorage.getItem("tokenDetails");
  const handleClickingOpen = () => {
    setOpenShare(true);
  };

  const handleShareModalClose = (value) => {
    setOpenShare(false);
  };
  // if languages have been added we can add the functionality here //

  useEffect(() => {
    setTextData(texttemplates && texttemplates)
    dispatch(getTextData(0))  // replace with mpUserID
    // let data= textData;
    // setFilterData(data.filter(x=>x.language == 'English'));
  }, [])

  return (
    <>
      <div className="itemfixed5">
        {textData.length === 0 ? <span style={{ fontSize: "21px", marginLeft: "2%" }}>No text added by Admin</span> : textData?.filter(x => x.language == language).map((item, i) => (
          <div
            className="sharing-text-box-container"
            style={{ padding: "10px" }}
            key={i}
          >
            <p className="linebreakut">{item.text}</p>
            <div style={{ position: "relative" }}>
              <div className="sharing-text-box-bottom linebreakut" >
                <p>{item.hashtag}</p>
                <div className="sharing-text-box-bottom-right">
                  <div>
                    <ShareIcon className='shareicone'
                      onClick={() => {
                        setContent(`${item.text}   ${item.hashtag}`);
                        handleClickingOpen()
                      }
                      }
                      style={{ color: "#356F92", background: "#fff" }}
                    />
                  </div>
                  <div>
                    <ContentCopyIcon
                      onClick={() => {
                        window.navigator.clipboard
                          .writeText(item.text)
                          .then((res) => {
                            toast.success("Copied to clipboard.");
                          })
                          .catch((err) => console.log(err));
                          CopyAndShareClick()
                      }}
                      style={{ color: "#356F92", background: "#fff", borderRadius: "50%", padding: "3px", width: "25px", height: "25px", marginLeft: "-30px", cursor: "pointer" }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <Dialog open={openShare} handleClose={handleShareModalClose}>


              <DialogTitle>
                <IconButton
                  aria-label="close"
                  onClick={() => handleShareModalClose(false)}
                  sx={{
                    position: "absolute",
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                    border: "1px solid #9e9e9e",
                    borderRadius: "50%",
                    padding: "2px",
                    cursor: "pointer",
                  }}
                >
                  <CloseIcon />
                </IconButton>
                <Typography
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    color: "#357092",
                    fontFamily: "HK Grotesk",
                    fontSize: "26px",
                    fontWeight: "bold",
                  }}
                >
                  Share to Social Media
                </Typography>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    marginTop: "25px",
                    gap: "40px",
                  }}
                >
                  <Share content={Content} />

                </div>
                {/* <CloseIcon onClick={() => setAddMembers(false)} /> */}
              </DialogTitle>
            </Dialog>
            {/* <ShareModal open={openShare} handleClose={handleShareModalClose} /> */}
          </div>
        ))}
      </div>
    </>
  );
}

export default SharingTextBox;
