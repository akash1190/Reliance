import {
    POST_INTIATIVE_FAILURE,
    POST_INTIATIVE_REQUEST,
    POST_INTIATIVE_SUCCESS,
  } from "../action/types";
  
  const initialState = {
    data: [],
    error: "",
    loading: false,
  };
  
  export const createIntiativeReducer = (state = initialState, action) => {
    switch (action.type) {
      case POST_INTIATIVE_REQUEST:
        return {
          ...state,
          loading: true,
        };
      case POST_INTIATIVE_SUCCESS:
        return {
          data: action.payload,
          loading: false,
        };
      case POST_INTIATIVE_FAILURE:
        return {
          data: [],
          error: action.payload,
          loading: true,
        };
      default:
        return state;
    }
  };
  