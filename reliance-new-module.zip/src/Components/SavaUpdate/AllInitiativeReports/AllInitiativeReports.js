import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import SideMenu from "../../SideMenu/SideMenu";
import first from "../../../asserts/images/1st.png";
import one from "../../../asserts/images/1.jpg";
import two from "../../../asserts/images/4.jpg";
import three from "../../../asserts/images/2.jpg";
import ShareIcon from "@mui/icons-material/Share";
import {
  Card,
  CardContent,
  TextField,
  Typography,
  Button,
  CardMedia,
  Breadcrumbs,
  Grid,
  capitalize,
  Dialog,
  DialogTitle,
  IconButton
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import Share from "../../ReusableComponents.js/Share";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import CreateInitiativeReportDialog from "./createInitiativeReportDialog.js";
import InitiativeDetails from "./initiativeDetails";
import { useLocation, useNavigate } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import Moment from "moment";
import {
  getIntiativesReportByIdList,
  getIntiativesReportByInitiativeIdAndMpId,
} from "../../../store/action/ongoingSevaInitiativesList";
import { getMpProfile } from "../../../store/action/individualMP";

import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import UpdateInitiativeReportDetails from "./UpdateInitiativeReportDialog";
import { useNotificationContext } from "../../../utils/NotificationContext";
import EventDetailsDialog from "./EventDetailsDialog";
import { getIds } from "../../ReusableComponents.js/getIds";

const AllInitiativeReports = () => {
  const dispatch = useDispatch();
  const { showNotification } = useNotificationContext();
  const location = useLocation();
  const [value, setValue] = useState(0);
  const [open, setOpen] = useState(false);
  const [mediaShare, setMediaShare] = useState(false)
  const [shareData, setShareData] = useState({});
  const [compareIdForCreateButton, setCompareIdForCreateButton] = useState(false);
  const [openInitiativeDetailsDialog, setOpenInitiativeDetailsDialog] =
    useState(false);
  const [openUpdateIntiativeDialog, setOpenUpdateInitiativeDialog] =
    useState(false);
  const [personDetails, setPersonDetails] = useState();
  const [openEventDetailsDialog, setOpenEventDetailsDialog] = useState(false);
  const [eventDetailsData, setEventDetailsData] = useState();
  const navigate = useNavigate();
  const ongoingSevaIntiativesReportsList = useSelector(
    (state) => state?.ongoingSevaIntiativesReportsList?.data
  );
  const initiativeReportDetailsByMPIdAndIntiativeId = useSelector(
    (state) => state?.initiativeReportDetailsByMPIdAndIntiativeId?.data
  );
  const ongoingSevaInitiativesList = useSelector(
    (state) => state?.ongoingSevaInitiativesList?.data
  );
  const ongoingSevaInitiativesListByMpId = useSelector(
    (state) => state?.ongoingSevaInitiativesListByMpId?.data
  );
  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  let user = location?.state?.user;
  let initiativeId = location?.state?.initiativeId;
  let initiativeName = location?.state?.initiativeName;
  let readonly = location?.state?.readonly;
  let eventByMpId = location?.state?.eventByMpId;
  let mpName = location?.state?.mpName;
  let mpId = location?.state?.mpId;
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = (reset, setImages, setFiles) => {
    setOpen(false);
    reset();
    setImages([]);
    setFiles([]);
  };

  useEffect(() => {
    //call api to update store
    dispatch(getIntiativesReportByIdList(initiativeId));
    dispatch(getMpProfile(getIds()));

  }, []);

  useEffect(() => {
    const reportArray = ongoingSevaIntiativesReportsList[0]?.reportdata;
    for (let i = 0; i < reportArray?.length; i++) {
      if (reportArray[i]?.userId === mpProfileData?.id) {
        setCompareIdForCreateButton(true);
        return;
      }
      else if (reportArray[i]?.userId !== mpProfileData?.id) {
        setCompareIdForCreateButton(false);
      }
    }
  }, [ongoingSevaIntiativesReportsList])

  const handleOpenInitiativeDetails = async (item) => {
    try {
      const response = await dispatch(getIntiativesReportByInitiativeIdAndMpId(item?.initiativeId, item?.userId));
      if (response.status === 200 || response.status === 201) {
        if (response.data?.message) {
          showNotification("Error", response.data?.message, "error");
        }
        else {
          setPersonDetails(item);
          setOpenInitiativeDetailsDialog(true);
        }
      }
    } catch (error) {
      showNotification("Error", "Failed to fetch");
    }
  };
  const handleCloseInitiativeDetails = () => {
    setOpenInitiativeDetailsDialog(false);
  };

  const handleOpenUpdateInitiativeDetails = async (item) => {
    try {
      const response = await dispatch(getIntiativesReportByInitiativeIdAndMpId(item?.initiativeId, item?.userId));
      if (response.status === 200 || response.status === 201) {
        if (response.data?.message) {
          showNotification("Error", response.data?.message, "error");
        }
        else {
          setPersonDetails(item);
          setOpenUpdateInitiativeDialog(true);
        }
      }
    } catch (error) {
      showNotification("Error", "Failed to fetch");
    }
  };
  const handleCloseUpdateInitiativeDetails = (
    reset,
    reportFiles,
    setUploadFiles
  ) => {
    reset();
    reportFiles([]);
    setUploadFiles([]);
    setOpenUpdateInitiativeDialog(false);
  };

  const onFolderClick = () => {
    navigate("/SevaUpdates", {
      state: {
        user: user,
      },
    });
  };

  const ongoingBreadCrumbClick = () => {
    navigate('/SevaUpdates/viewAllOngoingInitiatives', {
      state: {
        // user: newUser,
        viewAllValue: "Ongoing Seva Initiatives",
        mpName: mpName,
        data: mpId ? ongoingSevaInitiativesListByMpId
          : ongoingSevaInitiativesList,
      }
    });
  }

  const handleOpenEventDetailsDialog = (data) => {
    setEventDetailsData(data);
    setOpenEventDetailsDialog(true);
  };

  const handleCloseEventDetailsDialog = () => {
    setOpenEventDetailsDialog(false);
  };

  const handleShare = (e, data) => {
    e.stopPropagation()
    e.preventDefault()
    setShareData(data)
    setMediaShare(true);
  };

  return (
    <div className="page-wrapper d-flex" style={{ overflowX: "hidden" }}>
      <SideMenu active="Seva" user={user} profileData={mpProfileData} />

      <div className="main-wrapper center-width">
        <div>
          <div className="middle-wrapper">
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h1
                className="page-title mb-0"
                style={{
                  fontSize: "26px",
                  fontWeight: "bold",
                  fontFamily: "HK Grotesk",
                  marginLeft: "38px",
                }}
              >
                Seva aur Samarpan Campaign
              </h1>
              {/* search filter commented below */}
              {/* <div className="search-filter-icon d-flex">
                                {/* <TextField id="outlined-basic" label="Outlined" variant="outlined" sx={{ borderRadius: 50 }}>
                                </TextField> */}
              {/* <a className="d-block mr-1" href="">
                                    <svg className="searchIcon position-absolute" width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.58317 18.6253C4.87484 18.6253 1.0415 14.792 1.0415 10.0837C1.0415 5.37533 4.87484 1.54199 9.58317 1.54199C14.2915 1.54199 18.1248 5.37533 18.1248 10.0837C18.1248 14.792 14.2915 18.6253 9.58317 18.6253ZM9.58317 2.79199C5.55817 2.79199 2.2915 6.06699 2.2915 10.0837C2.2915 14.1003 5.55817 17.3753 9.58317 17.3753C13.6082 17.3753 16.8748 14.1003 16.8748 10.0837C16.8748 6.06699 13.6082 2.79199 9.58317 2.79199Z" fill="#5c819e" />
                                        <path d="M18.3335 19.4585C18.1752 19.4585 18.0169 19.4002 17.8919 19.2752L16.2252 17.6085C15.9835 17.3669 15.9835 16.9669 16.2252 16.7252C16.4669 16.4835 16.8669 16.4835 17.1085 16.7252L18.7752 18.3919C19.0169 18.6335 19.0169 19.0335 18.7752 19.2752C18.6502 19.4002 18.4919 19.4585 18.3335 19.4585Z" fill="#5c819e" />
                                    </svg>
                                </a>
                            </div>  */}
            </div>
            <div>
              <Grid
                container
                sx={{ mb: 1, marginLeft: "30px", marginBottom: "20px" }}
              >
                <Breadcrumbs
                  aria-label="breadcrumb"
                  separator={
                    <NavigateNextIcon
                      fontSize="small"
                      sx={{ marginLeft: "-15px" }}
                    />
                  }
                >
                  <Button
                    underline="hover"
                    style={{
                      color: "#505050",
                      fontWeight: "500",
                      fontSize: "18px",
                      fontWeight: "bold",
                      fontFamily: "HK Grotesk",
                      textTransform: "capitalize",
                    }}
                    onClick={onFolderClick}
                  >
                    Nationwide Seva Updates
                  </Button>
                  <Button
                    underline="hover"
                    style={{
                      color: "#505050",
                      fontWeight: "500",
                      fontSize: "18px",
                      fontWeight: "bold",
                      fontFamily: "HK Grotesk",
                      marginLeft: "-15px",
                      textTransform: "capitalize",
                      // cursor: "auto"
                    }}
                    onClick={ongoingBreadCrumbClick}
                  >
                    Ongoing Seva Initiative
                  </Button>
                  <Button
                    underline="hover"
                    style={{
                      color: "#EC6E29",
                      fontWeight: "600",
                      fontSize: "18px",
                      fontWeight: "bold",
                      fontFamily: "HK Grotesk",
                      marginLeft: "-15px",
                      textTransform: "capitalize",
                      cursor: "auto"
                    }}
                  >
                    {initiativeName && initiativeName}
                  </Button>
                </Breadcrumbs>
              </Grid>
              <h3
                style={{
                  color: "#2C2C2C",
                  fontSize: "22px",
                  fontWeight: "bold",
                  fontFamily: "HK Grotesk",
                  marginLeft: "38px",
                  marginBottom: "20px",
                }}
              >
                <b>Initiative Reports by</b>
              </h3>
            </div>
            {/* <hr className="mt-2 mb-4" /> */}
            <div className="d-flex justify-content-between leaders-cards ">
              <Box
                sx={{
                  flexGrow: 1,
                  minWidth: { xs: 920, sm: 1080 },
                  // bgcolor: 'background.paper',
                }}
              >
                <Tabs
                  value={value}
                  onChange={handleChange}
                  variant="scrollable"
                  scrollButtons
                  aria-label="visible arrows tabs example"
                  TabIndicatorProps={{
                    style: { display: "none" },
                  }}
                  sx={{
                    [`& .${tabsClasses.scrollButtons}`]: {
                      "&.Mui-disabled": { opacity: 0.3 },
                    },
                  }}
                >
                  {ongoingSevaIntiativesReportsList &&
                    ongoingSevaIntiativesReportsList[0]?.reportdata?.map(
                      (item) => (
                        <Card
                          sx={{ minWidth: 305, mr: 2, borderRadius: "20px" }}
                          className="bshadow cursorshow"
                          onClick={() =>
                            mpProfileData?.id === item?.userId && (user !== "Admin" && user !== "Leader")
                              ? handleOpenUpdateInitiativeDetails(item)
                              : handleOpenInitiativeDetails(item)
                          }
                        >
                          <CardContent>
                            {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                            {item?.user?.user_avatar ? (
                              <div className="text-center pt-3"> 
                                <img
                                  src={item?.user?.user_avatar}
                                  className="img-circle leader-circle-img mr-1 circularimage"
                                  width="80"
                                />
                              </div>
                            ) : (<AccountCircleIcon
                                sx={{
                                  fontSize: "xx-large",
                                  width: "80px",
                                  height: "80px",
                                  position: "relative",
                                  left: "37%",
                                }}
                              />                              
                              
                            )}
                            <div className="card-content">
                              <h2
                                style={{
                                  color: "#356F92",
                                  fontSize: "18px",
                                  fontWeight: "bold",
                                  fontFamily: "HK Grotesk",
                                }}
                              >
                                {item?.user?.user_name}
                              </h2>
                              <span
                                className="initial"
                                style={{
                                  color: "#11243D",
                                  fontSize: "12px",
                                  fontWeight: "bold",
                                  fontFamily: "HK Grotesk",
                                }}
                              >
                                {item?.user?.house}
                              </span>
                              <br />
                              <span
                                className="constituency"
                                style={{
                                  color: "#707A89",
                                  fontSize: "12px",
                                  fontWeight: "bold",
                                  fontFamily: "HK Grotesk",
                                }}
                              >
                                Constituency:
                                {item?.user?.constituency_name
                                  ? item?.user?.constituency_name
                                  : " -"}
                              </span>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    )}
                </Tabs>
              </Box>
            </div>
            <div className="mt-4">
              <h3
                style={{
                  color: "#2C2C2C",
                  fontSize: "20px",
                  fontWeight: "bold",
                  fontFamily: "HK Grotesk",
                  marginLeft: "38px",
                  marginBottom: "20px",
                }}
              >
                <b>Events under this Initiative</b>
              </h3>
            </div>
            <div className="d-flex justify-content-between leaders-cards">
              <Box
                sx={{
                  flexGrow: 1,
                  minWidth: { xs: 920, sm: 1080 },
                  // bgcolor: 'background.paper',
                }}
              >
                <Tabs
                  value={value}
                  onChange={handleChange}
                  variant="scrollable"
                  scrollButtons
                  aria-label="visible arrows tabs example"
                  TabIndicatorProps={{
                    style: { display: "none" },
                  }}
                  sx={{
                    [`& .${tabsClasses.scrollButtons}`]: {
                      "&.Mui-disabled": { opacity: 0.3 },
                    },
                  }}
                >
                  {ongoingSevaIntiativesReportsList &&
                    ongoingSevaIntiativesReportsList[0]?.Eventdata?.map(
                      (item, index) => (
                        <Card
                          className="cursorshow"
                          sx={{
                            minWidth: 235,
                            mr: 3,
                            mb: 3,
                            borderRadius: "15px",
                          }}
                          onClick={() => handleOpenEventDetailsDialog(item)}
                        >
                          <div style={{ position: "relative" }}>
                            <ShareIcon className='shareicone3' key={index} onClick={(e) => {
                              handleShare(e, item)
                            }} />
                            <CardMedia
                              sx={{
                                filter: "brightness(50%)",
                                maxWidth: "275px!important"
                              }}
                              id={index}
                              component="img"
                              loading="lazy"
                              height="150"
                              onError={(e) => (e.target.src = NoImageFound)}
                              src={item?.coverimage && JSON.parse(item?.coverimage)[0]}
                              alt="new Image"
                              className="blackoverlay"
                            />


                            <CardContent sx={{ minHeight: "180px", maxHeight: "180px" }} >
                              <div
                                style={{
                                  fontSize: "16px",
                                  fontWeight: "bold",
                                  fontFamily: "HK Grotesk",
                                  color: "#505050",
                                  marginLeft: "5px",
                                  // marginTop: "10px",
                                  width: "235px",
                                  overflow: "hidden",
                                  textOverflow: "ellipsis"
                                }}
                              >
                                {" "}
                                {item?.eventTitle}
                              </div>
                              <div
                                style={{
                                  fontSize: "12px",
                                  fontWeight: "500",
                                  fontFamily: "HK Grotesk",
                                  color: "#505050",
                                  marginLeft: "5px",
                                  marginTop: "4px",
                                }}
                              >
                                Date:{" "}
                                {Moment(item?.startDate).format("DD/MM/YYYY")}
                              </div>

                              <hr style={{ width: "95%" }}></hr>
                              <div style={{ display: "flex", marginLeft: "-15px" }}>
                                {item?.user?.user_avatar ? (
                                 <div className="text-center pt-3">
                                    <img
                                      src={item?.user?.user_avatar}
                                      className="img-circle leader-circle-img mr-1 circularimage2"
                                      width="40"
                                      style={{
                                        marginLeft: "15px",
                                        marginTop: "-14px",
                                        marginBottom: "5px",
                                      }}
                                    />
                                  </div>
                                ) : ( <AccountCircleIcon
                                    sx={{
                                      fontSize: "xx-large",
                                      width: "50px",
                                      height: "auto",
                                      border:0
                                    }}
                                  />
                                  
                                )}
                                <div>
                                  <div
                                    style={{
                                      fontSize: "14px",
                                      fontWeight: "bold",
                                      fontFamily: "HK Grotesk",
                                      color: "#356F92",
                                      marginLeft: "10px",
                                    }}
                                  >
                                    {item?.user?.user_name}
                                  </div>
                                  <div
                                    style={{
                                      fontSize: "12px",
                                      fontWeight: "500",
                                      fontFamily: "HK Grotesk",
                                      color: "#797979",
                                      marginLeft: "10px",
                                    }}
                                  >
                                    {item?.user?.designation}
                                  </div>
                                  <div
                                    style={{
                                      fontSize: "12px",
                                      fontWeight: "500",
                                      fontFamily: "HK Grotesk",
                                      color: "#797979",
                                      marginLeft: "10px",
                                    }}
                                    title={
                                      item?.user?.party ? item?.user?.party : ""
                                    }
                                  >
                                    {(item?.user?.party &&
                                      item?.user?.party.slice(0, 24)) ||
                                      "-"}
                                    {item?.user?.party &&
                                      item?.user?.party.length > 24
                                      ? "..."
                                      : ""}
                                  </div>
                                  <div
                                    style={{
                                      fontSize: "12px",
                                      fontWeight: "500",
                                      fontFamily: "HK Grotesk",
                                      color: "#797979",
                                      marginLeft: "10px",
                                      marginBottom: "15px",
                                    }}
                                  >
                                    {item?.user?.state_name}
                                  </div>
                                </div>
                              </div>
                              {/* <div className="text-center pt-3"><img src={item.user_avatar} className="img-circle leader-circle-img mr-1" width="70" /></div> */}
                            </CardContent ></div>

                        </Card>
                      )
                    )}
                </Tabs>
              </Box>
            </div>
            {!readonly && user !== "Admin" && !compareIdForCreateButton && (
              <Card
                className="bshadow-1"
                sx={{
                  display: "inline-block",
                  marginLeft: "38px",
                  marginTop: "30px",
                  borderRadius: "24px",
                  background: "#f5eeed",
                }}
              >
                <CardContent>
                  <div style={{ display: "flex" }}>
                    <div>
                      <Typography
                        component="div"
                        sx={{
                          fontSize: "24px",
                          fontWeight: "bold",
                          fontFamily: "HK Grotesk",
                          color: "#505050",
                          marginLeft: "15px",
                        }}
                      >
                        Create an initiative report
                      </Typography>

                      <Typography
                        variant="subtitle1"
                        color="text.secondary"
                        component="div"
                        sx={{
                          fontSize: "20px",
                          fontFamily: "HK Grotesk",
                          color: "#505050",
                          marginLeft: "15px",
                        }}
                      >
                        Have you taken part in this initiative? Add the details
                        here
                      </Typography>
                    </div>
                    <div style={{ marginLeft: "15px", marginTop: "5px" }}>
                      <Button
                        className="button-tr1-admin-big"
                        endIcon={<BorderColorIcon sx={{ mt: 1.5 }} />}
                        onClick={handleClickOpen}
                      >
                        Create New
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          <div style={{ display: "none" }}>
            <CreateInitiativeReportDialog
              open={open}
              handleClose={handleClose}
              initiativeName={initiativeName}
              initiativeId={initiativeId}
            />
            <InitiativeDetails
              handleCloseInitiativeDetails={handleCloseInitiativeDetails}
              openInitiativeDetailsDialog={openInitiativeDetailsDialog}
              details={personDetails}
              uniqueInitiativeClick={true}
              initiativeName={initiativeName}
              mpProfileData={mpProfileData}
              initiativeReportDetailsByMPIdAndIntiativeId={
                initiativeReportDetailsByMPIdAndIntiativeId
              }
              user={user}
            />
            {openUpdateIntiativeDialog && (
              <UpdateInitiativeReportDetails
                handleCloseUpdateInitiativeDetails={
                  handleCloseUpdateInitiativeDetails
                }
                openUpdateIntiativeDialog={openUpdateIntiativeDialog}
                details={personDetails}
                initiativeName={initiativeName}
                initiativeReportDetailsByMPIdAndIntiativeId={
                  initiativeReportDetailsByMPIdAndIntiativeId
                }
                allInitiativeReportsPage={true}
              />
            )}
            {openEventDetailsDialog && (<EventDetailsDialog
              openEventDetailsDialog={openEventDetailsDialog}
              handleCloseEventDetailsDialog={handleCloseEventDetailsDialog}
              details={eventDetailsData}
              mpProfileData={mpProfileData}
              eventByMpId={eventByMpId}
              initiativeId={initiativeId}
              user={user}
            />)}
          </div>
          <Dialog open={mediaShare} onClose={() => setMediaShare(false)}>
            <DialogTitle>
              <IconButton
                aria-label="close"
                onClick={() => setMediaShare(false)}
                sx={{
                  position: "absolute",
                  right: 8,
                  top: 8,
                  color: (theme) => theme.palette.grey[500],
                  border: "1px solid #9e9e9e",
                  borderRadius: "50%",
                  padding: "2px",
                  cursor: "pointer",
                }}
              >
                <CloseIcon />
              </IconButton>
              <Typography
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  color: "#357092",
                  fontFamily: "HK Grotesk",
                  fontSize: "26px",
                  fontWeight: "bold",
                }}
              >
                Share to Social Media
              </Typography>

              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  marginTop: "25px",
                  gap: "40px",
                }}
              >
                <Share data={shareData} title={"Ongoing Seva Initiatives"} initiativeReport={true} />

              </div>
              {/* <CloseIcon onClick={() => setAddMembers(false)} /> */}
            </DialogTitle>
          </Dialog>
        </div>
      </div>
    </div>
  );
};
export default AllInitiativeReports;
