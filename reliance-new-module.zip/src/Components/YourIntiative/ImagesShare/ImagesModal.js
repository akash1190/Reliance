import {
  Breadcrumbs,
  Button,
  Dialog,
  Divider,
  Grid,
  Hidden,
  IconButton,
  ImageList,
  ImageListItem,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router";
import ItemData from "./itemData";
import LanguageData from "./LanguageData";
import ImagesFolder from "./ImagesFolder";
import close from "../../../asserts/images/sharing/Close.svg";
import groupIcon from "../../../asserts/images/sharing/Illustration.svg";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";
import { saveAs } from "file-saver";
import "./Share.css";
import { useSelector } from "react-redux";
import { ImageLoader } from "../../ReusableComponents.js/ImageLoader";
import DownloadScore from "../../ReusableComponents.js/DownloadScore";

const ImagesModal = ({ open, setOpen }) => {
  const [folderName, setFolderName] = useState();
  const [languageName, setLanguageName] = useState();
  const [viewImage, setViewImage] = useState("");
  const [allImages, setAllImages] = useState([]);
  const imagetemplates = useSelector(
    (state) =>
      state?.socialMediaKit?.data !== [] &&
      state?.socialMediaKit?.data?.imagetemplates
  );
  const [imageResponse, setImageResponse] = useState([]);

  const handleClose = () => {
    setOpen(false);
  };
  const navigate = useNavigate();

  const onFolderClick = () => {
    setLanguageName("");
    setViewImage("");
    navigate(
      <ItemData folderName={folderName} imageResponse={imageResponse} />
    );
  };

  const onImagesLink = () => {
    setFolderName("");
    setViewImage("");
    setLanguageName("");
  };
  useEffect(() => {
    setImageResponse(imagetemplates && imagetemplates);
    setFolderName("");
    setViewImage("");
    setLanguageName("");
  }, [imagetemplates]);

  const downloadAllImg = () => {
    allImages.forEach((data) => {
      saveAs(data, "images.jpg");
    });
    DownloadScore(allImages.length);
  };

  const downloadImg = () => {
    saveAs(viewImage, "image.jpg");
    DownloadScore(1);
    // saveAs(NoImageFound, "noImage.jpg");
  };

  return (
    <Dialog disableEscapeKeyDown open={open} onClose={handleClose}
    sx={{
      "& .MuiDialog-container": {
        "& .MuiPaper-root": {
          width: "100%",
          maxWidth: "70%",
          minWidth: "70%",
          minHeight: "90%", // Set your width here
        },
      },
    }}>
      <img
        src={close}
        className="cancel-icon cursorshow"
        onClick={handleClose}
      />
      <div className="DialogBox" style={{ padding: "25px", height: "95vh" }}>
        <Typography
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2e739c",
            fontWeight: "700",
            fontSize: "20px",
            mt: 1,
            ml: 1
          }}
        >
          {folderName == "Certificate" ? "Certificate" : "Images"}
        </Typography>
        <Typography
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontWeight: "700",
            fontSize: "16px",
            ml: 1
          }}
        >
          {folderName == "Certificate"
            ? "Select and download the certificate."
            : "Select and download the Images for social media & outdoor banners from the below directory."}
        </Typography>
        <hr style={{ border: "1px solid #356F92", width: "98%" }}></hr>
        <Breadcrumbs
          aria-label="breadcrumb"
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontWeight: "700",
            fontSize: "16px",
            mt: 1,
          }}
        >
          <Link
            underline="hover"
            className="custom-link"
            href="/"
            onClick={onImagesLink}
          >
            Images
          </Link>
          {folderName && (
            <Link onClick={onFolderClick} href="/">
              {folderName && folderName}
            </Link>
          )}
          {languageName && <Link>{languageName && languageName}</Link>}
        </Breadcrumbs>
        <div style={{ marginTop: "10px", marginLeft: "10px" }}>
          <Grid container spacing={2}>
            <Grid
              item
              xs={3}
              md={5}
              margin="12px"
              sx={{ backgroundColor: "#f5f6fa", borderRadius: "20px",  minHeight: "70vh", }}
            >
              {" "}
              {!folderName ? (
                <ItemData
                  setFolderName={setFolderName}
                  imageResponse={imageResponse}
                />
              ) : folderName && languageName ? (
                <ImagesFolder
                  imageResponse={imageResponse}
                  languageData={languageName}
                  setViewImage={setViewImage}
                  folderName={folderName}
                  setAllImages={setAllImages}
                />
              ) : (
                <LanguageData
                  setLanguageName={setLanguageName}
                  imageResponse={imageResponse}
                  folderName={folderName}
                />
              )}
            </Grid>
            <Grid
              item
              xs={9}
              md={6}
              margin="15px"
              padding="15px"
              sx={{
                backgroundColor: "#fff",
                border: "1px solid #DDDDDD",
                borderRadius: "20px",
              }}
            >
              {viewImage ? (
                <>
                  <div>
                    <ImageLoader
                      src={`${viewImage}`}//?w=164&h=164&fit=crop&auto=format
                      srcSet={`${viewImage}`}//w=164&h=164&fit=crop&auto=format&dpr=2 2x
                      width={"100%"}
                      loading="lazy"
                    />
                    {/* <img
                      src={`${viewImage}?w=164&h=164&fit=crop&auto=format`}
                      // src={`${NoImageFound}?w=164&h=164&fit=crop&auto=format`}
                      srcSet={`${viewImage}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                      // alt={viewImage.subTitle}
                      loading="lazy"
                      width={"100%"}
                    /> */}
                    <div style={{ display: "flex", justifyContent: "center" }}>
                      <Button className="button-tr-2" onClick={downloadImg}>
                        Download
                      </Button>
                      <Button
                        className="button-tr-citizen-cancel"
                        onClick={downloadAllImg}
                      >
                        Download All
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="imagemodalfilemana">
                    <img src={groupIcon} />
                    <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        color: "#2e739c",
                        fontWeight: "700",
                        fontSize: "20px",
                        mt: 1,
                      }}
                    >
                      Select an Item to download
                    </Typography>
                    <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        color: "#2C2C2C",
                        fontWeight: "700",
                        fontSize: "16px",
                      }}
                    >
                      Nothing is selected
                    </Typography>
                  </div>
                </>
              )}
            </Grid>
          </Grid>
        </div>
      </div>
    </Dialog>
  );
};

export default ImagesModal;
