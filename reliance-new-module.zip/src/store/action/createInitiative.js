import axios from "axios";
import Constant from "../../utils/constant";
import {
  POST_INTIATIVE_FAILURE,
  POST_INTIATIVE_REQUEST,
  POST_INTIATIVE_SUCCESS,
} from "./types";

export const postIntiativeRequest = () => {
  return {
    type: POST_INTIATIVE_REQUEST,
  };
};
export const postIntiativeSuccess = (value) => {
  return {
    type: POST_INTIATIVE_SUCCESS,
    payload: value,
  };
};
export const postIntiativeFailure = (error) => {
  return {
    type: POST_INTIATIVE_FAILURE,
    payload: error,
  };
};

export const postIntiative = (payload, id) => async (dispatch) => {
  const tkn = localStorage.getItem("tokenDetails");
  dispatch(postIntiativeRequest);
  let iniId = id ? id : 0;
  return axios
    .post(Constant.BASE_URL + `/api/initiative/create/${iniId}`, payload, {
      headers: {
        Authorization: `Bearer ${tkn}`,
      },
    })
    .then((response) => {
      const result = response.data;
      dispatch(postIntiativeSuccess(result));
      return response;
    })
    .catch((error) => {
      const errorMsg = error.message;
      dispatch(postIntiativeFailure(errorMsg));
    });
};
