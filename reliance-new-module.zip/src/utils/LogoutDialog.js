import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import CloseIcon from "@mui/icons-material/Close";
import { IconButton } from "@mui/material";

export default function LogoutDialog(props) {
    const { openLogoutDialog, handleCloseLogoutDialog, setCheckLogoutClick } = props;

    return (
        <div>
            <Dialog
                open={openLogoutDialog}
                onClose={handleCloseLogoutDialog}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                sx={{ maxWidth: "550px", margin: "0 auto" }}

            >
                <IconButton
                    aria-label="close"
                    onClick={handleCloseLogoutDialog}
                    sx={{
                        position: "absolute",
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                        border: "1px solid #9e9e9e",
                        borderRadius: "50%",
                        padding: "2px",
                        cursor: "pointer",
                    }}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent>
                    <DialogContentText sx={{ minHeight: "50px", display: "flex", alignItems: "center", color: "#6C6C6C", fontFamily: 'HK Grotesk', fontSize: "22px", textAlign: "center", fontWeight: "Bold", mt: 2, justifyContent: "center" }}>
                        Logout Of MPs Corner ?
                    </DialogContentText>
                </DialogContent>
                <DialogActions sx={{ justifyContent: "center" }}>
                    <Button className="button-tr-2" sx={{ fontFamily: 'HK Grotesk', ml: 2, width: "180px", mb: 3, height: "44px" }} onClick={() => setCheckLogoutClick(true)}>Logout</Button>
                    <Button className="button-tr-2" sx={{ fontFamily: 'HK Grotesk', ml: 2, width: "180px", mb: 3, height: "44px" }} onClick={handleCloseLogoutDialog}>Cancel</Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}
