import {
  Breadcrumbs,
  Button,
  Dialog,
  Divider,
  Grid,
  Hidden,
  IconButton,
  ImageList,
  ImageListItem,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router";
import ItemData from "./itemData";
import { useSelector } from "react-redux";
import { saveAs } from "file-saver";
// import VideosFolder from "./VideosFolder";
import close from "../../../asserts/images/sharing/Close.svg";
import groupIcon from "../../../asserts/images/sharing/Illustration.svg";
import "../ImagesShare/Share.css";
import LanguageData from "../ImagesShare/LanguageData";
import VideosFolder from "./VideosFolder";
import { VideoLoader } from "../../ReusableComponents.js/VideoLoader";
import DownloadScore from "../../ReusableComponents.js/DownloadScore";

const VideosModal = ({ open, setOpenVideo }) => {
  const [folderName, setFolderName] = useState();
  const [languageName, setLanguageName] = useState();
  const [viewVideo, setViewVideo] = useState("");
  const [videoResponse, setVideoResponse] = useState([]);
  const [allVideos, setAllVideos] = useState([]);
  const videotemplates = useSelector(
    (state) =>
      state?.socialMediaKit?.data !== [] &&
      state?.socialMediaKit?.data?.videotemplates
  );
  const handleClose = () => {
    setOpenVideo(false);
  };
  const navigate = useNavigate();

  const onFolderClick = () => {
    setLanguageName("");
    setViewVideo("");
    navigate(<ItemData />);
  };

  const onVideosLink = () => {
    setFolderName("");
    setViewVideo("");
    setLanguageName("");
  };
  useEffect(() => {
    setVideoResponse(videotemplates && videotemplates);
    setFolderName("");
    setViewVideo("");
    setLanguageName("");
  }, [videotemplates]);

  const downloadVideo = () => {
    saveAs(viewVideo, "video.mp4");
    DownloadScore(1);
  };

  const downloadAllVideo = () => {
    allVideos.forEach((data) => {
      saveAs(data, "video.mp4");
    });
    DownloadScore(allVideos.length);
  };

  return (
    <Dialog
      disableEscapeKeyDown
      open={open}
      onClose={handleClose}
      sx={{
        "& .MuiDialog-container": {
          "& .MuiPaper-root": {
            width: "100%",
            maxWidth: "70%",
            minWidth: "70%",
            minHeight: "90%", // Set your width here
          },
        },
      }}
    >
      <img
        src={close}
        className="cancel-icon cursorshow"
        onClick={handleClose}
      />
      <div style={{ padding: "25px", overflow: "hidden" }}>
        <Typography
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2e739c",
            fontWeight: "700",
            fontSize: "20px",
            mt: 1,
            ml: 1
          }}
        >
          Videos
        </Typography>
        <Typography
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontWeight: "700",
            fontSize: "16px",
            ml:1
          }}
        >
          Select and download the Videos from the below directory.
        </Typography>
        <hr style={{ border: "1px solid #356F92", width: "98%" }}></hr>
        <Breadcrumbs
          aria-label="breadcrumb"
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontWeight: "700",
            fontSize: "16px",
            mt: 1,
          }}
        >
          <Link
            underline="hover"
            className="custom-link"
            href="/"
            onClick={onVideosLink}
          >
            Campaign Videos
          </Link>
          {/* {folderName && (
            <Link onClick={onFolderClick} href="/">
              {folderName && folderName?.title}
            </Link>
          )} */}
          {languageName && <Link>{languageName && languageName}</Link>}
        </Breadcrumbs>
        <div style={{ marginTop: "10px", marginLeft: "10px" }}>
          <Grid container spacing={2}>
            <Grid
              item
              xs={3}
              md={5}
              margin="12px"
              sx={{
                backgroundColor: "#f5f6fa",
                borderRadius: "20px",
                minHeight: "70vh",
              }}
            >
              {/* {!folderName ? (
                <ItemData setFolderName={setFolderName} />
              ) : folderName && languageName ? (
                <VideosFolder
                  videoResponse={videoResponse}
                  languageData={languageName}
                  setViewVideo={setViewVideo}
                  folderName={folderName}
                />
              ) : (
                <LanguageData setLanguageName={setLanguageName} />
              )} */}
              {languageName ? (
                <VideosFolder
                  videoResponse={videoResponse}
                  languageData={languageName}
                  setViewVideo={setViewVideo}
                  folderName={folderName}
                  setAllVideos={setAllVideos}
                />
              ) : (
                <LanguageData
                  setLanguageName={setLanguageName}
                  videoResponse={videoResponse}
                />
              )}
            </Grid>
            <Grid
              item
              xs={9}
              md={6}
              margin="15px"
              sx={{
                backgroundColor: "#fff",
                border: "1px solid #DDDDDD",
                borderRadius: "20px",
              }}
            >
              {viewVideo ? (
                // <>
                //   <img
                //     src={`${viewVideo?.img}?w=164&h=164&fit=crop&auto=format`}
                //     srcSet={`${viewVideo.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                //     alt={viewVideo.subTitle}
                //     loading="lazy"
                //   />
                //   <Button>Download</Button>
                //   <Button>Download All</Button>
                // </>
                <>
                <div style={{textAlign:"center",minHeight:"400px",marginLeft:"-16px"}}>
                  <VideoLoader
                    iframe={true}
                    width="470"
                    height="300"
                    src={
                      viewVideo || "https://www.youtube.com/embed/phIuP8XU9KQ"
                    }
                    allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                  />
                  </div>
                  {/* <iframe
                    width="320"
                    height="300"
                    src={
                      // viewVideo?.video?.replace(
                      //   /[\|&;\$%@"<>[\]\(\)\+,']/g,
                      //   ""
                      // )
                      viewVideo || "https://www.youtube.com/embed/phIuP8XU9KQ"
                    }
                    // title={
                    //   viewVideo.title ||
                    //   "Swachh Bharat Abhiyan- Swachh Bharat ka Irada Kar Liya Hum Ne"
                    // }
                    frameBorder="0"
                    allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                  ></iframe> */}
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      marginBottom: "4px",
                    }}
                  >
                    <Button className="button-tr-2" onClick={downloadVideo}>
                      {" "}
                      <a
                        href={
                          viewVideo.videoUrl ||
                          "https://www.youtube.com/embed/phIuP8XU9KQ"
                        }
                        download
                      ></a>
                      Download
                    </Button>
                    <Button
                      className="button-tr-citizen-cancel"
                      onClick={downloadAllVideo}
                    >
                      Download All
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  <div className="imagemodalfilemana">
                    <img src={groupIcon} />
                    <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        color: "#2e739c",
                        fontWeight: "700",
                        fontSize: "20px",
                        mt: 1,
                      }}
                    >
                      Select an Item to download
                    </Typography>
                    <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        color: "#2C2C2C",
                        fontWeight: "700",
                        fontSize: "16px",
                      }}
                    >
                      Nothing is selected
                    </Typography>
                  </div>
                </>
              )}
            </Grid>
          </Grid>
        </div>
      </div>
    </Dialog>
  );
};

export default VideosModal;
