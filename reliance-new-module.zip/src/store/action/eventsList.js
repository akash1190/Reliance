import axios from "axios"
import Constant from "../../utils/constant"
// import { mpList } from "../../Constants/mpList"
import {
    FETCH_EVENTS_LIST_REQUEST, FETCH_EVENTS_LIST_SUCCESS, FETCH_EVENTS_LIST_FAILURE,
    FETCH_EVENTS_LIST_BY_MP_ID_REQUEST, FETCH_EVENTS_LIST_BY_MP_ID_SUCCESS, FETCH_EVENTS_LIST_BY_MP_ID_FAILURE
} from "./types"

export const fetchEventsListRequest = () => {
    return {
        type: FETCH_EVENTS_LIST_REQUEST
    }
}
export const fetchEventsListSuccess = carMakes => {
    return {
        type: FETCH_EVENTS_LIST_SUCCESS,
        payload: carMakes
    }
}
export const fetchEventsListFailure = error => {
    return {
        type: FETCH_EVENTS_LIST_FAILURE,
        payload: error
    }
}

export const fetchEventsListByMpIdRequest = () => {
    return {
        type: FETCH_EVENTS_LIST_BY_MP_ID_REQUEST
    }
}
export const fetchEventsListByMpIdSuccess = carMakes => {
    return {
        type: FETCH_EVENTS_LIST_BY_MP_ID_SUCCESS,
        payload: carMakes
    }
}
export const fetchEventsListByMpIdFailure = error => {
    return {
        type: FETCH_EVENTS_LIST_BY_MP_ID_FAILURE,
        payload: error
    }
}



export const getEventsList = (id) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchEventsListRequest)
    await axios.get(Constant.BASE_URL + `/api/event/getall/${id ? id : 0}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchEventsListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchEventsListFailure(errorMsg))
        })
}

export const getEventsListByMpId = (mpId) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchEventsListByMpIdRequest)
    await axios.get(Constant.BASE_URL + `/api/getEventDataByMpId/${mpId}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchEventsListByMpIdSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchEventsListByMpIdFailure(errorMsg))
        })
}


