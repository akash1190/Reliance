import React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import editIcon from "../../asserts/images/IconEdit.svg";
import camera from "../../asserts/images/Camera.svg";
import { useDispatch, useSelector } from "react-redux";
import "./reusableIndex.css";
import {
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  CardMedia,
  Grid,
  Icon,
  Typography,
} from "@mui/material";
import { updateMpProfile } from "../../store/action/individualMP";
import { getMpProfile } from "../../store/action/individualMP";
import { useState } from "react";
import { useLoading } from "../../utils/LoadingContext";
import { useNotificationContext } from "../../utils/NotificationContext";

export default function ProfileEdit({ setOpen, mpDetail, open }) {
  const { setLoading } = useLoading();
  const { showNotification } = useNotificationContext();
  const hiddenFileInput = React.useRef(null);
  const hiddenCoverInput = React.useRef(null);
  const [profilePic, setProfilePic] = useState("");
  const [coverPic, setCoverPic] = useState("");
  const [profilePicF, setProfilePicForm] = React.useState("");
  const [coverPicF, setCoverPicForm] = React.useState("");
  const [onProfileEditClick, setOnProfileEditClick] = React.useState(false);
  const [onCoverEditClick, setOnCoverEditClick] = React.useState(false);
  const dispatch = useDispatch();
  const fileFormats = ["image/png", "image/jpeg", "image/jpg"];

  React.useEffect(() => {
    setProfilePic(mpDetail.user_avatar);
    setCoverPic(mpDetail.coverimage);
  }, [mpDetail]);
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClick = (e) => {
    // setOnProfileEditClick(true);
    hiddenFileInput.current.click();
  };
  const handleCoverClick = (e) => {
    // setOnCoverEditClick(true);
    hiddenCoverInput.current.click();
  };
  const handleImageChange = (e, data) => {
    const uploadedFiles = e.target.files;

    let newImages = [];
    for (let i = 0; i < uploadedFiles.length; i++) {
      const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
        newImages.push({ url: reader.result });
        if (i === uploadedFiles.length - 1) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          if (data === "cover") {
            setCoverPic(newImages[0].url);
            setCoverPicForm(uploadedFiles);
          } else {
            setProfilePic(newImages[0].url);
            setProfilePicForm(uploadedFiles);
          }
        }
      };
    }
  };

  const handleClose = async (reason) => {
    var formData = new FormData();
    formData.append("user_name", mpDetail.user_name);
    formData.append("user_screen_name", mpDetail.user_screen_name);
    formData.append("house", mpDetail.house);
    formData.append("user_points", mpDetail.user_points);
    formData.append("user_contact", mpDetail.user_contact);
    formData.append("constituency_name", mpDetail.constituency_name);
    formData.append("state_name", mpDetail.state_name);
    // profilePic && formData.append("profileimage", profilePic);
    profilePicF &&
      Array.from(profilePicF).forEach((file) =>
        formData.append(`profileimage`, file, file.name)
      );
    coverPicF &&
      Array.from(coverPicF).forEach((file) =>
        formData.append(`coverimage`, file, file.name)
      );
    const tkn = localStorage.getItem("tokenDetails");

    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${tkn}`,
      },
    };

    if (reason === "update") {
      try {
        setLoading(true);
        const response = await dispatch(
          updateMpProfile(formData, mpDetail.id, config)
        );
        if (response.status === 200 || response.status === 201) {
          dispatch(getMpProfile(mpDetail.id));
          showNotification("Success", response.data.message, "success");
        }
      } catch (error) {
        showNotification("Error", "Failed to fetch");
      } finally {
        setLoading(false);
      }
    }
    setOpen(false);
  };
  return (
    <div>
      <Dialog disableEscapeKeyDown open={open} onClose={handleClose}>
        <Grid textAlign="center">
          <input
            type="file"
            ref={hiddenCoverInput}
            style={{ display: "none" }}
            onChange={(e) => { 
              setOnCoverEditClick(true)
              handleImageChange(e, "cover");
            }}
            accept="image/png, image/jpeg, image/jpg"
          />
          <input
            type="file"
            ref={hiddenFileInput}
            style={{ display: "none" }}
            onChange={(e) => {
              setOnProfileEditClick(true)
              handleImageChange(e)}
            }
            accept="image/png, image/jpeg, image/jpg"
          />

          <Card>
            <img
              src={profilePic ? profilePic : mpDetail.user_avatar}
              alt={mpDetail.user_name}
              className="card-image"
            />
            <img
              src={editIcon}
              alt={mpDetail.user_name}
              className=" card-icon-edit-big"
              onClick={handleClick}
            />
            <Button
              variant="contained"
              sx={{
                textTransform: "capitalize",
                color: "#11243D!important",
                fontSize: "16px",
                fontFamily: "HK Grotesk",
              }}
              onClick={handleCoverClick}
              className="cover-edit"
              startIcon={<img height="inherit" src={camera} />}
            >
              Edit cover photo
            </Button>
            {/* {mpDetail.coverimage ? */}
            <div style={{ minHeight: "333px" }}>
              <img
                src={coverPic ? coverPic : mpDetail.coverimage}
                alt={mpDetail.user_name}
                height="333px"
                className='bigcoverimage'
                style={{minHeight:"300px"}}
              />
              <img
                src={editIcon}
                alt={mpDetail.user_name}
                className=" card-icon-edit-big cursorshow"
                onClick={handleClick}
              />
              <Button
                variant="contained"
                sx={{
                  textTransform: "capitalize",
                  color: "#11243D!important",
                  fontSize: "16px",
                  fontFamily: "HK Grotesk",
                }}
                onClick={handleCoverClick}
                className="cover-edit"
                startIcon={<img height="inherit" src={camera} />}
              >
                Edit cover photo
              </Button>
              {/* {mpDetail.coverimage ? */}
              {/* <Box  sx={{ backgroundColor: '#DFF6FF'}} height="333" />} */}
              <CardContent
                alignItems="center"
                justify="center"
                sx={{ marginTop: "150px" }}
              >
                <Typography
                  gutterBottom
                  variant="h5"
                  component="div"
                  sx={{
                    color: "#357092",
                    fontWeight: "Bold",
                    fontFamily: "HK Grotesk",
                    fontSize: "30px",
                  }}
                >
                  {mpDetail.user_name}
                </Typography>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{
                    color: "#11243D",
                    fontWeight: "Bold",
                    fontFamily: "HK Grotesk",
                    fontSize: "18px",
                  }}
                >
                  {mpDetail.designation} -{mpDetail.party},<br />
                  {mpDetail.state_name}
                </Typography>
              </CardContent>
              <hr style={{ width: "90%" }}></hr>
              <CardActions sx={{ justifyContent: "center" }}>
                <Button
                  variant="contained"
                  sx={{
                    width: "140px",
                    fontFamily: "HK Grotesk",
                    fontSize: "13px",
                    color: "#fff",
                    backgroundColor: "#ef7d3f",
                    border: "1px solid #ef7d3f00",
                    borderRadius: "45px",
                    boxShadow: " 0px 8px 15px rgb(0 0 0 / 10%)",
                    marginTop: "10px",
                  }}
                  onClick={() => {
                    handleClose("update");
                  }}
                  disabled={
                    !onProfileEditClick && !onCoverEditClick ? true : false
                  }
                >
                  UPDATE
                </Button>
                <Button
                  className="button-tr-citizen-cancel"
                  sx={{ border: "1px blue solid" }}
                  onClick={() => {
                    handleClose();
                  }}
                >
                  CANCEL
                </Button>
              </CardActions>
            </div>
          </Card>
        </Grid>
      </Dialog>
    </div>
  );
}
