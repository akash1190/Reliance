import React, { useState, useRef, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import {
  Select,
  MenuItem,
  Button,
  TextField,
  Grid,
  Box,
  FormControl,
  InputLabel,
  Card,
  CardContent,
  Paper,
  IconButton,
  FormHelperText,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import UploadIcon from "@mui/icons-material/Upload";
import CloseIcon from "@mui/icons-material/Close";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";
import { postCreateInitiativeReportBy } from "../../../store/action/createInitiativeReportBy";
import { getMpProfile } from "../../../store/action/individualMP";
import closeIconp from "../../../asserts/images/close.png";
import { getIntiativesReportByIdList } from "../../../store/action/ongoingSevaInitiativesList";
import { getIds } from "../../ReusableComponents.js/getIds";
import { validateNotEmpty } from "../../ReusableComponents.js/reuseMethods";
import "./dialogStyle.css";

const CreateInitiativeReportDialog = ({
  handleClose,
  open,
  initiativeName,
  initiativeId,
  setCheckInitiativeStatus,
  insideYourInitiative,
}) => {
  const [images, setImages] = useState([]);
  const [files, setFiles] = useState([]);
  const { setLoading } = useLoading();
  const dispatch = useDispatch();
  const { showNotification } = useNotificationContext();
  const [checkImages, setCheckImages] = useState(false);
  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  const fileFormats = ["image/png", "image/jpeg", "image/jpg"];

  // const [value, setValue] = useState(0);
  useEffect(() => {
    //call api to update store
    dispatch(getMpProfile(getIds()));
  }, []);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();

  const hiddenFileInput = useRef(null);

  const onSubmit = async (data) => {
    if (images.length === 0) return;
    setLoading(true);
    const tkn = localStorage.getItem("tokenDetails");
    const formData = new FormData();
    formData.append("participant", data?.participants);
    formData.append("desc", data?.desc);
    formData.append("initiativeId", initiativeId);
    formData.append("mpmodelId", mpProfileData?.id);
    Array.from(files).forEach((file) =>
      formData.append(`media`, file, file.name)
    );
    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${tkn}`,
      },
    };
    try {
      const response = await dispatch(
        postCreateInitiativeReportBy(0, formData, config, showNotification)
      );
      if (response.status === 200 || response.status === 201) {
        showNotification("Success", response.data.message, "success");
        if (insideYourInitiative) {
          setCheckInitiativeStatus(true);
        }
        handleClose(reset, setImages, setFiles);
        dispatch(getIntiativesReportByIdList(initiativeId));
        // Object.keys(data).map(val => resetField(val));
        // setFiles([]);
        // setUploadFiles([]);
      }
    } catch (error) {
      showNotification("Error", "Failed to fetch");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (index) => {
    const tempImages = [...images];
    tempImages.splice(index, 1);
    setImages(tempImages);
  };

  // const handleImageChange = (e) => {
  //     const uploadedFiles = e.target.files;
  //     setFiles([...files, ...uploadedFiles]);
  //     let newImages = [];
  //     for (let i = 0; i < uploadedFiles.length; i++) {
  //         const reader = new FileReader();
  //         reader.readAsDataURL(uploadedFiles[i]);
  //         reader.onload = () => {
  //             newImages.push({ url: reader.result, file: uploadedFiles[i] });
  //             if (i === uploadedFiles.length - 1) {
  //                 setImages([...images, ...newImages]);
  //             }
  //         };
  //     }
  // };

  const handleImageChange = (e) => {
    const uploadedFiles = e.target.files;
    setFiles([...files, ...uploadedFiles]);
    let newFiles = [];
    for (let i = 0; i < uploadedFiles.length; i++) {
      const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
        if (uploadedFiles[i].type.startsWith("image")) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          newFiles.push({
            type: "image",
            url: reader.result,
            file: uploadedFiles[i],
          });
        } else if (uploadedFiles[i].type.startsWith("video")) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          newFiles.push({
            type: "video",
            url: reader.result,
            file: uploadedFiles[i],
          });
        } else {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
        }
        if (i === uploadedFiles.length - 1) {
          setImages([...newFiles, ...images]);
        }
      };
    }
  };

  const handlePreview = (file) => {
    if (file.type === "image") {
      return (
        <img
          src={typeof file === "string" ? file : file.url}
          alt="Preview"
          className="form-img__img-preview-ed-ne"
        />
      );
    } else if (file.type === "video") {
      return (
        <video controls className="form-img__img-preview-ed-ne">
          <source src={typeof file === "string" ? file : file.url} />
          Your browser does not support the video tag.
        </video>
      );
    }
  };

  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };

  const blockInvalidChar = (e) => {
    if (["e", "E", "+", "-", "."].includes(e.key) || e.keyCode === 40) {
      e.preventDefault();
    }
    if (e.keyCode === 40) {
      // 40 is the key code for down arrow
      const currentValue = e.target.value;
      if (currentValue > 1) {
        e.target.value = Number(currentValue) - 1;
      }
      e.preventDefault();
    }
  };

  const onPasteCLick = (e) => {
    var clipboardData = e.clipboardData.getData("text");
    var cleanedData = clipboardData.replace(/[-e]/gi, "");
    if (cleanedData.length === 0) {
      e.preventDefault();
    } else {
      document.execCommand("insertText", false, cleanedData);
      e.preventDefault();
    }
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={() => handleClose(reset, setImages, setFiles)}
      >
        <DialogTitle>
          <Box sx={{ display: "flex", justifyContent: "center" }}>
            <IconButton
              aria-label="close"
              onClick={() => handleClose(reset, setImages, setFiles)}
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
                border: "1px solid #9e9e9e",
                borderRadius: "50%",
                padding: "2px",
                cursor: "pointer",
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <div>
              <b
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#2C2C2C",
                  fontSize: "20px",
                  fontWeight: "bold",
                }}
              >
                Create Initiative Report For{" "}
              </b>
            </div>
            <div>
              <b
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "26px",
                  fontWeight: "bold",
                }}
              >
                {initiativeName && initiativeName}
              </b>
            </div>
          </div>
        </DialogTitle>
        <Grid container className="bg-white">
          <Grid item xs={12} md={12}>
            <Grid item xs={12} md={12} sx={{ p: 4 }}>
              <Box>
                <form>
                  <Grid
                    container
                    spacing={1}
                    justifyContent="left"
                    alignItems="center"
                  >
                    <Grid container sx={{ mb: 2 }}>
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <b
                          style={{
                            fontFamily: "HK Grotesk",
                            color: "#357092",
                            fontSize: "16px",
                            fontWeight: "bold",
                            marginLeft: "5px",
                            marginBottom: "2px",
                          }}
                        >
                          Participants
                        </b>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <TextField
                            className="stepperFormInput partic"
                            name="participants"
                            fullWidth
                            placeholder="Enter participants count"
                            size="small"
                            required
                            type="number"
                            autoComplete="off"
                            {...register("participants", {
                              required:
                                "Please enter the count of participants",
                              maxLength: {
                                value: 10,
                                message:
                                  "Maximum number of participants is a 10 digit number",
                              },
                              validate: (value) => {
                                if (value === "0") {
                                  return "Participants count cannot be 0";
                                } else if (/^0+$/.test(value)) {
                                  return "Participants count cannot be 0";
                                }
                                return true;
                              },
                            })}
                            onKeyDown={blockInvalidChar}
                            onPaste={onPasteCLick}
                            onWheel={(e) => {
                              e.target.blur();
                              e.stopPropagation();
                            }}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.participants?.message}
                        </FormHelperText>
                      </Grid>
                    </Grid>
                    <Grid container sx={{ mb: 2, mt: 1 }}>
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <b
                          style={{
                            fontFamily: "HK Grotesk",
                            color: "#357092",
                            fontSize: "16px",
                            fontWeight: "bold",
                            marginLeft: "5px",
                            marginBottom: "2px",
                          }}
                        >
                          Initiative Description
                        </b>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <TextField
                            className="stepperFormInput"
                            name="desc"
                            placeholder="Enter Initiative Description"
                            fullWidth
                            required
                            inputProps={{
                              maxLength: 1000,
                            }}
                            multiline
                            rows={3}
                            size="small"
                            autoComplete="off"
                            {...register("desc", {
                              required:
                                "Please enter the Initiative description",
                              maxLength: {
                                value: 1000,
                                message: "Maximum character length is 1000",
                              },
                              validate: (value) =>
                                validateNotEmpty(
                                  value,
                                  "the Initiative description"
                                ),
                            })}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.desc?.message}
                        </FormHelperText>
                      </Grid>
                    </Grid>
                    <div
                      style={{
                        fontFamily: "HK Grotesk",
                        color: "#357092",
                        fontSize: "16px",
                        fontWeight: "bold",
                        marginLeft: "5px",
                        marginBottom: "2px",
                      }}
                    >
                      <b> Upload Event Images</b>
                    </div>
                    <Grid container>
                      <div
                        // className="contpopup1"
                        style={{
                          // flexDirection: "row-reverse",
                          // marginLeft: "5px",
                          display: "flex",
                        }}
                      >
                        {/* {images.length > 0 ? ( */}
                        {/* <Grid item xs={6} sx={{ width: "80%" }}> */}
                        <div
                          style={{ top: "0px" }} // style={{ width: "470px", top: "0px" }}
                          className={`itemfixed-update-1-ini-less ${
                            images.length > 1 ? "itemfixed-update-1-ini " : ""
                          }`}
                        >
                          {images.length > 1 ? (
                            <Tabs
                              variant="scrollable"
                              scrollButtons
                              aria-label="visible arrows tabs example"
                              sx={{
                                [`& .${tabsClasses.scrollButtons}`]: {
                                  "&.Mui-disabled": { opacity: 0.3 },
                                  mt: "30px",
                                },
                              }}
                            >
                              {images.map((image, index) => (
                                <Card
                                  sx={{
                                    minWidth: 205,
                                    borderRadius: 0,
                                    boxShadow: "none",
                                  }}
                                  className="form-img__img-preview-ed-ne imageCard"
                                >
                                  <CardContent>
                                    <div key={index}>
                                      {handlePreview(image)}
                                    </div>
                                    {/* <img key={index} src={image.url} alt="Preview" className="form-img__img-preview" /> */}
                                    {/* <Button onClick={() => handleDelete(index)}>delete</Button> */}
                                    <img
                                      src={closeIconp}
                                      onClick={() => handleDelete(index)}
                                      className="imageclose-2-cird"
                                    />
                                  </CardContent>
                                </Card>
                              ))}
                            </Tabs>
                          ) : (
                            images.map((image, index) => (
                              <Card
                                sx={{
                                  minWidth: 200,
                                  borderRadius: 0,
                                  boxShadow: "none",
                                }}
                                className="form-img__img-preview-ed-ne imageCard"
                              >
                                <CardContent>
                                  <div key={index}>{handlePreview(image)}</div>
                                  {/* <img key={index} src={image.url} alt="Preview" className="form-img__img-preview" /> */}
                                  {/* <Button onClick={() => handleDelete(index)}>delete</Button> */}
                                  <img
                                    src={closeIconp}
                                    onClick={() => handleDelete(index)}
                                    className="imageclose-2-cird"
                                  />
                                </CardContent>
                              </Card>
                            ))
                          )}
                        </div>
                        {/* <h6>Event Images</h6>
                                                <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} />
                                                <div>
                                                    {images.map((image, index) => (
                                                        <img key={index} src={image.url} alt="" className="form-img__img-preview" />
                                                    ))}
                                                </div> */}
                        {/* </Grid>
                        ) : null} */}

                        <Grid item xs={6} sx={{ width: "20%" }}>
                          <input
                            type="file"
                            ref={hiddenFileInput}
                            style={{ display: "none" }}
                            multiple
                            onChange={handleImageChange}
                            accept="image/png, image/jpeg, image/jpg"
                          />
                          <Box
                            sx={{
                              mt: 2,
                              // ml: "-145px",
                              display: "flex",
                              "& > :not(style)": {
                                width: 150,
                                height: 140,
                                border: "3px dotted #356F92",
                              },
                            }}
                          >
                            <Paper
                              variant="outlined"
                              square
                              sx={{
                                border: "dotted 3px #1976d2",
                                padding: "50px",
                                width: "40%",
                                borderRadius: "14px",
                                // marginTop:"17px"
                              }}
                            >
                              <IconButton
                                color="primary"
                                aria-label="Upload"
                                onClick={handleClick}
                                sx={{
                                  display: "flex",
                                  justifyContent: "center",
                                  position: "relative",
                                  top: "25%",
                                  margin: "0 auto",
                                }}
                              >
                                <UploadIcon />
                              </IconButton>
                              <br />
                              <div
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  whiteSpace: "nowrap",
                                  marginTop: "-18px",
                                }}
                              >
                                {images.length > 0
                                  ? "Add More Images"
                                  : "Add Images"}
                              </div>
                            </Paper>
                          </Box>
                          <FormHelperText
                            sx={{
                              color: "#d32f2f",
                              width: "max-content",
                            }}
                          >
                            {checkImages &&
                              images.length === 0 &&
                              "Please upload event images"}
                          </FormHelperText>
                        </Grid>
                      </div>
                    </Grid>
                  </Grid>
                </form>
              </Box>
            </Grid>
            <React.Fragment>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Button
                  variant="contained"
                  sx={{}}
                  className="button-tr-2 postioncenterrelative"
                  onClick={handleSubmit(onSubmit)}
                  onFocus={() => setCheckImages(true)}
                >
                  Submit
                </Button>
                {/* <Button
                                    variant="outlined"
                                    onClick={handleClose}
                                    sx={{ p: 1, mr: 1 }}
                                    className="button-primary-alt-contained"
                                >
                                    Cancel
                                </Button> */}
                <Box sx={{ flex: "1 1 auto" }} />
              </Box>
            </React.Fragment>
          </Grid>
        </Grid>
      </Dialog>
    </>
  );
};

export default CreateInitiativeReportDialog;
