import React, { useState, useRef, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import CloseIcon from "@mui/icons-material/Close";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import {
  Select,
  MenuItem,
  Button,
  TextField,
  Grid,
  Box,
  FormControl,
  InputLabel,
  FormHelperText,
  Card,
  CardContent,
  IconButton,
  Paper,
  CardMedia,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import UploadIcon from "@mui/icons-material/Upload";
import CancelIcon from "@mui/icons-material/Cancel";
import { useDispatch, useSelector } from "react-redux";
import { getDevelopmentCompletionStatusList } from "../../../store/action/developmentProjectList";
import { postCreateDevelopmentProject } from "../../../store/action/createDevelopmentProject";
import Moment from "moment";
import {
  getDevelopmentProjectsListByMpId,
  getDevelopmentProjectsList,
} from "../../../store/action/developmentProjectList";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";
import closeIconp from "../../../asserts/images/close.png";
import Constant from "../../../utils/constant";
import { getIds } from "../../ReusableComponents.js/getIds";
import DeleteDevelopmentProjectsDialog from "./DeleteDevelopmentProjectsDialog";
import { validateNotEmpty } from "../../ReusableComponents.js/reuseMethods";

const AddDevelopmentProjects = ({
  openDevelopmentProjects,
  handleCloseDevelopmentProjects,
  details,
  isDevelopmentProjectsEdit,
  handleCloseInitiativeDetails,
  mpId,
  developmentProjectsByMpId,
}) => {
  const { setLoading } = useLoading();
  const { showNotification } = useNotificationContext();
  const [targetDate, setTargetDate] = useState(null);
  const [files, setFiles] = useState([]);
  const [uploadFiles, setUploadFiles] = useState([]);
  const dispatch = useDispatch();
  const developmentStatusList = useSelector(
    (state) => state?.developmentCompletionStatusList?.data
  );
  const hiddenFileInput = useRef(null);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();
  const [status, setStatus] = useState(
    developmentStatusList && developmentStatusList[0]?.status
  );
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [deleteClick, setDeleteClick] = useState(false);
  const [checkImages, setCheckImages] = useState(false);

  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  const fileFormats = ["image/png", "image/jpeg", "image/jpg"];
  useEffect(() => {
    //call api to update store
    dispatch(getDevelopmentCompletionStatusList());
  }, []);

  useEffect(() => {
    setStatus(developmentStatusList && developmentStatusList[0]?.status);
  }, [developmentStatusList]);

  useEffect(() => {
    if (details) {
      setFiles(details?.media && JSON.parse(details?.media));
      setTargetDate(details?.target);
    }
  }, [details]);

  useEffect(() => {
    if (deleteClick) {
      handleCloseDevelopmentProjects(
        reset,
        setFiles,
        setUploadFiles,
        setTargetDate
      );
    }
  }, [deleteClick]);

  const handleStatusChange = (event) => {
    setStatus(event.target.value);
    errors.status.message = null;
  };

  const handleImageChange = (e) => {
    const uploadedFiles = e.target.files;
    setUploadFiles([...uploadFiles, ...uploadedFiles]);
    let newFiles = [];
    for (let i = 0; i < uploadedFiles.length; i++) {
      const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
        if (uploadedFiles[i].type.startsWith("image")) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          newFiles.push({
            type: "image",
            url: reader.result,
            file: uploadedFiles[i],
          });
        } else if (uploadedFiles[i].type.startsWith("video")) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          newFiles.push({
            type: "video",
            url: reader.result,
            file: uploadedFiles[i],
          });
        }
        if (i === uploadedFiles.length - 1) {
          setFiles([...newFiles, ...files]);
        }
      };
    }
  };

  const handleDelete = (index) => {
    hiddenFileInput.current.value = "";
    const tempImages = [...files];
    tempImages.splice(index, 1);
    setFiles(tempImages);
    const tempFiles = [...uploadFiles];
    tempFiles.splice(index, 1);
    setUploadFiles(tempFiles);
  };

  const addImagesToFormData = async (formData, files) => {
    for (let i = 0; i < files.length; i++) {
      const response = await fetch(files[i].src);
      const blob = await response.blob();
      const file = new File(
        [blob],
        blob.type.startsWith("image/") ? `image${i}.jpg` : `video${i}.mp4`,
        { type: files[i].type === "image" ? "image/*" : "video/*" }
      );
      formData.append(`media`, file, file.name);
    }
  };

  const handleClickOpenDeleteDialog = () => {
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => setOpenDeleteDialog(false);

  const handlePreview = (file) => {
    if (file.type === "image") {
      return (
        <img
          src={typeof file === "string" ? file : file.url}
          alt="Preview"
          className="imageupload form-img__img-preview-4"
          id="imageupload"
        />
      );
    }
    if (file.type === "video") {
      return (
        <video
          controls
          className="imageupload form-img__img-preview-4"
          id="imageupload"
        >
          <source
            src={typeof file === "string" ? file : file.url}
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      );
    }
    const images = ["jpg", "gif", "png", "svg", "jfif"];
    const videos = ["mp4", "3gp", "ogg"];
    const url = new URL(file);
    const extension = url.search.split(".")[1];
    if (images.includes(extension)) {
      return (
        <img
          src={file}
          alt="Preview"
          className="imageupload form-img__img-preview-ed1"
          id="imageupload"
        />
      );
    }
    if (videos.includes(extension)) {
      return (
        <div>
          {/* <img src={playicon} onClick={handleHideImage} /> */}
          <video
            controls
            className="imageupload form-img__img-preview-ed1"
            id="imageupload"
          >
            <source
              src={typeof file === "string" ? file : file.url}
              type="video/mp4"
            />
            Your browser does not support the video tag.
          </video>
        </div>
      );
    }
  };

  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };

    const onAddDevelopmentProject = async (data) => {
        if (files?.length === 0) return;
        setLoading(true);
        const loggedInId = getIds();
        const tkn = localStorage.getItem("tokenDetails");
        const imgList = document.querySelectorAll(".imageupload");
        const formData = new FormData();
        formData.append("projecttitle", data?.projectTitle);
        formData.append("status", data?.status);
        formData.append("target", Moment(targetDate).format("YYYY-MM-DD"));
        formData.append("mpmodelId", loggedInId);
        formData.append("desc", data?.desc);
        await addImagesToFormData(formData, imgList);
        // Array.from(uploadFiles).forEach((file, i) => formData.append(`media`, file, file.name));
        const config = {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${tkn}`,
            },
        };
        const id = details?.id ? details?.id : 0;
        try {
            //   if (files?.length === 0) {
            //     showNotification("Error", "Please add image");
            //     return;
            //   } else {
            const response = await dispatch(
                postCreateDevelopmentProject(id, formData, config)
            );
            if (response.status === 200 || response.status === 201) {
                showNotification("Success", response.data.message, "success");
                handleCloseDevelopmentProjects(
                    reset,
                    setFiles,
                    setUploadFiles,
                    setTargetDate
                );
                if (details) {
                    handleCloseInitiativeDetails();
                }
                if (developmentProjectsByMpId) {
                    dispatch(getDevelopmentProjectsListByMpId(mpId));
                } else {
                    dispatch(getDevelopmentProjectsList(0));
                }
                // Object.keys(data).map(val => resetField(val));
                // setFiles([]);
                // setUploadFiles([]);
            }
            //   }
        } catch (error) {
            showNotification("Error", "Failed to fetch");
        } finally {
            setLoading(false);
        }
        // dispatch(postCreateDevelopmentProject(0, formData, config));
    };

  const dateConvert = (dateStr) => {
    const date = new Date(dateStr);
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let year = date.getFullYear();
    const formattedDate = `${month < 10 ? "0" + month : month}/${
      day < 10 ? "0" + day : day
    }/${year}`;
    return formattedDate;
  };

  return (
    <>
      <Dialog
        open={openDevelopmentProjects}
        onClose={() =>
          handleCloseDevelopmentProjects(
            reset,
            setFiles,
            setUploadFiles,
            setTargetDate
          )
        }
        sx={{ height: "96vh", mt: 2.5, overflowX: "hidden" }}
      >
        <DialogTitle
        // sx={{
        //     backgroundColor: "#003f93",
        //     color: "#ffffff",
        //     fontSize: "16px",
        // }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              color: "#357092",
              fontFamily: "HK Grotesk",
              fontSize: "26px",
              fontWeight: "bold",
            }}
          >
            <div>
              <b>Development Project</b>
            </div>
            <CloseIcon
              className="pageHeader"
              onClick={() =>
                handleCloseDevelopmentProjects(
                  reset,
                  setFiles,
                  setUploadFiles,
                  setTargetDate
                )
              }
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
                border: "1px solid #9e9e9e",
                borderRadius: "50%",
                padding: "2px",
                cursor: "pointer",
              }}
            />
          </Box>
        </DialogTitle>
        <Grid container className="bg-white" sx={{ overflowX: "hidden" }}>
          <Grid item xs={12} md={12}>
            <Grid item xs={12} md={12} sx={{ p: 4 }}>
              <Box>
                <form>
                  <Grid
                    container
                    spacing={1}
                    justifyContent="left"
                    alignItems="center"
                  >
                    <Grid container sx={{ mb: 2 }}>
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#357092",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b> Title</b>
                          </div>

                          <TextField
                            className="stepperFormInput"
                            // label="Title"
                            name="title"
                            fullWidth
                            placeholder="Enter title"
                            size="small"
                            required
                            defaultValue={details && details?.projecttitle}
                            autoComplete="off"
                            {...register("projectTitle", {
                              required: "Please enter project title",
                              maxLength: {
                                value: 50,
                                message: "Max length 50",
                              },
                              validate: (value) =>
                                validateNotEmpty(value, "project title"),
                            })}
                            //   error={Boolean(errors?.employeeId?.message)}
                            //   helperText={errors?.employeeId?.message}
                            //   onChange={() => setIsUpdateButton(false)}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.projectTitle?.message}
                        </FormHelperText>
                      </Grid>
                    </Grid>
                    <Grid container sx={{ mb: 2 }}>
                      <Grid item xs={6} sx={{ pr: 1 }}>
                        <div
                          style={{
                            fontFamily: "HK Grotesk",
                            color: "#357092",
                            fontSize: "16px",
                            fontWeight: "bold",
                            marginLeft: "5px",
                            marginBottom: "2px",
                          }}
                        >
                          <b> Target Date</b>
                        </div>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DatePicker
                            // label="End Date"
                            components={{
                              OpenPickerIcon: CalendarMonthIcon,
                            }}
                            InputProps={{
                              sx: {
                                "& .MuiSvgIcon-root": {
                                  color: "#fff",
                                  background: "#356f92",
                                  width: "35px",
                                  height: "35px",
                                  padding: "5px",
                                  borderRadius: "5px",
                                },
                              },
                            }}
                            // label="Target Date"
                            // sx={{width: '400px'}}
                            value={targetDate}
                            onChange={(newValue) => {
                              setTargetDate(dateConvert(newValue));
                            }}
                            minDate={new Date()}
                            renderInput={(params) => (
                              <TextField
                                sx={{
                                  "& .MuiInputBase-input": {
                                    width: "270px", // Set your height here.
                                  },
                                }}
                                {...params}
                                className="bdrdate"
                                defaultValue={details && details?.target}
                                {...register("targetDate", {
                                  required: !targetDate
                                    ? "Target date is required"
                                    : false,
                                })}
                                onKeyDown={(e) => {
                                  e.preventDefault();
                                }}
                                error={
                                  !targetDate &&
                                  Boolean(errors?.targetDate?.message)
                                }
                                helperText={
                                  !targetDate && errors?.targetDate?.message
                                }
                                autoComplete="off"
                              />
                            )}
                          />
                        </LocalizationProvider>
                      </Grid>
                      <Grid item xs={6} sm={6}>
                        <div
                          style={{
                            fontFamily: "HK Grotesk",
                            color: "#357092",
                            fontSize: "16px",
                            fontWeight: "bold",
                            marginLeft: "5px",
                            marginBottom: "2px",
                          }}
                        >
                          <b> Completion Status</b>
                        </div>

                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <InputLabel
                            id="demo-simple-select-label"
                            sx={{ marginTop: "-6px" }}
                          ></InputLabel>
                          <Select
                            className="stepperFormInput"
                            // label="Completion Status"
                            name="status"
                            fullWidth
                            required
                            defaultValue={details?.status}
                            size="small"
                            autoComplete="off"
                            sx={{ height: "56px" }}
                            {...register("status", {
                              required: "Please select status",
                            })}
                            SelectDisplayProps={{
                              renderValue: (defaultValue) => defaultValue,
                            }}
                            // value={details ? details?.status : status}
                            onChange={handleStatusChange}
                            // error={errors?.roleId}
                            // helperText={errors?.roleId?.message}
                            // onChange={() => setIsUpdateButton(false)}
                          >
                            {developmentStatusList &&
                              developmentStatusList.map((s) => {
                                return (
                                  <MenuItem
                                    native
                                    key={s.status}
                                    sx={{ width: "100%" }}
                                    value={s.status}
                                    size="small"
                                  >
                                    {s.status}
                                  </MenuItem>
                                );
                              })}
                          </Select>
                          <FormHelperText sx={{ color: "#d32f2f" }}>
                            {errors?.status && errors?.status?.message}
                          </FormHelperText>
                        </FormControl>
                      </Grid>
                    </Grid>
                    <Grid container>
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#357092",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b> About Project</b>
                          </div>
                          <TextField
                            className="stepperFormInput"
                            // label="About Project"
                            name="about"
                            placeholder="About Project"
                            fullWidth
                            required
                            multiline
                            rows={3}
                            size="small"
                            defaultValue={details && details?.desc}
                            autoComplete="off"
                            {...register("desc", {
                              required: "Please enter description",
                              maxLength: {
                                value: 1000,
                                message: "Max length 1000",
                              },
                              validate: (value) =>
                                validateNotEmpty(value, "description"),
                            })}
                            //   error={Boolean(errors?.mobileNumber)}
                            //   helperText={errors?.mobileNumber?.message}
                            //   onChange={() => setIsUpdateButton(false)}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.desc?.message}
                        </FormHelperText>
                      </Grid>
                    </Grid>
                    <Grid container sx={{ mt: 2 }}>
                      <div
                        style={{
                          fontFamily: "HK Grotesk",
                          color: "#357092",
                          fontSize: "16px",
                          fontWeight: "bold",
                          marginLeft: "5px",
                          marginBottom: "2px",
                        }}
                      >
                        <b> Attach Media</b>
                      </div>
                      <div
                        className="contpopup1"
                        style={{
                          flexDirection: "row-reverse",
                          marginLeft: "5px",
                        }}
                      >
                        {/* {files?.length > 0 ? ( */}
                        <div
                          style={{ width: "470px", top: "0px", marginLeft: "35px" }}
                          className="postionabs-2 itemfixed-update"
                        >
                          {files?.length > 1 ? (
                            <Tabs
                              // value={value}
                              // onChange={handleChange}
                              variant="scrollable"
                              scrollButtons
                              aria-label="visible arrows tabs example"
                              sx={{
                                [`& .${tabsClasses.scrollButtons}`]: {
                                  "&.Mui-disabled": { opacity: 0.3 },
                                },
                              }}
                            >
                              {files?.map((file, index) => (
                                <Card
                                  sx={{
                                    minWidth: 200,
                                    borderRadius: 0,
                                    boxShadow: "none",
                                  }}
                                  className="form-img__img-preview-4"
                                >
                                  <CardMedia>
                                    {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                    {/* <img key={index} src={image.url} alt="" className="form-img__img-preview" /> */}
                                    <div key={index}>{handlePreview(file)}</div>
                                    <img
                                      src={closeIconp}
                                      onClick={() => handleDelete(index)}
                                      className="imageclose-2"
                                    />
                                    {/* <Button onClick={() => handleDelete(index)}>delete</Button> */}
                                    {/* <IconButton
                                                                        className="card__icon" sx={{ position: "absolute", right: "5vh" }}
                                                                        onClick={() => handleRemove(file.id)}
                                                                    >
                                                                        <CancelIcon role="button"></CancelIcon>
                                                                    </IconButton> */}
                                  </CardMedia>
                                </Card>
                              ))}
                            </Tabs>
                          ) : (
                            files?.map((file, index) => (
                              <Card
                                sx={{
                                  minWidth: 200,
                                  borderRadius: 0,
                                  boxShadow: "none",
                                }}
                                className="form-img__img-preview-4 "
                              >
                                <CardMedia>
                                  {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                  {/* <img key={index} src={image.url} alt="" className="form-img__img-preview" /> */}
                                  <div key={index}>{handlePreview(file)}</div>
                                  {/* <Button onClick={() => handleDelete(index)}>delete</Button> */}
                                  <img
                                    src={closeIconp}
                                    onClick={() => handleDelete(index)}
                                    className="imageclose-2"
                                  />
                                </CardMedia>
                              </Card>
                            ))
                          )}
                        </div>
                        <Grid item xs={6}>
                          <input
                            type="file"
                            ref={hiddenFileInput}
                            style={{ display: "none" }}
                            multiple
                            onChange={handleImageChange}
                            accept="image/png, image/jpeg, image/jpg"
                          />
                          <Box
                            sx={{
                              // ml: "-95px",
                              display: "flex",
                              "& > :not(style)": {
                                // ml: "-8px",
                                width: 150,
                                height: 140,
                              },
                            }}
                          >
                            <Paper
                              variant="outlined"
                              square
                              sx={{
                                border: "dotted 3px #1976d2",
                                padding: "50px",
                                width: "40%",
                                borderRadius: "14px",
                              }}
                            >
                              <IconButton
                                color="primary"
                                aria-label="Upload"
                                onClick={handleClick}
                                sx={{
                                  display: "flex",
                                  justifyContent: "center",
                                  position: "relative",
                                  top: "15%",
                                  margin: "0 auto",
                                }}
                              >
                                <UploadIcon />
                              </IconButton>
                              <b
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  position: "relative",
                                  whiteSpace: "nowrap",
                                }}
                              >
                                {" "}
                                Add an Image
                              </b>
                              <FormHelperText
                                sx={{
                                  color: "#d32f2f",
                                  width: "max-content",
                                  marginTop: "28px",
                                  marginLeft: "-47px!important",
                                }}
                              >
                                {checkImages &&
                                  files.length === 0 &&
                                  "Please upload images"}
                              </FormHelperText>
                            </Paper>
                          </Box>
                        </Grid>
                        {/* <h6>Event Images</h6>
                                                <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} />
                                                <div>
                                                    {files.map((image, index) => (
                                                        <img key={index} src={image.url} alt="" className="form-img__img-preview" />
                                                    ))}
                                                </div> */}

                        {/* ) : null} */}
                      </div>
                    </Grid>

                    {/* <input type="file" ref={hiddenFileInput} onChange={handleVideoChange} multiple accept="video/*" />
                                        // <button onClick={handleClick}>Upload Videos</button> */}
                    {/* {videos.map((video, index) => */}
                    {/* <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size"> */}
                    {/* <CardContent> */}
                    {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                    {/* <video key={index} src={video.url} alt="" className="form-img__img-preview" /> */}
                    {/* </CardContent> */}
                    {/* </Card> */}
                    {/* // )} */}
                  </Grid>
                </form>
              </Box>
            </Grid>
            <React.Fragment>
              <Box sx={{ display: "flex", flexDirection: "row", p: 2, pl: 30 }}>
                <Button
                  variant="contained"
                  sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                  className="button-tr-2"
                  onClick={handleSubmit(onAddDevelopmentProject)}
                  onFocus={() => setCheckImages(true)}
                >
                  {isDevelopmentProjectsEdit ? "Update" : "Submit"}
                </Button>
                {isDevelopmentProjectsEdit && (
                  <Button
                    variant="outlined"
                    onClick={handleClickOpenDeleteDialog}
                    sx={{ p: 1, mr: 1 }}
                    className="button-tr-2-1 "
                  >
                    Delete
                  </Button>
                )}
                {!isDevelopmentProjectsEdit && (
                  <Button
                    variant="outlined"
                    onClick={() =>
                      handleCloseDevelopmentProjects(
                        reset,
                        setFiles,
                        setUploadFiles,
                        setTargetDate
                      )
                    }
                    sx={{ p: 1, mr: 1 }}
                    className="button-tr-2-1 "
                  >
                    Cancel
                  </Button>
                )}
                <Box sx={{ flex: "1 1 auto" }} />
              </Box>
            </React.Fragment>
            {openDeleteDialog && (
              <DeleteDevelopmentProjectsDialog
                openDeleteDialog={openDeleteDialog}
                handleCloseDeleteDialog={handleCloseDeleteDialog}
                developmentId={details?.id}
                mpId={mpProfileData?.id}
                handleCloseDevelopmentProjects={handleCloseDevelopmentProjects}
                developmentProjectsByMpId={developmentProjectsByMpId}
                handleCloseInitiativeDetails={handleCloseInitiativeDetails}
                details={details}
                setDeleteClick={setDeleteClick}
                isDevelopmentProjectsEdit={isDevelopmentProjectsEdit}
              />
            )}
          </Grid>
        </Grid>
      </Dialog>
    </>
  );
};

export default AddDevelopmentProjects;
