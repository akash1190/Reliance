import axios from "axios"
import Constant from "../../utils/constant"
// import { mpList } from "../../Constants/mpList"
import {
    FETCH_DEVELOPMENT_PROJECTS_LIST_REQUEST, FETCH_DEVELOPMENT_PROJECTS_LIST_SUCCESS, FETCH_DEVELOPMENT_PROJECTS_LIST_FAILURE,
    FETCH_DEVELOPMENT_STATUS_LIST_REQUEST, FETCH_DEVELOPMENT_STATUS_LIST_SUCCESS, FETCH_DEVELOPMENT_STATUS_LIST_FAILURE,
    FETCH_DEVELOPMENT_PROJECTS_LIST_BY_MP_ID_REQUEST, FETCH_DEVELOPMENT_PROJECTS_LIST_BY_MP_ID_SUCCESS, FETCH_DEVELOPMENT_PROJECTS_LIST_BY_MP_ID_FAILURE
} from "./types";

export const fetchDevelopmentProjectsListRequest = () => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_REQUEST
    }
}
export const fetchDevelopmentProjectsListSuccess = data => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_SUCCESS,
        payload: data
    }
}
export const fetchDevelopmentProjectsListFailure = error => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_FAILURE,
        payload: error
    }
}

export const fetchDevelopmentProjectsListByMpIdRequest = () => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_BY_MP_ID_REQUEST
    }
}
export const fetchDevelopmentProjectsListByMpIdSuccess = data => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_BY_MP_ID_SUCCESS,
        payload: data
    }
}
export const fetchDevelopmentProjectsListByMpIdFailure = error => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_BY_MP_ID_FAILURE,
        payload: error
    }
}

export const fetchDevelopmentCompletionStatusListRequest = () => {
    return {
        type: FETCH_DEVELOPMENT_STATUS_LIST_REQUEST
    }
}
export const fetchDevelopmentCompletionStatusListSuccess = carMakes => {
    return {
        type: FETCH_DEVELOPMENT_STATUS_LIST_SUCCESS,
        payload: carMakes
    }
}
export const fetchDevelopmentCompletionStatusListFailure = error => {
    return {
        type: FETCH_DEVELOPMENT_STATUS_LIST_FAILURE,
        payload: error
    }
}



export const getDevelopmentProjectsList = (id) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchDevelopmentProjectsListRequest)
    await axios.get(Constant.BASE_URL + `/api/development/getalldevelopment/${id ? id : 0}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchDevelopmentProjectsListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchDevelopmentProjectsListFailure(errorMsg))
        })
}

export const getDevelopmentProjectsListByMpId = (mpId) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchDevelopmentProjectsListByMpIdRequest)
    await axios.get(Constant.BASE_URL + `/api/getDevelopDataByMpId/${mpId}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data;
            // const result = mpList
            dispatch(fetchDevelopmentProjectsListByMpIdSuccess(result));
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchDevelopmentProjectsListByMpIdFailure(errorMsg));
        })
}

export const getDevelopmentCompletionStatusList = () => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchDevelopmentCompletionStatusListRequest)
    await axios.get(Constant.BASE_URL + '/api/getdevelopmentstatus',{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchDevelopmentCompletionStatusListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchDevelopmentCompletionStatusListFailure(errorMsg))
        })
}


