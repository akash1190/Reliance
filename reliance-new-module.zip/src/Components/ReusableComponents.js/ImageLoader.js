import { useState, useEffect } from "react";
import CircularProgress from '@mui/material/CircularProgress';
import noImage from '../../../src/asserts/images/noImageFound.jpg'

export function ImageLoader({ src, onClick, srcSet, className, width, loading }) {
    const [isLoading, setIsLoading] = useState(true);
    const [imageSrc, setImageSrc] = useState(null);

    useEffect(() => {
        const img = new Image();
        img.src = src;
        img.onload = () => {
            setIsLoading(false);
            setImageSrc(src);
        };
        // img.onerror =()=>{
        //     setIsLoading(false);
        //     setImageSrc(noImage)
        // }
    }, [src]);

    return (
        <div>
            {isLoading ? <div style={{ textAlignLast: "center" }} >  <CircularProgress color="inherit" /></div> :
                <img src={imageSrc && imageSrc} alt="" onClick={onClick && onClick}
                    srcSet={srcSet && srcSet} className={className && className} width={width && width}
                    loading={loading && loading} />}
        </div>
    );
}