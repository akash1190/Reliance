import axios from "axios"
import Constant from "../../utils/constant"
import { IMAGE_FAILURE,IMAGE_REQUEST,IMAGE_SUCCESS} from "./types"

export const getImageRequest = () => {
    return {
        type: IMAGE_REQUEST
    }
}
export const getImageSuccess = value => {
    return {
        type: IMAGE_SUCCESS,
        payload: value
    }
}
export const getImageFailure = error => {
    return {
        type: IMAGE_FAILURE,
        payload: error
    }
}


const getImageData = (query) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(getImageRequest)
    await axios.get(Constant.BASE_URL + `/api/imagestemplate/getall/${query}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
    .then(response => {
        const result = response.data.imagetemplatedata
        dispatch(getImageSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(getImageFailure(errorMsg))
    })
}

const updateImage = (formData) => async(dispatch)=>{
    const tkn = localStorage.getItem("tokenDetails");
    await axios.post(Constant.BASE_URL + `/api/user/update-mpdata/${formData.id}`,formData,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      });
}


export {getImageData, updateImage}

