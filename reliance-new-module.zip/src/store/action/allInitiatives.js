import axios from "axios"
import Constant from "../../utils/constant"
import { ALL_INITIATIVES_FAILURE, ALL_INITIATIVES_REQUEST, ALL_INITIATIVES_SUCCESS } from "./types"

export const allInitiativeRequest = () => {
    return {
        type: ALL_INITIATIVES_REQUEST,
        payload: []
    }
}
export const allInitiativeSuccess = value => {
    return {
        type: ALL_INITIATIVES_SUCCESS,
        payload: value
    }
}
export const allInitiativeFailure = error => {
    return {
        type: ALL_INITIATIVES_FAILURE,
        payload: error
    }
}

export const getAllInitiative = (...args) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    const query = args[0]
    const action = args[1]
    dispatch(allInitiativeRequest)
    let api;
    // if(data == "Ongoing") {

    if (action) {
        api = Constant.BASE_URL + `/api/initiative/sortbasedonstatus/${query}/${action}`
    }
    else {
        api = Constant.BASE_URL + `/api/initiative/getbymp/${query}`
    }
    await axios.get(api, {
        headers: {
            Authorization: `Bearer ${tkn}`,
        },
    })
        .then(response => {
            let result;
            // if(data == "Ongoing") {

            if (action) {
                result = response.data.flatArray
            }
            else {
                result = response.data.initiative
            }

            dispatch(allInitiativeSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(allInitiativeFailure(errorMsg))
        })
}

// export const activityInitiative = () => async (dispatch) => {
//     dispatch(allInitiativeRequest)
//     await axios.get(Constant.BASE_URL + `/api/initiative/sortbasedonstatus/69/Ongoing`)
//     .then(response => {
//         const result = response.data.initiative
//         dispatch(allInitiativeSuccess(result))
//     })
//     .catch(error => {
//         const errorMsg = error.message
//         dispatch(allInitiativeFailure(errorMsg))
//     })
// }