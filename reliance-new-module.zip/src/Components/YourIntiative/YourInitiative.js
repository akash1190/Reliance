import "./YourInitiative.css";
import SideMenu from "../SideMenu/SideMenu";
import React, { useEffect, useRef, useState } from "react";
import {
  CardActionArea,
  CardContent,
  Collapse,
  Grid,
  InputAdornment,
  TextField,
  Typography,
  Box,
  Dialog,
  DialogTitle,
  Tooltip,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
// import 'bootstrap/dist/css/bootstrap.min.css';
// import InitiativeCard from "./InitiativeCard";
// import CreateInitiativeCard from "./createIntiativecard";
import SortOutlinedIcon from "@mui/icons-material/SortOutlined";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
// import SortOut from "./sortOut";
import EditIcon from "@mui/icons-material/Edit";
import ShareIcon from "@mui/icons-material/Share";
import ImagesModal from "./ImagesShare/ImagesModal";
import searchIcon from "../../asserts/images/Search.svg";
import SharingText from "./sharingText";
import VideosModal from "./VideoSHare/VideosModal";
import buttonicon from "./../../asserts/images/Card1your.svg";
import buttonicon2 from "./../../asserts/images/Card2your.svg";
import { useDispatch, useSelector } from "react-redux";
import CreateInitiativeReportDialog from "../SavaUpdate/AllInitiativeReports/createInitiativeReportDialog";
import {
  getAllInitiative,
} from "../../store/action/allInitiatives";
import { overViewInitiatives } from "../../store/action/initiativesOverview";
import { getSocialMediaKit } from "../../store/action/socialMediaKit";
import { searchInitiative } from "../../store/action/searchInitiative";
import { useLocation } from "react-router";
import { getMpProfile } from "../../store/action/individualMP";
import { useLoading } from "../../utils/LoadingContext";
import { useNotificationContext } from "../../utils/NotificationContext";
import { getIntiativesReportByInitiativeIdAndMpId } from "../../store/action/ongoingSevaInitiativesList";
import UpdateInitiativeReportDetails from "../SavaUpdate/AllInitiativeReports/UpdateInitiativeReportDialog";
import CreateNewEvent from "../SavaUpdate/AddSevaEvent/CreateNewEvent";
import NoImageFound from "../../asserts/images/noImageFound.jpg";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import IconButton from "@mui/material/IconButton";
import { styled } from "@mui/material/styles";
import Share from "../ReusableComponents.js/Share";
import { getIds } from "../ReusableComponents.js/getIds";
import Moment from "moment";
const CryptoJS = require("crypto-js");
const mpUserId = getIds();

// import CreateInitiativeReportDialog from '../SavaUpdate/AllInitiativeReports/createInitiativeReportDialog';

function IntiativesDetailsCard({
  data,
  passChildData,
  setDetails,
  loading,
  searchStatus,
  filteredList,
}) {
  const functionHandler = (item) => {
    passChildData(item);
    setDetails(true);
  };

  let list = filteredList;

  useEffect(() => {
    // if (!props.data) {
    if (filteredList) {
      if (!data) {
        passChildData(filteredList[0]);
      }

      setDetails(true);
    }

    // }
  }, [filteredList]);

  if (list?.length === 0) {
    if(loading)
      return <div style={{ color: "green" }}>Loading Initiatives....</div>
    else if(searchStatus)
     return <div style={{ color: "red" }}>No Matches found. Try something else...</div>;
    else
    return <div style={{ color: "red" }}>No Initiatives Created....</div>;
    
  }

  return list?.map((item) => {
    return (
      <div className="onhovertes">
        <div
          className="onhoverte"
          tabindex="1"
          onClick={() => functionHandler(item)}
        >
          <div className="details-wrapper" key={item.id}>
            <p>
              <Tooltip title={item.initiativeName} arrow>
                <span className="name-alligment ellipsewehe12">
                  {item.initiativeName}
                </span>
              </Tooltip>

              <button
                style={{ marginTop: "-30px" }}
                className={`${item.status == "Ongoing" || item.status == "Completed"
                  ? "details-btn-ongoing"
                  : "details-btn-alligment"
                  }`}
              >
                {item.status}
              </button>
            </p>
            <p>
            {item?.tagetDate && <span  style={{ verticalAlign: "text-top"}}>Target Date: <span className="target-date">{Moment(item?.tagetDate).format('DD MMMM YYYY')}</span></span>}
          
              <button className="details-btn-alligments ellipsewehe12-h ">
                #{item?.hashTags?.replace(/^#+/, "")}
              </button>
            </p>
          </div>
        </div>
      </div>
    );
  });
}

function IntiativesDetails({
  data,
  setInitiatives,
  initiative,
  initDetailsChange,
  setInitDetailsChange,
}) {
  const initiativeReportDetailsByMPIdAndIntiativeId = useSelector(
    (state) => state?.initiativeReportDetailsByMPIdAndIntiativeId?.data
  );
  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  const mpId = mpProfileData?.id;
  const userEventId = useRef(data);
  const [buttonClick, setButtonClick] = useState(false);
  const [createButtonClick, setCreateButtonClick] = useState(false);
  // const [cardFormData, setCardFormData] = useState([]);
  const [update, setUpdate] = useState(false);
  const [open, setOpen] = useState(false);
  const [openImage, setOpenImage] = useState(false);
  const [openText, setOpenText] = useState(false);
  const [openVideo, setOpenVideo] = useState(false);
  // const [initiativeReportDialog, setInitiativeReportDialog] = useState(false);
  const [formImg, setFormImg] = useState();
  const [myValues, setMyValues] = useState(data);
  const [initiativeEvents, setInitiativeEvents] = useState([]);
  const [editEvent, setEditEvent] = useState(false);
  const [openUpdateIntiativeDialog, setOpenUpdateInitiativeDialog] =
    useState(false);
  const [openEventDialog, setOpenEventDialog] = useState(false);
  const [eventDetails, setEventDetails] = useState();
  const [isEventEdit, setIsEventEdit] = useState(false);
  const [createEventDialog, setCreateEventDialog] = useState(false);
  const [initReportDetails, setInitReportDetails] = useState([]);
  const [details, setDetails] = useState();
  const [expanded, setExpanded] = useState(false);
  const [yourEventsExpand, setYourEventsExpand] = useState(false);
  const [mediaShare, setMediaShare] = useState(false);
  const [shareData, setShareData] = useState({});
  const location = useLocation();
  const [checkInitiativeStatus, setCheckInitiativeStatus] = useState(false);
  let MPId = location?.state?.mpId;
  const { showNotification } = useNotificationContext();
  const { setLoading } = useLoading();
  const dispatch = useDispatch();
  const texttemplates = useSelector(
    (state) =>
      state?.socialMediaKit?.data !== [] &&
      state?.socialMediaKit?.data?.texttemplates
  );
  const imagetemplates = useSelector(
    (state) =>
      state?.socialMediaKit?.data !== [] &&
      state?.socialMediaKit?.data?.imagetemplates
  );
  const videotemplates = useSelector(
    (state) =>
      state?.socialMediaKit?.data !== [] &&
      state?.socialMediaKit?.data?.videotemplates
  );
  const fetchInitiativeData = async () => {
    try {
      const response = await dispatch(
        getIntiativesReportByInitiativeIdAndMpId(data?.id, mpId)
      );
      if (response.status === 200 || response.status === 201) {
        if (response.data?.message) {
          // showNotification("Error", response.data?.message, "error");
          setInitiativeEvents([]);
        } else {
          setInitiativeEvents(response?.data?.Eventdata);
          setInitReportDetails(response?.data?.reportdata);
          // setPersonDetails(item);
          // setOpenInitiativeDetailsDialog(true);
        }
      }
    } catch (error) {
      // showNotification("Error", "Failed to fetch");
    }
  };

  useEffect(() => {
    if (checkInitiativeStatus) {
      setInitDetailsChange(!initDetailsChange);
      // setCheckInitiativeStatus(false);
    }
  }, [createButtonClick]);

  useEffect(() => {
    if (data) {
      setMyValues(data);
      dispatch(getSocialMediaKit(data?.id));
    }
    if(data?.id && mpId)
      fetchInitiativeData();
  }, [
    data,
    openUpdateIntiativeDialog,
    createButtonClick,
    createEventDialog,
    openEventDialog,
  ]);
  const handleOpenText = (val) => {
    setOpenText(val);
  };

  const handleOpen = (val) => {
    setOpen(val);
  };

  const handleClickingOpen = () => {
    setOpenText(true);
  };

  const handleImageClickOpen = () => {
    setOpenImage(true);
  };
  const handleVideoClickOpen = () => {
    setOpenVideo(true);
  };
  const handleCloseText = (value) => {
    setOpenText(false);
  };

  const handleImageClose = (value) => {
    setOpenImage(false);
  };

  const handleVideoClose = (value) => {
    setOpenVideo(false);
  };

  const handleClickOpen = () => {
    setButtonClick(!buttonClick);
  };
  const handlecreateClickOpen = () => {
    setCreateButtonClick(!createButtonClick);
  };

  const handleUpdate = () => {
    setUpdate(true);
  };

  const handleCloseEvent = () => {
    setOpenEventDialog(false);
  };

  const handleCloseCreateEvent = () => {
    setCreateEventDialog(false);
  };

  const handleEdit = (item) => {
    setEventDetails(item);
    setOpenEventDialog(true);
    setEditEvent(true);
    setIsEventEdit(true);
  };

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const handleYourEventsExpandClick = () => {
    setYourEventsExpand(!yourEventsExpand);
  };

  const handleCloseUpdateInitiativeDetails = (
    reset,
    reportFiles,
    setUploadFiles
  ) => {
    // setShowUpdate(false);
    reset();
    reportFiles([]);
    setUploadFiles([]);
    setOpenUpdateInitiativeDialog(false);
  };

  const handleInitiativeReport = () => {
    if (data.status === "Completed" || initReportDetails?.id) {
      setOpenUpdateInitiativeDialog(true);
    } else {
      handlecreateClickOpen();
      // setCreateButtonClick(true)
    }
  };

  const ExpandMore = styled((props) => {
    const { expand, ...other } = props;
    return <IconButton {...other} />;
  })(({ theme, expand }) => ({
    transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
    marginLeft: "auto",
    transition: theme.transitions.create("transform", {
      duration: theme.transitions.duration.shortest,
    }),
  }));

  const handleShare = (e, item) => {
    e.stopPropagation();
    e.preventDefault();
    setShareData(item);
    setMediaShare(true);
  };

  const dataSteps = data?.steps?.split("\n");

  return (
    <card style={{ width: "600px", height: "650px" }}>
      {data ? (
        <div>
          <Tooltip title={data?.initiativeName} arrow>
            <p
              style={{
                marginLeft: "30px",
                marginTop: "10px",
                fontFamily: "HK Grotesk",
                fontSize: "20px",
                fontWeight: "bold",
                marginTop: "15px",
              }}
              className="ellipsewehe12 cursorshow"
            >
              {data?.initiativeName}
            </p>
          </Tooltip>
          <ImagesModal setOpen={handleImageClose} open={openImage} />
          <VideosModal
            setOpenVideo={handleVideoClose}
            open={openVideo}
          ></VideosModal>
          <img
            style={{
              width: "100%",
              height: "264px",
              top: "207px",
              left: "1127px",
              marginTop: "-20px",
            }}
            src={JSON.parse(data?.coverimage)[0]}
            className="seva-image"
            onError={(e) => (e.target.src = NoImageFound)}
          ></img>
          <div>
            <Grid container>
              <Grid item xs={11}>
                <span
                  className="initiative-heading"
                  style={{
                    marginLeft: "30px",
                    fontFamily: "HK Grotesk",
                    fontSize: "20px",
                    fontWeight: "bold",
                    color: "#356F92",
                  }}
                >
                  Initiative Details
                </span>
              </Grid>
              <Grid item xs={1}>
                <ExpandMore
                  expand={expanded}
                  onClick={handleExpandClick}
                  aria-expanded={expanded}
                  aria-label="show more"
                >
                  <ExpandMoreIcon
                    sx={{
                      background: "#E3F5FF",
                      color: "#356F92",
                      borderRadius: "50%",
                    }}
                  />
                </ExpandMore>
              </Grid>
            </Grid>
          </div>
          <Collapse in={expanded} timeout="auto" unmountOnExit>
            <CardContent>
              <Typography
                sx={{
                  ml: "25px",
                  fontFamily: "HK Grotesk",
                  fontSize: "18px",
                  fontWeight: "500",
                  color: "#505050",
                }}
              >
                {data?.initiativeDetails}
              </Typography>
              <Typography
                sx={{
                  ml: "25px",
                  fontFamily: "HK Grotesk",
                  fontSize: "18px",
                  fontWeight: "bold",
                  color: "#3571ED",
                }}
              >
                {" "}
                #{data?.hashTags?.replace(/^#+/, "")}{" "}
              </Typography>
              <Typography
                sx={{
                  ml: "25px",
                  mt: "11px",
                  fontFamily: "HK Grotesk",
                  fontSize: "18px",
                  fontWeight: "bold",
                  color: "#505050",
                }}
              >
                {" "}
                Target Date :
                <span
                  style={{
                    fontFamily: "HK Grotesk",
                    fontSize: "18px",
                    fontWeight: "500",
                    color: "#505050",
                  }}
                >
                  {" "}
                  {data?.tagetDate && Moment(data?.tagetDate).format("DD MMMM YYYY")}
                </span>{" "}
              </Typography>
              <Typography
                sx={{
                  ml: "25px",
                  mt: "15px",
                  fontFamily: "HK Grotesk",
                  fontSize: "18px",
                  fontWeight: "bold",
                  color: "#505050",
                }}
              >
                Steps:
              </Typography>
              {dataSteps.map((line) => (
                <Typography
                  key={line}
                  sx={{
                    ml: "25px",
                    fontFamily: "HK Grotesk",
                    fontSize: "18px",
                    fontWeight: "500",
                    color: "#505050",
                  }}
                >
                  {line}
                </Typography>
              ))}
              {/*  */}
            </CardContent>
          </Collapse>
          <hr width="90%"></hr>
          <div>
            <p
              className="initiative-heading"
              style={{
                marginLeft: "30px",
                marginTop: "20px",
                fontFamily: "HK Grotesk",
                fontSize: "20px",
                fontWeight: "bold",
                color: "#356F92",
              }}
            >
              Social Media Kit
            </p>
            <p
              className="resources-heading"
              style={{
                marginLeft: "40px",
                fontFamily: "HK Grotesk",
                fontSize: "16px",
                color: "#505050",
              }}
            >
              You can download the resources from here
            </p>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                paddingRight: "22px",
              }}
            >
              <button className="button-heading" onClick={handleClickingOpen}>
                <svg
                  className={
                    // texttemplates && texttemplates?.length === 0
                    //   ? "diablesvgtext"
                    //   :
                    "enabletextsvg"
                  }
                  xmlns="http://www.w3.org/2000/svg"
                  width="25"
                  height="25"
                  margin-right="10px"
                  viewBox="0 0 190.783 235.229"
                >
                  <g
                    id="Icon_feather-file-text"
                    data-name="Icon feather-file-text"
                    transform="translate(6.5 6.5)"
                    className={
                      // texttemplates && texttemplates?.length === 0
                      //   ? "diablesvgtext"
                      //   :
                      "enabletextsvg"
                    }
                  >
                    <path
                      id="Path_497528"
                      data-name="Path 497528"
                      d="M117.114,3H28.223A22.223,22.223,0,0,0,6,25.223V203.006a22.223,22.223,0,0,0,22.223,22.223H161.56a22.223,22.223,0,0,0,22.223-22.223V69.669Z"
                      transform="translate(-6 -3)"
                    ></path>
                    <path
                      id="Path_497529"
                      data-name="Path 497529"
                      d="M21,3V69.669H87.669"
                      transform="translate(90.115 -3)"
                    ></path>
                    <path
                      id="Path_497530"
                      data-name="Path 497530"
                      d="M100.892,19.5H12"
                      transform="translate(32.446 102.726)"
                    ></path>
                    <path
                      id="Path_497531"
                      data-name="Path 497531"
                      d="M100.892,25.5H12"
                      transform="translate(32.446 141.172)"
                    ></path>
                    <path
                      id="Path_497532"
                      data-name="Path 497532"
                      d="M34.223,13.5H12"
                      transform="translate(32.446 64.28)"
                    ></path>
                  </g>
                </svg>
                Text
              </button>
              <button className="button-heading" onClick={handleImageClickOpen}>
                <svg
                  className={
                    // imagetemplates && imagetemplates?.length === 0
                    //   ? "diablesvg"
                    //   :
                    "enablesvg"
                  }
                  xmlns="http://www.w3.org/2000/svg"
                  width="25"
                  height="25"
                  margin-right="10px"
                  viewBox="0 0 307.584 239.232"
                >
                  <path
                    id="Icon_awesome-images"
                    data-name="Icon awesome-images"
                    d="M256.32,207.306v8.544a25.632,25.632,0,0,1-25.632,25.632H25.632A25.632,25.632,0,0,1,0,215.85V79.146A25.632,25.632,0,0,1,25.632,53.514h8.544V164.586a42.768,42.768,0,0,0,42.72,42.72Zm51.264-42.72V27.882A25.632,25.632,0,0,0,281.952,2.25H76.9A25.632,25.632,0,0,0,51.264,27.882v136.7A25.632,25.632,0,0,0,76.9,190.218H281.952A25.632,25.632,0,0,0,307.584,164.586ZM136.7,53.514a25.632,25.632,0,1,1-25.632-25.632A25.632,25.632,0,0,1,136.7,53.514ZM85.44,130.41l29.645-29.645a6.409,6.409,0,0,1,9.063,0l21.1,21.1L217.613,49.5a6.409,6.409,0,0,1,9.063,0l46.732,46.733v59.808H85.44Z"
                    transform="translate(0 -2.25)"
                  />
                </svg>
                Images
              </button>
              <button className="button-heading" onClick={handleVideoClickOpen}>
                <svg
                  className={
                    // videotemplates && videotemplates?.length === 0
                    //   ? "diablesvg"
                    //   :
                    "enablesvg"
                  }
                  xmlns="http://www.w3.org/2000/svg"
                  width="25"
                  height="25"
                  margin-right="10px"
                  viewBox="0 0 339.064 226.043"
                >
                  <path
                    id="Icon_awesome-video"
                    data-name="Icon awesome-video"
                    d="M197.905,4.5H28.138A28.137,28.137,0,0,0,0,32.638V202.405a28.137,28.137,0,0,0,28.138,28.138H197.905a28.137,28.137,0,0,0,28.138-28.138V32.638A28.137,28.137,0,0,0,197.905,4.5ZM309.4,26.692l-64.516,44.5v92.654L309.4,208.292c12.479,8.594,29.668-.177,29.668-15.187V41.879C339.064,26.928,321.935,18.1,309.4,26.692Z"
                    transform="translate(0 -4.5)"
                  />
                </svg>
                Videos
              </button>
            </div>
            <hr width="90%"></hr>
          </div>
          <SharingText open={openText} onClose={handleCloseText} />

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <div
              style={{
                marginLeft: "40px",
                fontFamily: "HK Grotesk",
                fontSize: "20px",
                fontWeight: "bold",
                color: "#356F92",
              }}
            >
              Your Events{" "}
            </div>

            <div
              style={{
                // marginLeft: "50%",
                // marginTop: "20px",
                fontFamily: "HK Grotesk",
                fontSize: "20px",
                fontWeight: "bold",
                color: "#505050",
                display: "flex",
                alignItems: "center",
                marginLeft: "-15px",
              }}
            >
              {initiativeEvents?.length == 0
                ? "0 Events"
                : `${initiativeEvents?.length} ${ initiativeEvents?.length===1?"Event":"Events"} `}
              <ExpandMore
                expand={yourEventsExpand}
                onClick={handleYourEventsExpandClick}
                aria-expanded={yourEventsExpand}
                aria-label="show more"
              >
                <ExpandMoreIcon
                  sx={{
                    background: "#E3F5FF",
                    color: "#356F92",
                    borderRadius: "50%",
                  }}
                />
              </ExpandMore>
            </div>
          </div>

          <Collapse in={yourEventsExpand} timeout="auto" unmountOnExit>
            <CardContent className="gridyour" sx={{mb:"-15px!important"}}>
              {initiativeEvents?.map((item) => (
                <div >
                  <div class="d-flex hidden-section">
                    <div
                      class="event-card mr-3"
                      style={{ position: "relative" }}
                    >
                      <div class="">
                        <div>
                          <img
                            className="imagesquare"
                            width="100%"
                            src={
                              item?.coverimage &&
                              JSON.parse(item?.coverimage)[0]
                            }
                            alt=""
                            onError={(e) => (e.target.src = NoImageFound)}
                            style={{ filter: "brightness(50%)" }}
                          />
                        </div>
                      </div>
                      <div
                        style={{
                          position: "absolute",
                          color: "white",
                          top: 100,
                          left: "15%",
                          transform: "translateX(-15%)",
                          textTransform: "capitalize",
                        }}
                      >
                        <p
                          className="ecclipseonwidthnewrow"
                          style={{ fontFamily: "HK Grotesk", fontSize: "16px" }}
                        >
                          {item?.eventTitle}
                          <br />
                          <span
                            style={{
                              fontFamily: "HK Grotesk",
                              fontSize: "14px",
                            }}
                          >
                            {item?.location}{" "}
                          </span>
                        </p>
                      </div>
                      <div
                        className="cursorshow"
                        style={{
                          position: "absolute",
                          color: "white",
                          top: "4px",
                          left: "84%",
                          transform: "translateX(-15%)",
                          textTransform: "capitalize",
                        }}
                      >
                        <Box sx={{ display: "flex", ml: "-65px" }}>
                          <p className="oparditini" style={{marginLeft:"38px"}}>
                            <EditIcon
                              onClick={() => handleEdit(item)}
                              sx={{ width: "15px", mt: "-28px", ml: "-7px" }}
                            />
                          </p>
                          <p
                            className="oparditini"
                            style={{ marginLeft: "15px" }}
                          >
                            <ShareIcon
                              sx={{ width: "15px", mt: "-28px", ml: "-7px" }}
                              onClick={(e) => handleShare(e, item)}
                            />
                          </p>
                        </Box>
                       
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Collapse>

          <hr width="90%"></hr>
          <div>
            <div className="twobu">
              <div
                class="gfg cursorshow"
                onClick={() => setCreateEventDialog(true)}
              >
                <img src={buttonicon} className="imagewgfg" />
                <p
                  class="first-txt clickable"
                // onClick={() => setCreateEventDialog(true)}
                >
                  Create an Event for this Initiative
                </p>
              </div>

              <div class="gfg cursorshow" onClick={handleInitiativeReport}>
                <img src={buttonicon2} className="imagewgfg" />
                <p class="first-txt clickable">
                  {/* <p class="first-txt clickable" onClick={handleInitiativeReport}> */}
                  {data.status === "Completed" ||
                    // checkInitiativeStatus ||
                    initReportDetails?.id
                    ? "Update an Initiative Report"
                    : "Create an Initiative Report"}
                </p>
              </div>
            </div>
          </div>
          {createEventDialog && (
            <CreateNewEvent
              openCreateEventDialog={createEventDialog}
              handleCloseCreateEvent={handleCloseCreateEvent}
              initiativeId={data.id}
              initiativeName={data.initiativeName}
            />
          )}
          {editEvent && openEventDialog && (
            <CreateNewEvent
              mpId={mpId}
              initiativeId={data.id}
              initiativeName={data.initiativeName}
              details={eventDetails}
              handleCloseCreateEvent={handleCloseEvent}
              openCreateEventDialog={openEventDialog}
              isSevaEventEdit={isEventEdit}
            />
          )}
          {createButtonClick ? (
            <CreateInitiativeReportDialog
              open={createButtonClick}
              handleClose={handlecreateClickOpen}
              initiativeName={data.initiativeName}
              initiativeId={data.id}
              setCheckInitiativeStatus={setCheckInitiativeStatus}
              insideYourInitiative={true}
            />
          ) : null}
          {openUpdateIntiativeDialog ? (
            <UpdateInitiativeReportDetails
              handleCloseUpdateInitiativeDetails={
                handleCloseUpdateInitiativeDetails
              }
              openUpdateIntiativeDialog={openUpdateIntiativeDialog}
              details={initReportDetails}
              initiativeName={data.initiativeName}
              initiativeReportDetailsByMPIdAndIntiativeId={
                initiativeReportDetailsByMPIdAndIntiativeId
              }
            />
          ) : null}
          <Dialog open={mediaShare} onClose={() => setMediaShare(false)}>
            <DialogTitle>
              <IconButton
                aria-label="close"
                onClick={() => setMediaShare(false)}
                sx={{
                  position: "absolute",
                  right: 8,
                  top: 8,
                  color: (theme) => theme.palette.grey[500],
                  border: "1px solid #9e9e9e",
                  borderRadius: "50%",
                  padding: "2px",
                  cursor: "pointer",
                }}
              >
                <CloseIcon />
              </IconButton>
              <Typography
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  color: "#357092",
                  fontFamily: "HK Grotesk",
                  fontSize: "26px",
                  fontWeight: "bold",
                }}
              >
                Share to Social Media
              </Typography>

              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  marginTop: "25px",
                  gap: "40px",
                }}
              >
                <Share data={shareData} title="Seva aur Samarpan Campaign" />
              </div>
              {/* <CloseIcon onClick={() => setAddMembers(false)} /> */}
            </DialogTitle>
          </Dialog>
        </div>
      ) : null}
    </card>
  );
}

const YourIntiatives = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const allInitiatives = useSelector((state) => state?.allInitiatives?.data);
  const loading = useSelector((state) => state?.allInitiatives?.loading);
  const searchData = useSelector((state) => state?.searchInitiative?.data);
  const searchLoading = useSelector((state) => state?.searchInitiative?.loading);
  const [details, setDetails] = useState(false);
  const [hideSearch, setHideSearch] = useState(false);
  const [open, setOpen] = React.useState(false);
  const [initDetailsChange, setInitDetailsChange] = useState(false);
  const handleOpen = (event) => {
    setAnchorEl(event.currentTarget);

    setOpen(true);
    setSearchStatus(false);
    setHideSearch(false);
  };

  const handleClose = (event) => {
    setAnchorEl(event.currentTarget);
    setOpen(false);
  };
  const [data, setData] = useState();
  const [searchStatus, setSearchStatus] = useState(false);
  const [filterStatus, setFiterStatus] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState("");
  const [filteredList, setFilteredList] = useState(allInitiatives);

  const dispatch = useDispatch();
  const location = useLocation();
  let newUser = location?.state?.user;
  const loggedInId = getIds();
  const initiative = useSelector((state) => state?.initiativesOverview?.data);
  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  const mpId = mpProfileData?.id;

  const handleSearch = (event) => {
    const loggedInId = getIds();
    if (event.target.value == "") {
      setSearchStatus(false);
      dispatch(getAllInitiative(loggedInId));
    } else {
      setSearchStatus(true);
      dispatch(searchInitiative(mpUserId, event.target.value));
    }
  };

  const handleFilter = async (event, value) => {
    let statusValue;
    if (event.target.innerText == "Report Pending") {
      statusValue = "Report_Pending";
      setSelectedFilter("Report_Pending");
    } else if (event.target.innerText == "Activity") {
      statusValue = "";
      setSelectedFilter("Activity");
    } else {
      statusValue = event.target.innerText;
      setSelectedFilter(event.target.innerText);
    }
    setFiterStatus(true);

    // dispatch(activityInitiative())
    dispatch(
      getAllInitiative(
        loggedInId,
        // event.target.innerText === "Activity" ? "" : event.target.innerText
        statusValue
      )
    );
    setAnchorEl(null);
    setOpen(false);
    // dispatch()    // filter api
  };

  useEffect(() => {
    // const mpUserId = localStorage.getItem("userId");
    // dispatch(getEventsList(data.id));
    dispatch(getMpProfile(loggedInId));
    dispatch(getAllInitiative(loggedInId, ""));
    dispatch(overViewInitiatives(loggedInId));
    // setData(allInitiatives[0]);
    // handleSearch();
  }, [initDetailsChange]);

  const handleAllInitiatives = () => {
    setSearchStatus(false);
    setSelectedFilter("");
    setHideSearch(false);
    dispatch(getAllInitiative(loggedInId));
  };


  const blockInvalidChar = (e) =>
    [
      "#",
      "&",
      "+",
      "_",
      "!",
      "@",
      "%",
      "[",
      "]",
      "=",
      "*",
      "^",
      "-",
      "?",
      "/",
      "$",
      ")",
      "(",
    ].includes(e.key) && e.preventDefault();


  return (
    <div className="d-flex page-wrapper1">
      {newUser ? (
        <SideMenu active="Initiatives" user={newUser} />
      ) : (
        <SideMenu active="Initiatives" profileData={mpProfileData} />
      )}

      <div className="intiatives-container main-wrapper center-width">
        <h1 className="header-design header-alligment">Your Initiatives</h1>
        <Grid container>
          <Grid item xs={6} md={6}>
            <div className="container1-alligment">
              <card>
                <div className="overview-card">
                  <p className="header-design">Initiatives Overview</p>
                  <div className="overview-flex">
                    <span className="count-alligment">
                      <span className="count-headers">
                        Requested Initiatives{" "}
                      </span>
                      <div className="count-container count-conatiner-color1">
                        {initiative.requestCount}
                      </div>
                    </span>
                    <span className="count-alligment">
                      <span className="count-headers">
                        Ongoing Initiatives{" "}
                      </span>
                      <div className="count-container count-conatiner-color2">
                        {initiative.ongoingCount}
                      </div>
                    </span>
                    <span className="count-alligment">
                      <span className="count-headers">Events Conducted </span>
                      <div className="count-container1 count-conatiner-color3">
                        {initiative.eventcount1 === null
                          ? 0
                          : initiative.eventcount1}
                      </div>
                    </span>
                  </div>
                </div>
              </card>
              <div
                class="overview-card Testdemo"
                style={{
                  maxHeight: "625px",
                  overflowY: "scroll",
                  overflowX: "hidden",
                }}
              >
                <div class="all-intiatives-header">
                  <div className="design">
                    <span
                      className="header-design cursorshow"
                      onClick={handleAllInitiatives}
                    >
                      All Initiatives{" "}
                      <hr
                        style={{
                          border: "2px solid #EC6E29",
                          width: "100%",
                          marginTop: "4px",
                        }}
                      ></hr>
                    </span>
                    <div style={{ display: "flex", alignItems: "center" }}>
                      <div
                        className="menuItemForSort cursorshow"
                        style={{ marginRight: "15px" }}
                      >
                        <SortOutlinedIcon
                          className="sort-styling"
                          onClick={handleOpen}
                        />

                        <div className="checksort">
                          <Menu
                            // id="basic-menu"
                            anchorEl={anchorEl}
                            value={selectedFilter}
                            open={open}
                            onClose={handleClose}
                            // MenuListProps={{
                            //   'aria-labelledby': 'basic-button',
                            // }}
                            PaperProps={{
                              sx: {
                                width: "320px",
                                // height:"322px",
                                borderRadius: "14px",
                                fontFamily: "HK Grotesk",
                                left: "0!important",
                                right: " 0!important",
                                marginLeft: "auto",
                                marginRight: "auto",
                                // marginTop:"323px!important",
                                // position:"absolute!important",
                                // top:"-16px!important",

                                "& .MuiMenuItem-root": {
                                  fontFamily: "HK Grotesk",
                                  paddingTop: "0px",
                                  border: "1px solid #D3D3D3",
                                  margin: "10px 20px 0",
                                  borderRadius: "10px",
                                  justifyContent: "center",
                                  fontSize: "14px",
                                  fontWeight: "bold",
                                  "&$selected": {
                                    backgroundColor: "#356F92",
                                    "&:hover": {
                                      backgroundColor: "#356F92",
                                    },
                                  },
                                  "&:hover": {
                                    backgroundColor: "#356F92",
                                    color: "#fff",
                                  },
                                },
                              },
                            }}
                          >
                            <p
                              style={{
                                fontFamily: "HK Grotesk",
                                fontSize: "12px",
                                color: "#356F92",
                                fontWeight: "bold",
                                marginLeft: "24px",
                                marginBottom: "-6px",
                              }}
                            >
                              FILTER BY:
                            </p>
                            <MenuItem
                              value={"Activity"}
                              selected={
                                "Activity" == selectedFilter ? true : false
                              }
                              onClick={(event, value) =>
                                handleFilter(event, value)
                              }
                              sx={{
                                "&.Mui-selected": {
                                  backgroundColor:
                                    selectedFilter === "Activity"
                                      ? "#356F92 !important"
                                      : "",
                                  color:
                                    selectedFilter === "Activity"
                                      ? "#fff !important"
                                      : "",
                                },
                              }}
                            >
                              Activity
                            </MenuItem>
                            <MenuItem
                              value={"Requested"}
                              selected={
                                "Requested" == selectedFilter ? true : false
                              }
                              onClick={(event, value) =>
                                handleFilter(event, value)
                              }
                              sx={{
                                "&.Mui-selected": {
                                  backgroundColor:
                                    selectedFilter === "Requested"
                                      ? "#356F92 !important"
                                      : "",
                                  color:
                                    selectedFilter === "Requested"
                                      ? "#fff !important"
                                      : "",
                                },
                              }}
                            >
                              Requested
                            </MenuItem>
                            <MenuItem
                              value={"Ongoing"}
                              selected={
                                "Ongoing" == selectedFilter ? true : false
                              }
                              onClick={(event, value) =>
                                handleFilter(event, value)
                              }
                              sx={{
                                "&.Mui-selected": {
                                  backgroundColor:
                                    selectedFilter === "Ongoing"
                                      ? "#356F92 !important"
                                      : "",
                                  color:
                                    selectedFilter === "Ongoing"
                                      ? "#fff !important"
                                      : "",
                                },
                              }}
                            >
                              Ongoing
                            </MenuItem>
                            <MenuItem
                              value={"Report_Pending"}
                              selected={
                                "Report_Pending" == selectedFilter
                                  ? true
                                  : false
                              }
                              onClick={(event, value) =>
                                handleFilter(event, value)
                              }
                              sx={{
                                "&.Mui-selected": {
                                  backgroundColor:
                                    selectedFilter === "Report_Pending"
                                      ? "#356F92 !important"
                                      : "",
                                  color:
                                    selectedFilter === "Report_Pending"
                                      ? "#fff !important"
                                      : "",
                                },
                              }}
                            >
                              Report Pending
                            </MenuItem>
                            <MenuItem
                              value={"Completed"}
                              selected={
                                "Completed" == selectedFilter ? true : false
                              }
                              onClick={(event, value) =>
                                handleFilter(event, value)
                              }
                              sx={{
                                "&.Mui-selected": {
                                  backgroundColor:
                                    selectedFilter === "Completed"
                                      ? "#356F92 !important"
                                      : "",
                                  color:
                                    selectedFilter === "Completed"
                                      ? "#fff !important"
                                      : "",
                                },
                              }}
                            >
                              Completed
                            </MenuItem>
                          </Menu>
                        </div>
                      </div>
                      <div>
                        {!hideSearch ? (
                          <div style={{ marginTop: "2px" }}>
                            <img
                              className="searchIcon cursorshow"
                              width={18}
                              height={18}
                              src={searchIcon}
                              onClick={() => setHideSearch(!hideSearch)}
                            />
                          </div>
                        ) : (
                          <div>
                            <TextField
                              sx={{
                                "& fieldset": { border: "none" },
                                padding: "0px",
                                "& .MuiInputBase-input": {
                                  padding: "5px 10px 5px 10px !important",
                                  fontFamily: "HK Grotesk",
                                },
                                marginRight: "-12px",
                              }}
                              className="search-sort-ini"
                              onChange={(e) => {
                                handleSearch(e);
                              }}
                              // onKeyDown={blockInvalidChar}
                              placeholder="Search Seva/ Initiatives"
                              InputProps={{
                                endAdornment: (
                                  <InputAdornment position="end">
                                    {/* search icon  */}
                                    <img
                                      className="searchIcon cursorshow"
                                      width={18}
                                      height={18}
                                      src={searchIcon}
                                      onClick={() => {
                                        setHideSearch(!hideSearch);
                                        handleAllInitiatives();
                                      }}
                                    />
                                  </InputAdornment>
                                ),
                              }}
                            ></TextField>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <IntiativesDetailsCard
                    data={data}
                    passChildData={setData}
                    setDetails={setDetails}
                    loading={searchStatus ? searchLoading : loading}
                    searchStatus={searchStatus}
                    filteredList={searchStatus ? searchData : allInitiatives}
                  />
                </div>
              </div>
            </div>
          </Grid>
          {details && (
            <Grid item xs={6} md={6}>
              <div
                className="container2-alligment-2"
                style={{
                  maxHeight: "650px",
                  overflowX: "hidden",
                }}
              >
                <IntiativesDetails
                  initiative={initiative}
                  setInitiatives={[]}
                  data={data}
                  initDetailsChange={initDetailsChange}
                  setInitDetailsChange={setInitDetailsChange}
                />
              </div>
            </Grid>
          )}
        </Grid>
      </div>
    </div>
  );
};

export default YourIntiatives;
