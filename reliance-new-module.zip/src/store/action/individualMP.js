import axios from "axios"
import Constant from "../../utils/constant"
import { INDIVIDUAL_MP_VIEW_FAILURE, INDIVIDUAL_MP_VIEW_SUCCESS, INDIVIDUAL_MP_VIEW_REQUEST } from "./types"

export const getMp = () => {
    return {
        type: INDIVIDUAL_MP_VIEW_REQUEST
    }
}
export const getMpProfileSuccess = value => {
    return {
        type: INDIVIDUAL_MP_VIEW_SUCCESS,
        payload: value
    }
}
export const getMpProfileFailure = error => {
    return {
        type: INDIVIDUAL_MP_VIEW_FAILURE,
        payload: error
    }
}



const getMpProfile = (query) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails")
    dispatch(getMp)
    await axios.get(Constant.BASE_URL + `/api/user/getmpforcitizen/${query}`, {
        headers: {
            Authorization: `Bearer ${tkn}`,
        },
    })
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(getMpProfileSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(getMpProfileFailure(errorMsg))
        })
}

const updateMpProfile = (formData, id, config) => async (dispatch) => {
    
    return axios.post(Constant.BASE_URL + `/api/user/update-mpdata/${id}`, formData, config, {
        
    });
}


export { getMpProfile, updateMpProfile }

