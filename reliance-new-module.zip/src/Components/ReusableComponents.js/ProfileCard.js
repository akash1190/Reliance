import {
  Button,
  Card,
  CardActionArea,
  CardContent,
  CardMedia,
  Dialog,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";
import { Box } from "@mui/system";
import React, { useEffect } from "react";
import { useNavigate } from "react-router";
import rightArrow from "../../asserts/images/arrowRight.png";
import MemberIcon from "../../asserts/images/MemberIcon.png";
import DonationIcon from "../../asserts/images/InviteDonation.png";
import CircleBg from "../../asserts/images/CircleBg.png";
import IconEdit from "../../asserts/images/IconEdit.svg";
import CloseIcon from "@mui/icons-material/Close";
import ProfileEdit from "./ProfileEdit";
import Copyo from "../../asserts/images/copy1.svg";
import facebook from "../../asserts/images/Facebook.svg";
import twitter1 from "../../asserts/images/Twitter1.svg";
import whatsapp from "../../asserts/images/WhatsApp.svg";
import email from "../../asserts/images/Email.svg";
import Share from "./Share";
import { toast } from "react-hot-toast";
import CopyAndShareClick from "./CopyAndShareAPI";
import DonationClick from "./DonationClick";

const ProfileCard = ({ profile }) => {
  // const navigate= useNavigate();

  const [open, setOpen] = React.useState(false);
  const [addMembers, setAddMembers] = React.useState(false);
  const [inviteDonations, setInviteDonations] = React.useState(false);
  // let code = ["LBLA67-F", "M4TSUX-F"]
  let code = localStorage.getItem("Referal")
  let link = "https://n-m4.in/z2Fk";
  let link2 = `https://www.narendramodi.in/donation/${code}`;
  const content = `Join me on NM App in the journey to transform India. Click ${link} & Enter code ${code}`

  const handleEdit = () => {
    setOpen(true);
  };
  const handleOpen = (val) => {
    setOpen(val);
  };

  return (
    <>
      <Card className="right-card card">
        {/* <div> */}
          {/* {open && <ProfileEdit mpDetail={profile} setOpen={handleOpen} open={open} />} */}
          {/* <Card m={2} sx={{ border: "#357092 2px solid", borderRadius: "12px", height: "170px" }} 
          // onClick={handleEdit}
          >
            <CardActionArea>
              <img
                src={IconEdit}
                alt="edit"
                className="card-icon-edit"
              />
              <img src={CircleBg} alt="bg" className="card-bg" />
              <img
                src={profile.user_avatar}
                alt={profile.user_name}
                className="card-icon-image"
              />
              <CardContent>
                <Box width="50%">
                  <Typography
                    variant="h5"
                    color="#357092"
                    fontWeight="Bold"
                    padding="0"
                    fontFamily="HK Grotesk"
                    fontSize="18px"
                    className="cardellipright"
                  >
                    {profile?.user_name}
                  </Typography>
                  <Typography
                    variant="body2"
                    color="text.secondary"
                    fontFamily="HK Grotesk"
                    fontSize="14px"
                    sx={{ pt: 2 }}
                  >
                    {profile?.designation}-{profile?.party},<br />
                    <br />
                    {profile?.state_name}
                  </Typography>
                </Box>
              </CardContent>
            </CardActionArea>
          </Card> */}

          {/* </div> */}

          <div className="right-card-1" >
            <div className="d-flex-gap-1" style={{ justifyContent: "space-between" }}>
              {/* <Button sx={{ textTransform: "unset", textAlign:"-webkit-left",   color: "white",    font: "inherit"}}> */}
              <Card
                className="small-cards small-card1 clickable cursorshow"
                sx={{ borderRadius: "10px" }}
                onClick={() => setAddMembers(true)}
              >
                <Box mb={0}>
                  <img className="mr-3" src={MemberIcon} width="15" alt="" />
                </Box>
                <Box
                  sx={{ display: "flex", justifyContent: "space-between" }}
                  mt={2}
                >
                  <Typography
                    mb={0}
                    sx={{
                      color: "#fff",
                      fontSize: "13px",
                      fontWeight: "600",
                      fontFamily: "HK Grotesk",
                    }}
                  >
                    Add members to NaMo App
                  </Typography>
                  <img
                    width="24"
                    height="21.44"
                    className="align-bottom"
                    src={rightArrow}
                  />
                </Box>
              </Card>

              {/* <div className="small-cards small-card1">
                <p className="mb-0">
                  <img className="mr-3" src={MemberIcon} width="15" alt="" />
                </p>
                <div className="d-flex justify-content-between mt-3">
                  <p className="mb-0">Add members to NaMo App </p>
                  <img
                    width="24"
                    height="21.44"
                    className="align-bottom"
                    src={rightArrow}
                  />
                </div>
              </div> */}
              {/* </Button> */}

              {/* <Button sx={{ textTransform: "unset", textAlign:"-webkit-left",   color: "white",    font: "inherit"}}> */}
              <Card
                className="small-cards small-card2 clickable cursorshow"
                sx={{ borderRadius: "10px" }}
                onClick={() => setInviteDonations(true)}
              >
                <Box mb={0}>
                  <img className="mr-3" src={DonationIcon} width="15" alt="" />
                </Box>
                <Box
                  sx={{ display: "flex", justifyContent: "space-between" }}
                  mt={2}
                >
                  <Typography
                    mb={0}
                    sx={{
                      color: "#fff",
                      fontSize: "13px",
                      fontWeight: "600",
                      fontFamily: "HK Grotesk",
                    }}
                  >
                    Invite Donations
                  </Typography>
                  <img
                    width="24"
                    height="21.44"
                    className="align-bottom"
                    src={rightArrow}
                  />
                </Box>
              </Card>

              {/* <div className="small-cards small-card2">
                <p className="mb-0">
                  <img className="mr-3" src={DonationIcon} width="15" alt="" />
                </p>
                <div className="d-flex justify-content-between mt-3">
                  <p className="mb-0">Invite Donations</p>
                  <img
                    width="24"
                    height="21.44"
                    className="align-text-bottom"
                    src={rightArrow}
                  />
                </div>
              </div> */}
              {/* </Button> */}
            </div>
          </div>
        {/* </div> */}
      </Card>
      <Dialog open={addMembers} onClose={() => setAddMembers(false)}
      PaperProps={{
        style: {
          width:"600px"
        },
      }}>
        <DialogTitle sx={{ mt:2}}>
          <IconButton
            aria-label="close"
            onClick={() => setAddMembers(false)}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
              border: "1px solid #9e9e9e",
              borderRadius: "50%",
              padding: "2px",
              cursor: "pointer",
            }}
          >
            <CloseIcon />
          </IconButton>
          <Typography
            sx={{
              display: "flex",
              justifyContent: "center",
              color: "#357092",
              fontFamily: "HKGrotesk-Bold!important",
              fontSize: "30px",
              fontWeight: "bold",
            }}
          >
            Expand the Movement
          </Typography>
          <Typography
            sx={{
              display: "flex",
              justifyContent: "center",
              color: "#505050",
              fontFamily: "HKGrotesk-Bold!important",
              fontSize: "22px",
              fontWeight: "bold",
              mt: 1
            }}
          >
            Invite more members to be New India Volunteer
          </Typography>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "25px",
            }}
          >

            <div className="sharepopupbg">
              <span style={{
                color: "#505050",
                fontFamily: "HK Grotesk",
                fontSize: "18px",
                fontWeight: "bold",
                textAlign: "left", display: "block", marginLeft: "5%", marginTop: "13px"
              }}><b style={{fontWeight:"500"}}>YOUR UNIQUE CODE </b><br></br> {code}</span>
              {/* <span style={{
                color: "#505050",
                fontFamily: "HK Grotesk",
                fontSize: "20px",
                fontWeight: "bold",
                textAlign: "center", display: "block", marginLeft: "-63%"
              }}>M4TSUX-F </span> */}
            </div>
            <img src={Copyo} className="copysv cursorshow" onClick={() => {
              window.navigator.clipboard
                .writeText(code)
                .then((res) => {
                  toast.success("Copied to clipboard.");
                })
                .catch((err) =>
                  console.log(err)
                );
              CopyAndShareClick()
            }}

            />
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "25px",
              gap: "40px",
              marginBottom:"10px"
            }}
          >
            <Share CopyAndShareClick={CopyAndShareClick} content={`Join me on NM App in the journey to transform India. Click ${link}& Enter code ${code}`} linkurl={link} />

          </div>
          {/* <CloseIcon onClick={() => setAddMembers(false)} /> */}
        </DialogTitle>
      </Dialog>
      <Dialog open={inviteDonations} onClose={() => setInviteDonations(false)}
      PaperProps={{
        style: {
          width:"600px",
          height:"450px"
        },
      }}>
        <DialogTitle sx={{ }}>
          <IconButton
            aria-label="close"
            onClick={() => setInviteDonations(false)}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
              border: "1px solid #9e9e9e",
              borderRadius: "50%",
              padding: "2px",
              cursor: "pointer",
            }}
          >
            <CloseIcon />
          </IconButton>
          <Typography
            sx={{
              display: "flex",
              justifyContent: "center",
              color: "#357092",
              fontFamily: "HKGrotesk-Bold!important",
              fontSize: "30px",
              fontWeight: "bold",
            }}
          >
            Invite Donations
          </Typography>
          <Typography
            sx={{
              display: "flex",
              justifyContent: "center",
              color: "#505050",
              fontFamily: "HKGrotesk-Bold!important",
              fontSize: "22px",
              fontWeight: "bold",
              textAlign: "center",
              mt: 1,
            }}
          >
            Encourage contributions towards strengthening <br></br>a party of
            New India Builders.
          </Typography>
          <Typography
            sx={{
              display: "flex",
              justifyContent: "center",
              color: "#357092",
              fontFamily: "HKGrotesk-Bold!important",
              fontSize: "30px",
              fontWeight: "bold",
              mt: 2,
            }}
          >
            Refer now to your friends
          </Typography>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "25px",
            }}
          >
            <div className="sharepopupbg">
              <span style={{
                color: "#505050",
                fontFamily: "HK Grotesk",
                fontSize: "18px",
                fontWeight: "bold",
                textAlign: "left", display: "block", marginLeft: "5%", marginTop: "13px"
              }}><b style={{fontWeight:"500"}}>YOUR UNIQUE CODE </b><br></br> {code}</span>
              {/* <span style={{
                color: "#505050",
                fontFamily: "HK Grotesk",
                fontSize: "20px",
                fontWeight: "bold",
                textAlign: "center", display: "block", marginLeft: "-63%"
              }}>LBLA67-F </span> */}
            </div>
            <img src={Copyo} className="copysv cursorshow"
              onClick={() => {
                window.navigator.clipboard
                  .writeText(code)
                  .then((res) => {
                    toast.success("Copied to clipboard.");
                  })
                  .catch((err) => console.log(err));
                DonationClick()
              }} />
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "25px",
              gap: "40px",
              marginBottom:"10px"
            }}
          >
            <Share donation={true} content={`I donated to the party of aspirations of all Indians. I contributed towards strengthening a party of New India builders under PM Modi. You can do it too! Use my Code ${code}  
${link2} via Namo App`} linkurl={link2} />
          </div>
        </DialogTitle>
      </Dialog>
    </>
  );
};

export default ProfileCard;
