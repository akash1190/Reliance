import React, { useState, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";
import Moment from "moment";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { Box, Card, CardContent, Grid, Button } from "@mui/material";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import DialogActions from "@mui/material/DialogActions";
import CreateNewEvent from "../AddSevaEvent/CreateNewEvent";
import PreviewImagesDialog from "./PreviewImagesDialog";

const EventDetailsDialog = ({
    handleCloseEventDetailsDialog,
    openEventDetailsDialog,
    details,
    mpProfileData,
    initiativeId,
    user
}) => {
    const [isSevaEventEdit, setIsSevaEventEdit] = useState(false);
    const [files, setFiles] = useState([]);
    const [openCreateEventDialog, setOpenCreateEventDialog] = useState(false);
    const [openPreviewImages, setOpenPreviewImages] = useState(false);

    useEffect(() => {
        if (details) {
            setFiles(details?.media && JSON.parse(details?.media));

        }
    }, [details]);

    const handlePreview = (file) => {
        const images = ["jpg", "gif", "png", "svg", "jfif"];
        const videos = ["mp4", "3gp", "ogg"];
        const url = new URL(file);
        const extension = url?.search.split(".")[1];
        if (details && images.includes(extension)) {
            return (
                <img
                    src={file}
                    alt="Preview"
                    onError={(e) => (e.target.src = NoImageFound)}
                    className="form-img__img-preview-invide-ini"
                    style={{ marginLeft: "32px" }}
                />
            );
        }
        else if (details && videos.includes(extension)) {
            return (
                <video controls className="form-img__img-preview-invide-ini" style={{ marginLeft: "32px" }}>
                    <source
                        src={typeof file === "string" ? file : file.url}
                        type="video/mp4"
                    />
                    Your browser does not support the video tag.
                </video>
            );
        }
    };

    const handleOpenCreateEvent = () => {
        setOpenCreateEventDialog(true);
    };
    const handleCloseCreateEvent = () => {
        // setEventByMpId(false);
        setOpenCreateEventDialog(false);
    };

    const onEditClick = () => {
        setIsSevaEventEdit(true);
        handleOpenCreateEvent();
        // if (checkMySeva) {
        //     setEventByMpId(true);
        // }
    };

    const handleOpenPreviewImages = () => {
        setOpenPreviewImages(true);
    };
    const handleClosePreviewImages = () => {
        setOpenPreviewImages(false);
    };

    return (
        <>
            <Dialog
                open={openEventDetailsDialog}
                onClose={handleCloseEventDetailsDialog}
                sx={{ height: "96vh", marginTop: "15px" }}
            >
                <IconButton
                    aria-label="close"
                    onClick={handleCloseEventDetailsDialog}
                    sx={{
                        position: "absolute",
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                        border: "1px solid #9e9e9e",
                        borderRadius: "50%",
                        padding: "2px",
                        cursor: "pointer",
                    }}
                >
                    <CloseIcon />
                </IconButton>
                <DialogTitle
                    id="customized-dialog-title"
                    onClose={handleCloseEventDetailsDialog}
                >
                    <div
                        style={{
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    >
                        <h1
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#356F92",
                                fontSize: "26px",
                                fontWeight: "bold",
                                textTransform: "capitalize",
                            }}
                        >
                            Event Conducted by {details?.user?.user_name}
                        </h1>
                    </div>
                    <hr></hr>
                </DialogTitle>
                <DialogContent sx={{ mt: -1.5 }}>
                    <div className="text-center pt-1">
                        {details?.user?.user_avatar ? (
                            <img
                                src={details?.user?.user_avatar}
                                className="img-circle leader-circle-img mr-1"
                                width="80"
                                height="80px"
                            />
                        ) : (
                            <AccountCircleIcon
                                sx={{ fontSize: "xx-large", width: "80px", height: "80px" }}
                            />
                        )}
                    </div>
                    <div className="card-content">
                        <h2
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#356F92",
                                fontSize: "22px",
                                fontWeight: "bold",
                            }}
                        >
                            {details?.user?.user_name ?? ""}
                        </h2>
                        <span
                            className="initial"
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#11243D",
                                fontSize: "15px",
                                fontWeight: "bold",
                            }}
                        >
                            {details?.user?.designation ??
                                "" + ", " + details?.user?.state_name ??
                                ""}
                        </span>
                        <br />
                        <span
                            className="constituency"
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#707A89",
                                fontSize: "15px",
                                fontWeight: "bold",
                            }}
                        >
                            {"Constituency" + " : " + details?.user?.constituency_name ??
                                ""}
                        </span>
                        <br />
                        <span
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#11243D",
                                fontSize: "17px",
                                fontWeight: "bold",
                                display: "inline-block",
                                background: "#fef6f2",
                                padding: "5px",
                                borderRadius: "10px",
                                marginTop: "10px",
                            }}
                        >
                            {details?.eventTitle ?? ""}
                        </span>
                    </div>
                    <div style={{ marginTop: "5px" }}>
                        <div
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#356F92",
                                fontSize: "16px",
                                fontWeight: "bold",
                                marginLeft: "55px",
                            }}
                        >
                            Event Description
                            <br />
                        </div>
                        <div
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#505050",
                                fontSize: "15px",
                                fontWeight: "bold",
                                marginLeft: "50px",
                                height: "85px",
                                overflowY: "auto",
                                overflowx: "hidden",
                                wordBreak: "break-word",
                                // border:"1px solid #b6b6b6",
                                borderRadius: "20px",
                                marginTop: "10px",
                                padding: "6px"
                            }}
                        >
                            <span title={details?.desc ? details?.desc : ""}>
                                {details?.desc && details?.desc}
                            </span>
                        </div>
                    </div>
                    <br />
                    <div>
                        <span
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#356F92",
                                fontSize: "16px",
                                fontWeight: "bold",
                                marginLeft: "55px",
                            }}
                        >
                            Event Images
                        </span>
                        <div >
                            {files?.length > 1 ? (
                                <Tabs
                                    variant="scrollable"
                                    scrollButtons
                                    aria-label="visible arrows tabs example"
                                    sx={{
                                        [`& .${tabsClasses.scrollButtons}`]: {
                                            "&.Mui-disabled": { opacity: 0.3 },
                                        },
                                        "& .MuiTabs-flexContainer":{marginLeft:"-35px"}
                                    }}
                                >
                                    {files?.map((file, index) => (
                                        <Card
                                            sx={{ minWidth: 200, mr: 2, borderRadius: "20px" }}
                                            className=" bshadow"
                                            onClick={() => {
                                                handleOpenPreviewImages(file)
                                            }}
                                        >
                                            <CardContent>
                                                <div key={index}>{handlePreview(file)}</div>
                                            </CardContent>
                                        </Card>
                                    ))}
                                </Tabs>
                            ) : (
                                files?.map((file, index) => (
                                    <Card
                                        sx={{ minWidth: 200, mr: 2, borderRadius: "20px"}}
                                        className="bshadow"
                                        onClick={() => {
                                            handleOpenPreviewImages(file)
                                        }}
                                    >
                                        <CardContent>
                                            <div key={index}>{handlePreview(file)}</div>
                                        </CardContent>
                                    </Card>
                                ))
                            )}
                        </div>
                        <Grid container>
                            <Grid item xs={6}>
                                <span
                                    style={{
                                        fontFamily: "HK Grotesk",
                                        color: "#356F92",
                                        fontSize: "16px",
                                        fontWeight: "bold",
                                        marginLeft: "55px",
                                    }}
                                >
                                    Start Date :
                                </span>{" "}
                                {Moment(details?.startDate).format("DD/MM/YYYY")}
                            </Grid>
                            <Grid item xs={6}>
                                <span
                                    style={{
                                        fontFamily: "HK Grotesk",
                                        color: "#356F92",
                                        fontSize: "16px",
                                        fontWeight: "bold",
                                        marginLeft: "55px",
                                    }}
                                >
                                    End Date :
                                </span>{" "}
                                {details?.endDate !== null ? Moment(details?.endDate).format("DD/MM/YYYY") : "-"}
                            </Grid>
                        </Grid>
                        <div
                            style={{
                                fontFamily: "HK Grotesk",
                                color: "#356F92",
                                fontSize: "16px",
                                fontWeight: "bold",
                                marginLeft: "55px",
                                display: "block",
                                marginTop: "15px",
                            }}
                        >
                            {" "}
                            Location
                        </div>
                        <Grid container>
                            <Grid
                                item
                                xs={12}
                                sx={{
                                    fontFamily: "HK Grotesk",
                                    color: "#505050",
                                    fontSize: "18px",
                                    fontWeight: "bold",
                                    marginLeft: "55px",
                                }}
                            >
                                {details?.location ?? ""}
                            </Grid>
                        </Grid>
                    </div>
                </DialogContent>
                <DialogActions sx={{ justifyContent: "Center" }}>
                    {details?.userId === mpProfileData?.id &&
                        <>
                            {user !== "Admin" && user !== "Leader" && <Button
                                variant="contained"
                                className="button-tr-2"
                                autoFocus
                                sx={{ backgroundColor: "#ef7335" }}
                                onClick={onEditClick}
                            >
                                Edit
                            </Button>}
                            <Button
                                variant="outlined"
                                className="button-tr-citizen-cancel"
                                autoFocus
                                onClick={handleCloseEventDetailsDialog}

                            >
                                Cancel
                            </Button>
                        </>
                    }
                </DialogActions>
                {openCreateEventDialog && <CreateNewEvent
                    openCreateEventDialog={openCreateEventDialog}
                    isSevaEventEdit={isSevaEventEdit}
                    handleCloseCreateEvent={handleCloseCreateEvent}
                    details={details}
                    editEventDetails={true}
                    handleCloseEventDetailsDialog={handleCloseEventDetailsDialog}
                    initiativeId={initiativeId}
                />}
                {openPreviewImages && <PreviewImagesDialog
                    openPreviewImages={openPreviewImages}
                    handleClosePreviewImages={handleClosePreviewImages}
                    files={files}
                />}
            </Dialog>
        </>
    );
};

export default EventDetailsDialog;
