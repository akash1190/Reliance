import React, { useState, useRef, useEffect, createRef } from "react";
import DialogTitle from "@mui/material/DialogTitle";
import Dialog from "@mui/material/Dialog";
import CloseIcon from "@mui/icons-material/Close";
import {
  FormControl,
  Grid,
  IconButton,
  InputLabel,
  Select,
  MenuItem,
  Button,
  FormHelperText,
  DialogActions,
} from "@mui/material";
import { Box } from "@mui/system";
import AddIcon from "@mui/icons-material/Add";
import UploadIcon from "@mui/icons-material/Upload";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import UploadVideos from "./UploadVideoDialog";
import closeIconp from "../../../../asserts/images/close-1.png";
import { useNotificationContext } from "../../../../utils/NotificationContext";
import VideoPlayerPreview from "../../../ReusableComponents.js/VideoPlayerPreview";

const AddVideoTemplates = ({
  handleCloseVideosTemplateDialog,
  openVideoTemplateDialog,
  setVideoData,
  languages,
  editDetails,
  setUpdateVideoValue,
}) => {
  const {
    register,
    unregister,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
    reset,
  } = useForm();
  const fileFormats = ["video/mp4"];
  const { showNotification } = useNotificationContext();

  const uploadVideoRef = useRef();
  const [videoRefs, setVideoRefs] = useState([]);

  const [videos, setVideos] = useState([]);
  const [videoFiles, setVideoFiles] = useState([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(-1);
  const [checkWarningPopup, setCheckWarningPopup] = useState(false);
  const [dialogState, setDialogState] = useState({
    open: false,
    for: undefined,
  });
  const [inputState, setInputState] = useState([
    {
      id: Date.now(),
      language: true,
      upload: true,
      remove: true,
    },
  ]);

  useEffect(() => {
    setVideoRefs(inputState.map(() => createRef()));
  }, []);


  useEffect(() => {
    if (editDetails) {
      const temp = [];
      editDetails?.forEach((template, i) => {
        temp.push({
          id: i,
          language: true,
          languageValue: template.language,
          upload: true,
          remove: true,
          videosData:
            typeof template.video === "string"
              ? JSON.parse(template.video)
              : template.video,
        });
        !getValues(`${i}`)?.length > 0 &&
          setValue(`${i}.language`, template.language);
        !getValues(`${i}`)?.length > 0 &&
          setValue(
            `${i}.videos`,
            typeof template.video === "string"
              ? JSON.parse(template.video)
              : template.video
          );
      });
      setInputState(temp);
      setVideoRefs(temp.map(() => createRef()));
    }
  }, [editDetails]);

  const removeInput = (id) => {
    const tempData = [...inputState];
    const newData = tempData.filter((input) => input.id !== id);
    const index = inputState.findIndex((data) => data.id === id);
    const newRefs = videoRefs.filter((_, i) => tempData[i].id !== id);
    unregister(index.toString());
    setInputState(newData);
    setVideoRefs(newRefs);
    const newFormData = {};
    const formData = getValues();
    const formDataValues = Object.values(formData);
    formDataValues.forEach((item, ind) => {
      newFormData[ind] = item;
    });
    reset(newFormData);
  };

  const addInput = () => {
    const newInput = {
      id: inputState.length,
      language: true,
      upload: true,
      remove: true,
    };
    setInputState((prevState) => [...prevState, newInput]);
    setVideoRefs((prevRefs) => [...prevRefs, createRef()]);
  };

  const handleClick = (e, i) => {
    setVideos([]);
    // uploadVideoRef.current?.click();
    videoRefs[i].current?.click();
    e?.stopPropagation();
  };
  const handleVideoChange = (e, i) => {
    if (errors[i]) {
      errors[i].videos = null;
    }
    const uploadedFiles = e.target.files;
    if (uploadedFiles.length > 0) {
      setCheckWarningPopup(true);
    }
    setVideoFiles([...videoFiles, ...uploadedFiles]);
    let newVideos = [];
    for (let i = 0; i < uploadedFiles.length; i++) {
      const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
        newVideos.push({
          type: "video",
          url: reader.result,
          file: uploadedFiles[i],
        });
        if (i === uploadedFiles.length - 1) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload mp4 videos",
              "error"
            );
            return;
          }
          // setVideos(prevState => [...prevState, ...newVideos])
          setVideos([...newVideos]);
        }
      };
    }
    handleOpenUploadDialog(`${currentImageIndex}`);
  };
  const handleOpenUploadDialog = (id, edit = false, videos = []) => {
    if (!edit) {
      setVideos(getValues(id));
      setDialogState({ open: true, for: id });
    } else {
      setVideos(videos);
      setDialogState({ open: true, videos, for: id });
    }
  };
  const handleCloseUploadDialog = () =>
    setDialogState({ open: false, for: undefined });

  const onSubmit = (data) => {
    const objectArray = Object.values(data);
    setVideoData([]);
    setVideoData((prevData) => [
      ...prevData,
      prevData.length > 0
        ? objectArray?.map((val) => prevData[0]?.push(val))
        : objectArray,
    ]);
    setUpdateVideoValue(true);
    handleCloseVideosTemplateDialog();
  };
  const handleDelete = (i) => {
    // setInitialId(i)
    // if(videos.length<1){
    //     setVideos([])
    // setValue(`${i}.videos`, []);
    // setValue(`undefined`, []);
    // }
    // else{
    setCheckWarningPopup(true);
    const tempVideos = [...videos];
    tempVideos.splice(0, 1);
    setVideos(tempVideos);
    if (inputState.length > 0) {
      let updatedInputState = [...inputState]; // create a copy of inputState
      updatedInputState[i] = {
        // update the object at index i
        ...updatedInputState[i], // spread the current object's properties
        videosData: inputState[i].videosData.slice(1), // create a new array without the first element
      };
      setInputState(updatedInputState);
      let val = getValues(`${i}`);

      delete val.videos[0];
      val.videos.splice(0, 1);
      setValue(`${i}.videos`, val.videos);
    } else {
      let val = getValues(`${i}`);

      delete val.videos[0];
      val.videos.splice(0, 1);
      setValue(`${i}.videos`, val.videos);
    }
  };

  return (
    <Dialog
      onClose={() => handleCloseVideosTemplateDialog(checkWarningPopup)}
      // onClose={() => handleCloseVideosTemplateDialog()}
      open={openVideoTemplateDialog}
      sx={{ height: "90vh", marginTop: "25px" }}
    >
      <DialogTitle
        sx={{
          fontFamily: "HK Grotesk",
          color: "#2e739c",
          fontWeight: "700",
          textAlign: "center",
          fontSize: "26px",
        }}
      >
        {editDetails?.length > 0 ? "Update" : "Add"} Video Templates
      </DialogTitle>
      <IconButton
        aria-label="close"
        onClick={() => handleCloseVideosTemplateDialog(checkWarningPopup)}
        // onClick={() => handleCloseVideosTemplateDialog()}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
          border: "1px solid #9e9e9e",
          borderRadius: "50%",
        }}
      >
        <CloseIcon />
      </IconButton>
      <Box sx={{ m: 3, overflowX: "hidden" }}>
        <form onSubmit={handleSubmit(onSubmit)}>
          {inputState.map((input, i) => {
            return (
              <div className="box" key={input.id}>
                <Grid container>
                  <Grid item xs={6} md={6} lg={6} xl={6}>
                    {input.language && (
                      <Grid container spacing={2} sx={{ mt: 0.5 }}>
                        <Grid
                          item
                          xs={12}
                          md={12}
                          lg={12}
                          xl={12}
                          sx={{ width: "280px" }}
                        >
                          <FormControl
                            size="small"
                            fullWidth
                            sx={{
                              "& .MuiInputBase-input": {
                                borderRadius: "14px!important",
                              },
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderRadius: "14px",
                              },
                            }}
                          >
                            <b
                              style={{
                                fontFamily: "HK Grotesk",
                                color: "#356F92",
                                fontSize: "16px",
                                marginLeft: "8px",
                                position: "relative",
                                bottom: "5px",
                              }}
                            >
                              Language
                            </b>
                            <Select
                              labelId="demo-select-small"
                              id="demo-select-small"
                              // label="Langauge"
                              {...register(`${i}.language`, {
                                required: "Please select Language",
                              })}
                              defaultValue={input?.languageValue}
                              onChange={() => setCheckWarningPopup(true)}
                            >
                              {languages &&
                                languages.map((s) => {
                                  return (
                                    <MenuItem
                                      native
                                      key={s.id}
                                      sx={{ width: "100%" }}
                                      value={s.language}
                                      size="small"
                                    >
                                      {s.language}
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                            <FormHelperText class="p-error">
                              {errors &&
                                errors[i] &&
                                errors[i].language?.message}
                            </FormHelperText>
                          </FormControl>
                        </Grid>
                      </Grid>
                    )}
                    {input.remove && inputState.length !== 1 && (
                      <Grid item xs={3} sx={{ mt: 1, marginLeft: "-15px" }}>
                        <Button
                          variant="outlined"
                          sx={{ borderRadius: 4 }}
                          className="button-tr-citizen-admin"
                          onClick={() => {
                            removeInput(input.id);
                            setCheckWarningPopup(true);
                          }}
                        >
                          Remove
                        </Button>
                        {/* } */}
                      </Grid>
                    )}
                  </Grid>
                  <Grid
                    item
                    xs={6}
                    md={6}
                    lg={6}
                    xl={6}
                    sx={{ marginTop: "20px" }}
                  >
                    <div
                      style={{
                        fontFamily: "HK Grotesk",
                        color: "#356F92",
                        fontSize: "16px",
                        fontWeight: "bold",
                        display: "flex",
                        justifyContent: "center",
                        whiteSpace: "nowrap",
                        position: "relative",
                        bottom: "10px",
                        color: "#356F92",
                      }}
                    >
                      Video Preview
                    </div>
                    {input.upload && (
                      <Grid
                        item
                        xs={6}
                        sx={{
                          pr: 1,
                          pl: 1,
                          margin: "0 auto",
                          border: "dotted 3px #1976d2",
                          padding: "50px",
                          width: "40%",
                          borderRadius: "14px",
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            "& > :not(style)": {
                              width: 25,
                              height: 30,
                            },
                          }}
                        >
                          <div>
                            <IconButton
                              color="primary"
                              aria-label="Upload"
                              onClick={(e) => {
                                handleClick(e, i);
                                setCurrentImageIndex(i);
                              }}
                              sx={{}}
                            >
                              <UploadIcon />
                            </IconButton>
                            <br />
                            <input
                              type="file"
                              {...register(`${i}.videos`, {
                                required: "Please add video",
                              })}
                              ref={videoRefs[i]}
                              multiple
                              onChange={(e) => handleVideoChange(e, i)}
                              onClick={(event) => {
                                event.target.value = null
                              }}
                              accept="video/mp4"
                              style={{ display: "none" }}
                            />

                            <div
                              style={{
                                display: "flex",
                                justifyContent: "center",
                                whiteSpace: "nowrap",
                                marginLeft: "4px",
                              }}
                            >
                              Add Video
                            </div>
                          </div>
                          {/* {
                                                    getValues(`${i}.videos`)?.length > 0 && (
                                                        <div>
                                                            <video controls src={getValues(`${i}.videos`)[0].url} alt="" style={{ width: 250, height: 144, position: "relative", top: "45%", left: "0", transform: "translate(-50%, -50%)", background: "#fff" }} />
                                                            <img src={closeIconp} id={i} onClick={() => handleDelete(i)} className="imageclose-imge" />
                                                            {
                                                                getValues(`${i}.videos`).length > 1 ? <Link style={{ whiteSpace: 'nowrap', marginLeft: "-50px", position: "relative", top: "-280%" }} onClick={() => handleOpenUploadDialog(`${i}.videos`)}>+{getValues(`${i}.videos`).length - 1} More {getValues(`${i}.videos`).length > 2 ? "videos" : "Videos"} </Link> :
                                                                    <Link style={{ whiteSpace: 'nowrap', marginLeft: "-50px", position: "relative", top: "-280%" }} onClick={() => handleOpenUploadDialog(`${i}.videos`)}>Add More Videos </Link>
                                                            }
                                                        </div>
                                                    )
                                                } */}
                          {input?.videosData?.length > 0 && (
                            <div>
                              <VideoPlayerPreview
                                width="250"
                                height="150"
                                className="mar-class-video object-video"
                                // className={`fetchVideo${i}`}
                                src={input?.videosData[0].url
                                  ? input?.videosData[0].url
                                  : input?.videosData[0]}
                                controls
                                onClick={() =>
                                  handleOpenUploadDialog(
                                    i,
                                    true,
                                    input?.videosData
                                  )
                                }
                              />
                             
                              <img
                                src={closeIconp}
                                id={i}
                                onClick={() => handleDelete(i)}
                                className="imageclose-imge-preview-video"
                              />
                              {input?.videosData?.length > 1 ? (
                                <Link
                                  style={{
                                    whiteSpace: "nowrap",
                                    marginLeft: "-50px",
                                    position: "relative",
                                    top: "-98%",
                                  }}
                                  onClick={() =>
                                    handleOpenUploadDialog(
                                      i,
                                      true,
                                      input?.videosData
                                    )
                                  }
                                >
                                  +{input?.videosData?.length - 1} More{" "}
                                  {input?.videosData?.length > 2
                                    ? "Videos"
                                    : "Video"}{" "}
                                </Link>
                              ) : (
                                <Link
                                  style={{
                                    whiteSpace: "nowrap",
                                    marginLeft: "-50px",
                                    position: "relative",
                                    top: "-98%",
                                  }}
                                  onClick={() =>
                                    handleOpenUploadDialog(
                                      i,
                                      true,
                                      input?.videosData
                                    )
                                  }
                                >
                                  Add More Videos{" "}
                                </Link>
                              )}
                            </div>
                          )}
                        </Box>
                      </Grid>
                    )}
                    {errors[i] && (
                      <FormHelperText error class="p-error center">
                        {errors && errors[i] && errors[i].videos?.message}
                      </FormHelperText>
                    )}
                  </Grid>
                  <hr style={{ width: "96%", marginTop: "40px" }}></hr>
                </Grid>
              </div>
            );
          })}
        </form>
        <div className="btn-box">
          <React.Fragment>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                mb: 2,
                mt: 2,
                marginLeft: "-15px",
              }}
            >
              <Button
                variant="outlined"
                sx={{ borderRadius: 4 }}
                className="button-tr-citizen-admin"
                startIcon={<AddIcon sx={{ mt: "5px" }} />}
                onClick={() => {
                  addInput();
                }}
              >
                Add More
              </Button>
              <Box sx={{ flex: "1 1 auto" }} />
            </Box>
          </React.Fragment>
        </div>
      </Box>
      <DialogActions sx={{ justifyContent: "center", mb: 2 }}>
        <Button

          sx={{
            p: 1,
            mr: 1,
            backgroundColor: "#ef7335",
            borderRadius: 4,
            width: "250px"
          }}
          className="button-tr-2"
          type="submit"
          onClick={handleSubmit(onSubmit)}
        >
          {editDetails?.length > 0 ? "Update Video Template" : "Add Video Template"}
        </Button>
      </DialogActions>
      {videos?.length > 0 && (
        <UploadVideos
          handleCloseUploadDialog={handleCloseUploadDialog}
          state={dialogState}
          setValue={setValue}
          getValue={getValues}
          initialVideos={
            dialogState.for === "edit" ? dialogState.videos : videos
          }
          setVideosNew={setVideos}
          setInputData={setInputState}
          inputData={inputState}
          fileFormats={fileFormats}
          setCheckWarningPopup={setCheckWarningPopup}
        />
      )}
    </Dialog>
  );
};

export default AddVideoTemplates;
