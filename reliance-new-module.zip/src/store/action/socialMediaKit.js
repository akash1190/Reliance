import axios from "axios"
import Constant from "../../utils/constant"
import { SOCIAL_MEDIA_KIT_FAILURE,SOCIAL_MEDIA_KIT_REQUEST,SOCIAL_MEDIA_KIT_SUCCESS} from "./types"

export const socialMediaKitRequest = () => {
    return {
        type: SOCIAL_MEDIA_KIT_REQUEST,
        payload:[]
    }
}
export const socialMediaKitSuccess = value => {
    return {
        type: SOCIAL_MEDIA_KIT_SUCCESS,
        payload: value
    }
}
export const socialMediaKitFailure = error => {
    return {
        type: SOCIAL_MEDIA_KIT_FAILURE,
        payload: error
    }
}

export const getSocialMediaKit = (query) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");

    dispatch(socialMediaKitRequest)
    await axios.get(Constant.BASE_URL + `/api/socialMedia/getbyInitiative/${query}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
    .then(response => {
        const result = response?.data[0]
        dispatch(socialMediaKitSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(socialMediaKitFailure(errorMsg))
    })
}


