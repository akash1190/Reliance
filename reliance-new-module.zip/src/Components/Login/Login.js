import React, { useState } from "react";
import { useNavigate } from "react-router";
import {
  Button,
  FormControl,
  FormControlLabel,
  Grid,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  TextField,
} from "@mui/material";
import mp from "../../asserts/images/MP_logo_w.png";
import backgroundImage from "../../asserts/images/par1.jpg";
import "./Login.css";
import { useDispatch } from "react-redux";
import { getToken } from "../../store/action/userLogin";
import { useForm } from "react-hook-form";
import axios from "axios";
import Constant from "../../utils/constant";
import { useEffect } from "react";
import { LoaderIcon } from "react-hot-toast";
import { useNotificationContext } from "../../utils/NotificationContext";
import { padding } from "@mui/system";

function Login({ setId, paramId }) {
  // const { showNotification } = useNotificationContext();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const [user, setUser] = useState("");
  const [pwd, setPwd] = useState("");

  const [loading, setLoading] = useState(true);
  const dispatch = useDispatch();
  const Tokens = localStorage.getItem("tokenDetails");
  const navigate = useNavigate();
  const navigateToPage = (id) => {
    //mp 1002, admin 1004, citizen 1003/, leader/1001
  };

  const handleLogin = async (id) => {
    let payload = {
      userid: id?.replace(/[']/g, ""),
    };
    // dispatch(getToken(payload))
    await axios
      .post(Constant.BASE_URL + `/api/auth/signin`, payload)

      .then(async (response) => {
        const CryptoJS = require("crypto-js");
        let val = response.data.token;
        localStorage.setItem("tokenDetails", val);
        response.data?.role == "mp" &&
          localStorage.setItem(
            "mpId",
            CryptoJS.AES.encrypt(response.data?.mpid.toString(), Constant.idKey)
          );

        let id = response.data?.roleId;

        if (id == 1004) {
          localStorage.setItem(
            "userId",
            CryptoJS.AES.encrypt("2", Constant.roleKey)
          );

          navigate("/SevaInitiatives");
          window.location.reload(true);
        } else if (id == 1002) {
          localStorage.setItem("Referal",response.data.refferalCode)
          localStorage.setItem(
            "userId",
            CryptoJS.AES.encrypt("1", Constant.roleKey)
          );

          navigate("/MpHome", 0);
          window.location.reload(true);
        } else if (id == 1001) {
          localStorage.setItem(
            "userId",
            CryptoJS.AES.encrypt("3", Constant.roleKey)
          );

          navigate("/AdminHome");
          window.location.reload(true);
        }
      })
      .catch((error) => {
        setLoading(false)
        const errorMsg = error.message;

        localStorage.setItem("tokenDetails", "");
      });
  };

  useEffect(() => {
    if(!paramId)
      setLoading(false);
    if (paramId) {
      setLoading(true);
      handleLogin(paramId);
    }
  }, [paramId]);

  return (
    <>
    
        
      
      {loading ? <div className="loader"><LoaderIcon />
          <span>Loading...</span>
          </div>
      : (
        <div class="text-wrapper-login">
          <div class="title" data-content="404">
            403 - ACCESS DENIED
          </div>

          <div class="subtitle">
            Oops, You don't have permission to access this page.
          </div>
          <div class="isi">
            A web server may return a 403 Forbidden HTTP status code in response
            to a request from a client for a web page or resource to indicate
            that the server can be reached and understood the request, but
            refuses to take any further action. Status code 403 responses are
            the result of the web server being configured to deny access, for
            some reason, to the requested resource by the client.
          </div>
          <div class="btncontainer">
          <div class="buttonslogin" >
            <a class="buttonlogin aa" href="/loginusers.html">
              Test Login
            </a>
          </div>
          <div class="buttonslogin">
            <a class="buttonlogin aa" href="https://www.narendramodi.in">
              Go to Login
            </a>
          </div>
          </div>
        </div>
      )}</>
  );
}

export default Login;
