import {
  Card,
  CardContent,
  CardMedia,
  IconButton,
  Typography,
  Box,
  Dialog,
  DialogTitle,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import "./RowImage.css";
import CancelSharpIcon from "@mui/icons-material/CancelSharp";
import CloseIcon from "@mui/icons-material/Close";
import ShareIcon from "@mui/icons-material/Share";
import { useNavigate } from "react-router";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";
import Share from "../../ReusableComponents.js/Share";
import { fontFamily } from "@mui/system";
import UpdateInitiativeReportDetails from "../AllInitiativeReports/UpdateInitiativeReportDialog";
import { useDispatch, useSelector } from "react-redux";
import { useNotificationContext } from "../../../utils/NotificationContext";
import { getIntiativesReportByInitiativeIdAndMpId } from "../../../store/action/ongoingSevaInitiativesList";
import zIndex from "@mui/material/styles/zIndex";

function RowImage({
  title,
  data,
  user,
  isOngoingSevaClick,
  handleOpenInitiativeDetails,
  mpName,
  onSevaEvent,
  onMediaCoverage,
  readonly,
  eventByMpId,
  mySeva,
  mpId
}) {
  const [personalDetails, setPersonalDetails] = useState();
  const { showNotification } = useNotificationContext();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [mediaShare, setMediaShare] = useState(false)
  const [shareData, setShareData] = useState({})
  const [initiativeName, setInitiativeName] = useState();
  const [ongoingDetails, setOngoingDetails] = useState();
  const [openUpdateIntiativeDialog, setOpenUpdateInitiativeDialog] =
    useState(false);
  const initiativeReportDetailsByMPIdAndIntiativeId = useSelector(
    (state) => state?.initiativeReportDetailsByMPIdAndIntiativeId?.data
  );
  // const handleClear=(e)=>{
  //     updateData(e)
  //   }
  const details = (!mySeva && !mpId) ? data.length > 0 && data?.slice(0, 10) : data;

  const handleShare = (e, data) => {
    e.stopPropagation()
    e.preventDefault()
    setShareData(data)
    setMediaShare(true);

  };
  const handleCardClick = (data) => {
    setPersonalDetails(data);
    // !user ?
    // navigate("/SevaUpdates/allInitiativeReports") :
    navigate("/SevaUpdates/allInitiativeReports", {
      state: {
        readonly: readonly,
        user: user,
        // initiativeDetails: initiativeDetails,
        initiativeId: data?.id,
        initiativeName: data?.initiativeName,
        eventByMpId: eventByMpId,
        mpName: mpName,
        mpId: mpId
      },
    });
  };

  const handleOpenInitiativeReport = async (dataVal) => {
    try {
      const response = await dispatch(
        getIntiativesReportByInitiativeIdAndMpId(dataVal?.id, mpId)
      );
      if (response.status === 200 || response.status === 201) {
        if (response.data?.message) {
          showNotification("Error", response.data?.message, "error");
        }
        else if (response?.data?.reportdata.length === 0) {
          showNotification("Initiative report has not been submitted yet for this initiative", false);
        }
        else {
          setInitiativeName(dataVal?.initiativeName);
          setOpenUpdateInitiativeDialog(true);
          setOngoingDetails(dataVal);
        }
      }
    } catch (error) {
      showNotification("Error", error, 'error');
    }

  };

  const handleCloseUpdateInitiativeDetails = (
    reset,
    reportFiles,
    setUploadFiles
  ) => {
    // setShowUpdate(false);
    reset();
    reportFiles([]);
    setUploadFiles([]);
    setOpenUpdateInitiativeDialog(false);
  };


  return (
    <div>
      {/* <h2 className='row__title'>{title}</h2> */}
      <div className="itemfixed3">
        <div>
          <Tabs
            // value={value}
            // onChange={handleChange}
            variant="scrollable"
            scrollButtons
            aria-label="visible arrows tabs example"
            sx={{
              [`& .${tabsClasses.scrollButtons}`]: {
                "&.Mui-disabled": { opacity: 0.3 },
              },
            }}
          >
            {details &&
              details?.map((dataVal, index) => (
                <Card
                  className="clickable"
                  sx={{ minWidth: 235, mr: 3, mb: 3, borderRadius: "15px" }}
                  onClick={() => {
                    isOngoingSevaClick
                      ? mpName
                        ? (
                          mySeva ? handleOpenInitiativeReport(dataVal) :
                            handleOpenInitiativeDetails(
                              dataVal,
                              title,
                              isOngoingSevaClick
                            )
                        )
                        : handleCardClick(dataVal)
                      : handleOpenInitiativeDetails(dataVal, title);
                  }}
                >
                  <div style={{ position: "relative" }}>
                    <CardMedia
                      sx={{
                        // filter: "brightness(50%)",
                        // // backgroundColor: "rgb(0 0 0 / 30%)",
                        borderRadius: "15px",
                        background: "transparent linear-gradient(180deg, #FFFFFF00 0%, #000000 100%) 0% 0% no-repeat padding-box",


                      }}
                      id={index}
                      component="img"
                      loading="lazy"
                      height="150"
                      width="190"
                      src={
                        (isOngoingSevaClick || onSevaEvent)
                          ? dataVal?.coverimage && JSON.parse(dataVal?.coverimage)[0]
                          : dataVal?.media && JSON.parse(dataVal?.media)[0]
                      }

                      // image={data.image}
                      onError={(e) => (e.target.src = NoImageFound)}
                      alt="new Image"
                      className="blackoverlay"
                    />
                    <ShareIcon className='shareicone customshare' key={index} onClick={(e) => {
                      handleShare(e, dataVal)
                    }} />
                    <div className="dibgover"  style={{marginTop:"17%"}}></div>
                    <div
                    className="ecclipseonwidthnewrow1"
                      style={{
                        position: "absolute",
                        color: "white",
                        top: 100,
                        left: "15%",
                        transform: "translateX(-15%)",
                        textTransform: "capitalize",
                        // backgroundColor: "rgb(0 0 0 / 30%)",
                        width: " 234px",
                        height: "50px",
                        paddingLeft: "10px",
                        fontFamily: 'HK Grotesk',
                        fontSize: "16px",
                        zIndex:"999",
                      }}
                    >
                      <p className={`ecclipseonwidthnewrow  ${ dataVal?.eventTitle?.length > 30 || dataVal?.title?.length > 30 || dataVal?.projecttitle?.length > 30  ? 'class30' : ''}${ dataVal?.initiativeName?.length < 30  ? 'class30-ini' : ''}`}>
                        {" "}
                        {isOngoingSevaClick
                          ? dataVal?.initiativeName
                          : onSevaEvent
                            ? dataVal?.eventTitle
                            : onMediaCoverage
                              ? dataVal?.title
                              : dataVal?.projecttitle}
                      </p>
                      <span  style={{
                        fontFamily: 'HK Grotesk',
                        fontSize: "14px",
                      }}>
                        {isOngoingSevaClick
                          ? null
                          : onSevaEvent
                            ? dataVal?.location
                            : onMediaCoverage
                              ? dataVal?.type
                              : dataVal?.status}
                      </span>
                      <p></p>
                    </div>
                    <div></div>
                  </div>
                </Card>

              ))}
          </Tabs>
          <Dialog open={mediaShare} onClose={() => setMediaShare(false)}>
            <DialogTitle>
              <IconButton
                aria-label="close"
                onClick={() => setMediaShare(false)}
                sx={{
                  position: "absolute",
                  right: 8,
                  top: 8,
                  color: (theme) => theme.palette.grey[500],
                  border: "1px solid #9e9e9e",
                  borderRadius: "50%",
                  padding: "2px",
                  cursor: "pointer",
                }}
              >
                <CloseIcon />
              </IconButton>
              <Typography
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  color: "#357092",
                  fontFamily: "HK Grotesk",
                  fontSize: "26px",
                  fontWeight: "bold",
                }}
              >
                Share to Social Media
              </Typography>

              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  marginTop: "25px",
                  gap: "40px",
                }}
              >
                <Share data={shareData} title={title} />

              </div>
              {/* <CloseIcon onClick={() => setAddMembers(false)} /> */}
            </DialogTitle>
          </Dialog>
          {openUpdateIntiativeDialog &&
            <UpdateInitiativeReportDetails
              openUpdateIntiativeDialog={openUpdateIntiativeDialog}
              details={ongoingDetails}
              initiativeName={initiativeName}
              handleCloseUpdateInitiativeDetails={
                handleCloseUpdateInitiativeDetails
              }
              initiativeReportDetailsByMPIdAndIntiativeId={initiativeReportDetailsByMPIdAndIntiativeId}
            />}
        </div>
      </div>
    </div>
  );
}

export default RowImage;
