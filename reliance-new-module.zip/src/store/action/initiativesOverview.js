import axios from "axios"
import Constant from "../../utils/constant"
import { INITIATIVES_OVERVIEW_FAILURE,INITIATIVES_OVERVIEW_REQUEST,INITIATIVES_OVERVIEW_SUCCESS} from "./types"

export const initiativeOverviewRequest = () => {
    return {
        type: INITIATIVES_OVERVIEW_REQUEST,
        payload:{ requested: 0,
            ongoing: 0,
            events: 0,}
    }
}
export const initiativeOverviewSuccess = value => {
    return {
        type: INITIATIVES_OVERVIEW_SUCCESS,
        payload: value
    }
}
export const initiativeOverviewFailure = error => {
    return {
        type: INITIATIVES_OVERVIEW_FAILURE,
        payload: error
    }
}

export const overViewInitiatives = (query) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(initiativeOverviewRequest)
    await axios.get(Constant.BASE_URL + `/api/initiative/statusbymp/${query}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
    .then(response => {
        const result = response.data
        dispatch(initiativeOverviewSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(initiativeOverviewFailure(errorMsg))
    })
}


