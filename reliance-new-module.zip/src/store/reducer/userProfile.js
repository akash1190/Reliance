import { GET_USER_PROFILE_FAILURE, USER_PROFILE_REQUEST, GET_USER_PROFILE_SUCCESS} from "../action/types";

const initialState = {
    data: {},
    error: ''
};

export const getUserProfileReducer = (state = initialState, action) => {
    switch (action.type) {
        case  USER_PROFILE_REQUEST:
            return {
                state,
            }
        case  GET_USER_PROFILE_SUCCESS:
            return {
                data: action.payload
            }
        case  GET_USER_PROFILE_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}