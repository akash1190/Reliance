import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import one from "../../../asserts/images/1.jpg";
import two from "../../../asserts/images/4.jpg";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";
import AddMediaCoverage from "../AddMediaCoverage/AddMediaCoverage";
import Moment from "moment";
import AddDevelopmentProjects from "../AddDevelopmentProjects/AddDevelopmentProjects";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import AddSevaEvent from "../AddSevaEvent/AddSevaEvent";
import CreateNewEvent from "../AddSevaEvent/CreateNewEvent";
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  Grid,
  Typography,
} from "@mui/material";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import PreviewImagesDialog from "./PreviewImagesDialog";
import Share from "../../ReusableComponents.js/Share";
import Linkify from 'linkify-react';

const InitiativeDetails = ({
  handleCloseInitiativeDetails,
  openInitiativeDetailsDialog,
  details,
  onViewClickTitle,
  mpName,
  uniqueInitiativeClick,
  isEdit,
  mpId,
  mpProfileData,
  initiativeName,
  initiativeReportDetailsByMPIdAndIntiativeId,
  checkMySeva,
  setDevelopmentProjectsByMpId,
  setOpedsByMpId,
  setEventByMpId,
  opedsByMpId,
  developmentProjectsByMpId,
  viewAllCheck,
  eventByMpId,
  user,
}) => {
  const [openMediaCoverage, setOpenMediaCoverage] = useState(false);
  const [isMediaCoverageEdit, setIsMediaCoverageEdit] = useState(false);
  const [isDevelopmentProjectsEdit, setIsDevelopmentProjectsEdit] =
    useState(false);
  const [isSevaEventEdit, setIsSevaEventEdit] = useState(false);
  const [openDevelopmentProjects, setOpenDevelopmentProjects] = useState(false);
  const [openCreateEventDialog, setOpenCreateEventDialog] = useState(false);
  const [openPreviewImages, setOpenPreviewImages] = useState(false);
  const [previewImageIndex, setPreviewImageIndex] = useState(0);
  const [files, setFiles] = useState([]);
  const [onFilesSelect, setOnFilesSelect] = useState(false);
  const [reportFiles, setReportFiles] = useState([]);
  const [mediaShare, setMediaShare] = useState(false);
  const [shareData, setShareData] = useState({});
  const reportsData =
    initiativeReportDetailsByMPIdAndIntiativeId &&
    initiativeReportDetailsByMPIdAndIntiativeId?.reportdata;
  const eventsData =
    initiativeReportDetailsByMPIdAndIntiativeId &&
    initiativeReportDetailsByMPIdAndIntiativeId?.Eventdata;
  useEffect(() => {
    if (details) {
      setFiles(details?.media && JSON.parse(details?.media));
    }
  }, [details]);
  // const url = details?.url ? new URL(details?.url.startsWith("http") ? details?.url : "http://" + details?.url) : "";
  useEffect(() => {
    if (reportsData) {
      setReportFiles(reportsData?.media && JSON.parse(reportsData?.media));
    }
  }, [reportsData]);

  const handleOpenMediaCoverage = () => {
    setOpenMediaCoverage(true);
  };
  const handleCloseMediaCoverage = () => {
    if (!viewAllCheck) {
      setOpedsByMpId(false);
    }
    setOpenMediaCoverage(false);
  };

  const handleOpenDevelopmentProjects = () => {
    setOpenDevelopmentProjects(true);
  };
  const handleCloseDevelopmentProjects = () => {
    if (!viewAllCheck) {
      setDevelopmentProjectsByMpId(false);
    }
    setOpenDevelopmentProjects(false);
  };

  const handleOpenCreateEvent = () => {
    setOpenCreateEventDialog(true);
  };
  const handleCloseCreateEvent = () => {
    if (!viewAllCheck) {
      setEventByMpId(false);
    }
    setOpenCreateEventDialog(false);
  };

  const handleOpenPreviewImages = (file, index = 0) => {
    setPreviewImageIndex(index)
    setOpenPreviewImages(true);
  };
  const handleClosePreviewImages = () => {
    setOnFilesSelect(false);
    setOpenPreviewImages(false);
  };

  const titleName = () => {
    if (onViewClickTitle === "Seva aur Samarpan Campaign") {
      return `Event Conducted by ${details?.user?.user_name}`;
    } else if (onViewClickTitle === "OP-ed's, Books & Media Coverage of") {
      return `${details.title ?? ""}`;
    } else if (onViewClickTitle === "Development Projects") {
      return `${details.projecttitle ?? ""}`;
    } else if (
      onViewClickTitle === "Ongoing Seva Initiatives" ||
      uniqueInitiativeClick
    ) {
      return `${
        initiativeName ? initiativeName ?? "" : details?.initiativeName ?? ""
      }`;
    }
  };

  const onEditClick = () => {
    if (onViewClickTitle === "Seva aur Samarpan Campaign") {
      setIsSevaEventEdit(true);
      handleOpenCreateEvent();
      if (checkMySeva) {
        setEventByMpId(true);
      }
      // return `Event Conducted by ${details.personName}`
    } else if (onViewClickTitle === "OP-ed's, Books & Media Coverage of") {
      setIsMediaCoverageEdit(true);
      handleOpenMediaCoverage();
      if (checkMySeva) {
        setOpedsByMpId(true);
      }
      // handleCloseInitiativeDetails();
    } else if (onViewClickTitle === "Development Projects") {
      setIsDevelopmentProjectsEdit(true);
      handleOpenDevelopmentProjects();
      if (checkMySeva) {
        setDevelopmentProjectsByMpId(true);
      }
      // return `${details.projecttitle}`
    }
  };

  const handleShare = (e, data) => {
    setShareData(data);
    setMediaShare(true);
  };

  const handlePreview = (file) => {
    const images = ["jpg", "gif", "png", "svg", "jfif"];
    const videos = ["mp4", "3gp", "ogg"];
    const url = new URL(file);
    const extension = url?.search.split(".")[1];
    if (details && images.includes(extension)) {
      return (
        <img
          src={file}
          alt="Preview"
          onError={(e) => (e.target.src = NoImageFound)}
          className="form-img__img-preview-invide-ini"
          style={{ marginLeft: "25px" }}
        />
      );
    } else if (details && videos.includes(extension)) {
      return (
        <video controls className="form-img__img-preview-invide-ini" style={{ marginLeft: "25px" }}>
          <source
            src={typeof file === "string" ? file : file.url}
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      );
    }
  };

  return (
    // <div style={{
    //     minWidth: "70vh",
    //     margin: "0 50% 0 50%",

    //     minHeight: "95vh"
    // }}>
    <>
      <Dialog
        open={openInitiativeDetailsDialog}
        onClose={handleCloseInitiativeDetails}
        sx={{ height: "96vh", marginTop: "15px" }}
      >
        {/* <BootstrapDialog
                    onClose={handleCloseInitiativeDetails}
                    aria-labelledby="customized-dialog-title"
                    open={openInitiativeDetailsDialog}
                    sx={{ height: "90vh", marginTop: "20px" }}

                > */}
        <IconButton
          aria-label="close"
          onClick={handleCloseInitiativeDetails}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
            border: "1px solid #9e9e9e",
            borderRadius: "50%",
            padding: "2px",
            cursor: "pointer",
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogTitle
          id="customized-dialog-title"
          onClose={handleCloseInitiativeDetails}
        >
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <h6
              style={{
                fontFamily: "HK Grotesk",
                color: "#2C2C2C",
                fontSize: "20px",
                fontWeight: "bolder",
                textTransform: "capitalize",
              }}
              title={
                details?.eventTitle ? details?.eventTitle : ""
              }
            >
              {onViewClickTitle
                ? onViewClickTitle === "OP-ed's, Books & Media Coverage of"
                  ? "Books & Media Coverage of"
                  : onViewClickTitle === "Ongoing Seva Initiatives"
                    ? `Initiative Report by ${reportsData?.user?.user_name ?? ""}`
                    : (details?.eventTitle ? details.eventTitle.slice(0, 30) + (details.eventTitle.length > 30 ? "..." : "") : 
                    `${onViewClickTitle}`)
                : `Initiative Report by ${details?.user?.user_name ?? ""}`}
            </h6>
            <h1
              style={{
                fontFamily: "HK Grotesk",
                color: "#356F92",
                fontSize: "26px",
                fontWeight: "bolder",
                textTransform: "capitalize",
              }}
            >
              {titleName()}
            </h1>
          </div>
          <hr></hr>
        </DialogTitle>
        <DialogContent sx={{ mt: -1.5 }}>
          {onViewClickTitle === "Ongoing Seva Initiatives" ||
          uniqueInitiativeClick ? (
            <div className="text-center pt-1">
              {reportsData?.user?.user_avatar ? (
                <img
                  src={reportsData?.user?.user_avatar}
                  className="img-circle leader-circle-img mr-1"
                  width="80"
                  height="80px"
                  onError={e=>e.target.value=<AccountCircleIcon
                    sx={{ fontSize: "xx-large", width: "80px", height: "80px" }}
                  />}
                />
              ) : (
                <AccountCircleIcon
                  sx={{ fontSize: "xx-large", width: "80px", height: "80px" }}
                />
              )}
            </div>
          ) : (
            <div className="text-center pt-1">
              {details?.user?.user_avatar ? (
                <img
                  src={details?.user?.user_avatar}
                  className="img-circle leader-circle-img mr-1"
                  width="80"
                  height="80px"
                />
              ) : (
                <AccountCircleIcon
                  sx={{ fontSize: "xx-large", width: "80px", height: "80px" }}
                />
              )}
            </div>
          )}
          <div className="card-content">
            {(onViewClickTitle === "Ongoing Seva Initiatives" ||
              uniqueInitiativeClick) && (
              <div>
                <span
                  style={{
                    fontFamily: "HK Grotesk",
                    color: "#11243D",
                    fontSize: "15px",
                    fontWeight: "bold",
                  }}
                >
                  {reportsData?.user?.designation ?? ""}
                  {reportsData?.user?.party?.length>0
                    ? ", " + reportsData?.user?.party
                    : ""}
                </span>
                <br />
                <span
                  className="constituency"
                  style={{
                    fontFamily: "HK Grotesk",
                    color: "#707A89",
                    fontSize: "14px",
                    fontWeight: "bold",
                  }}
                >
                  Constituency :{" "}
                  {reportsData?.user?.constituency_name
                    ? reportsData?.user?.constituency_name
                    : ""}
                </span>
                <br />
                <div
                  style={{
                    display: "inline-block",
                    background: "#fef6f2",
                    padding: "5px",
                    borderRadius: "10px",
                    marginTop: "10px",
                  }}
                >
                  Participants: {reportsData?.participant ?? ""}
                </div>
              </div>
            )}
            {(onViewClickTitle === "Seva aur Samarpan Campaign" ||
              onViewClickTitle === "Development Projects" ||
              onViewClickTitle === "OP-ed's, Books & Media Coverage of") && (
              <h2
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "22px",
                  fontWeight: "bold",
                }}
              >
                {details?.user?.user_name ?? ""}
              </h2>
            )}
            {(onViewClickTitle === "OP-ed's, Books & Media Coverage of" ||
              onViewClickTitle === "Development Projects") && (
              <div>
                <span
                  style={{
                    fontFamily: "HK Grotesk",
                    color: "#11243D",
                    fontSize: "15px",
                    fontWeight: "bold",
                  }}
                >
                  {details?.user?.designation ?? ""}
                </span>
                <br />
                <span
                  style={{
                    fontFamily: "HK Grotesk",
                    color: "#707A89",
                    fontSize: "14px",
                    fontWeight: "bold",
                  }}
                >
                  {details?.user?.state_name ?? ""}
                </span>
                <br />
              </div>
            )}
            {onViewClickTitle === "Seva aur Samarpan Campaign" && (
              <span
                className="initial"
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#11243D",
                  fontSize: "15px",
                  fontWeight: "bold",
                }}
              >
                {details?.user?.designation ??
                  "" + ", " + details?.user?.state_name ??
                  ""}
              </span>
            )}
            <br />
            {onViewClickTitle === "Seva aur Samarpan Campaign" && (
              <span
                className="constituency"
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#707A89",
                  fontSize: "15px",
                  fontWeight: "bold",
                }}
              >
                {"Constituency" + " : " + details?.user?.constituency_name ??
                  ""}
              </span>
            )}
            <br />
            {onViewClickTitle === "Development Projects" && (
              <div
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#11243D",
                  fontSize: "17px",
                  fontWeight: "bold",
                  display: "inline-block",
                  background: "#fef6f2",
                  padding: "5px",
                  borderRadius: "10px",
                  // width: "200px",
                  marginTop: "-30px",
                  verticalAlign: "30px",
                }}
              >
                Target Date : {Moment(details?.target).format("DD MMM YYYY")}
              </div>
            )}
            {onViewClickTitle === "Seva aur Samarpan Campaign" && (
              <span
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#11243D",
                  fontSize: "17px",
                  fontWeight: "bold",
                  display: "inline-block",
                  background: "#fef6f2",
                  padding: "5px",
                  borderRadius: "10px",
                  marginTop: "10px",
                  // width: "180px",
                }}
                title={
                  details?.eventTitle ? details?.eventTitle : ""
                }
              >
                {(details.eventTitle &&
                  details.eventTitle.slice(0, 30)) ||
                  "-"}
                {details.eventTitle &&
                  details.eventTitle.length > 30
                  ? "..."
                  : ""}
              </span>
            )}
          </div>
          <div style={{ marginTop: "5px" }}>
            <div
              style={{
                fontFamily: "HK Grotesk",
                color: "#356F92",
                fontSize: "16px",
                fontWeight: "bold",
                marginLeft: "55px",
              }}
            >
              {onViewClickTitle === "OP-ed's, Books & Media Coverage of"
                ? "About"
                : onViewClickTitle === "Development Projects"
                ? "About"
                : onViewClickTitle === "Seva aur Samarpan Campaign"
                ? "Event Description"
                : "Initiative Description"}{" "}
              <br />
            </div>
            <div
              style={{
                fontFamily: "HK Grotesk",
                color: "#505050",
                fontSize: "15px",
                fontWeight: "bold",
                marginLeft: "50px",
                height: "85px",
                overflowY: "auto",
                overflowx: "hidden",
                wordBreak: "break-word",
                // border:"1px solid #b6b6b6",
                borderRadius: "20px",
                marginTop: "10px",
                padding: "6px",
                width:"85%"
              }}
            >
              <span title={details?.desc ? details?.desc : ""}>
              {details?.desc ? details?.desc : reportsData?.desc}
              </span>
            </div>
          </div>
          <br />

          {onViewClickTitle === "OP-ed's, Books & Media Coverage of" && (
            <div
              style={{
                fontFamily: "HK Grotesk",
                color: "#356F92",
                fontSize: "16px",
                fontWeight: "bold",
                marginLeft: "55px",
              }}
            >
              Type
              <br />
              <div
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#505050",
                  fontSize: "15px",
                  fontWeight: "bold",
                  // marginLeft: "50px",
                  height: "85px",
                  overflowY: "auto",
                  overflowx: "hidden",
                  wordBreak: "break-word",
                  // border:"1px solid #b6b6b6",
                  borderRadius: "20px",
                  marginTop: "5px",
                  padding: "3px",
                }}
              >
                <span>{details?.type ? details?.type : ""}</span>
              </div>
            </div>
          )}
          {(onViewClickTitle === "OP-ed's, Books & Media Coverage of" ||
            onViewClickTitle === "Development Projects") && (
              <div>
                <span
                  style={{
                    fontFamily: "HK Grotesk",
                    color: "#356F92",
                    fontSize: "16px",
                    fontWeight: "bold",
                    marginLeft: "55px",
                  }}
                >
                  Images
                </span>
                <Box
                  sx={{
                    flexGrow: 1,
                    minWidth: { xs: 300, sm: 300 },
                    marginLeft: "38px",
                  }}
                >
                  {files && files.length > 1 ? (
                    <Tabs
                      variant="scrollable"
                      scrollButtons
                      aria-label="visible arrows tabs example"
                      sx={{
                        [`& .${tabsClasses.scrollButtons}`]: {
                          "&.Mui-disabled": { opacity: 0.3 },
                        },
                        marginLeft: "-45px",
                      }}
                    >
                      {files &&
                        files.map((file, index) => (
                          <Card
                            sx={{ minWidth: 230, mr: 2, marginLeft: "-32px" }}
                            className="bshadow"
                            onClick={() => {
                              handleOpenPreviewImages(file, index)
                              setOnFilesSelect(true)
                            }}
                          >
                            <CardContent>
                              <div key={index}>{handlePreview(file)}</div>
                            </CardContent>
                          </Card>
                        ))}
                    </Tabs>
                  ) : (
                    files &&
                    files.map((file, index) => (
                      <Card
                        sx={{ minWidth: 200, mr: 2, marginLeft: "-32px" }}
                        className=" bshadow"
                        onClick={() => {
                          handleOpenPreviewImages(file, index)
                          setOnFilesSelect(true)
                        }}
                      >
                        <CardContent>
                          <div key={index}>{handlePreview(file)}</div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </Box>
              </div>
            )}
          {(onViewClickTitle === "Ongoing Seva Initiatives" ||
            uniqueInitiativeClick) && (
            <div>
              <div>
                <span
                  style={{
                    fontFamily: "HK Grotesk",
                    color: "#356F92",
                    fontSize: "16px",
                    fontWeight: "bold",
                    marginLeft: "55px",
                  }}
                >
                  Images
                </span>
                <Box
                  sx={{
                    flexGrow: 1,
                    minWidth: { xs: 300, sm: 300 },
                  }}
                >
                  {reportFiles && reportFiles.length > 1 ? (
                    <Tabs
                      variant="scrollable"
                      scrollButtons
                      aria-label="visible arrows tabs example"
                      sx={{
                        [`& .${tabsClasses.scrollButtons}`]: {
                          "&.Mui-disabled": { opacity: 0.3 },
                        },
                      }}
                    >
                      {reportFiles &&
                        reportFiles.map((file, index) => (
                          <Card
                            sx={{ minWidth: 175 }}
                            //commented because more image upload causing image break
                            // sx={{ minWidth: 100, mr: 2 }}
                            className="bshadow"
                              onClick={() => handleOpenPreviewImages(file, index)}
                          >
                            <CardContent onClick={handleOpenPreviewImages}>
                              {/* <img src={file} alt="Preview" style={{ borderRadius: "20px" }} className="form-img__img-preview" /> */}
                              <div key={index}>{handlePreview(file)}</div>
                            </CardContent>
                          </Card>
                        ))}
                    </Tabs>
                  ) : (
                    reportFiles &&
                    reportFiles.map((file, index) => (
                      <Card sx={{ minWidth: 100, mr: 2 }} className="bshadow">
                        <CardContent onClick={handleOpenPreviewImages}>
                          <div key={index}>{handlePreview(file)}</div>
                          {/* <img src={file} alt="Preview" style={{ borderRadius: "20px" }} className="form-img__img-preview" /> */}
                        </CardContent>
                      </Card>
                    ))
                  )}
                </Box>
              </div>
              <div style={{ marginTop: "10px" }}>
                <span
                  style={{
                    fontFamily: "HK Grotesk",
                    color: "#356F92",
                    fontSize: "16px",
                    fontWeight: "bold",
                    marginLeft: "55px",
                  }}
                >
                  {" "}
                  Event Conducted :
                  {initiativeReportDetailsByMPIdAndIntiativeId &&
                    initiativeReportDetailsByMPIdAndIntiativeId?.eventcount}
                </span>
                <div className="gridinirepo">
                  {eventsData && eventsData.length > 1 ? (
                    <Tabs
                      variant="scrollable"
                      scrollButtons
                      aria-label="visible arrows tabs example"
                      sx={{
                        [`& .${tabsClasses.scrollButtons}`]: {
                          "&.Mui-disabled": { opacity: 0.3 },
                        },
                        "& .MuiTabs-flexContainer": { marginLeft: "-25px" },
                      }}
                    >
                      {eventsData &&
                        eventsData.map((item) => (
                          <Card
                            sx={{
                              minWidth: 180,
                              maxWidth: 180,
                              width: 180,
                              ml: "25px",
                              mr: "0!important",
                            }}
                            className="bshadow cardini2"
                          >
                            <CardMedia>
                              <img
                                src={
                                  item?.coverimage &&
                                  JSON.parse(item?.coverimage)[0]
                                }
                                onError={(e) => (e.target.src = NoImageFound)}
                                alt="Preview"
                                style={{ borderRadius: "20px" }}
                                className="form-img__img-preview-ec"
                              />
                            </CardMedia>

                            <CardContent>
                              <div style={{ marginTop: "-12px" }}>
                                <span
                                  title={
                                    item?.eventTitle ? item?.eventTitle : ""
                                  }
                                  style={{
                                    fontFamily: "HK Grotesk",
                                    color: "#2C2C2C",
                                    fontSize: "13px",
                                    fontWeight: "bold",
                                    textTransform: "capitalize",
                                  }}
                                >
                                  {(item.eventTitle &&
                                    item.eventTitle.slice(0, 20)) ||
                                    "-"}
                                  {item.eventTitle &&
                                  item.eventTitle.length > 20
                                    ? "..."
                                    : ""}
                                </span>
                                <br />
                                <span
                                  style={{
                                    fontFamily: "HK Grotesk",
                                    color: "#2C2C2C",
                                    fontSize: "12px",
                                    fontWeight: "bold",
                                  }}
                                >
                                  {Moment(item?.startDate).format(
                                    "DD MMM YYYY"
                                  )}
                                  ,
                                  <span
                                    title={item?.location ? item?.location : ""}
                                    style={{
                                      fontFamily: "HK Grotesk",
                                      color: "#2C2C2C",
                                      fontSize: "12px",
                                      fontWeight: "bold",
                                      textTransform: "capitalize",
                                    }}
                                  >
                                    {(item.location &&
                                      item.location.slice(0, 20)) ||
                                      "-"}
                                    {item.location && item.location.length > 20
                                      ? "..."
                                      : ""}
                                  </span>
                                </span>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                    </Tabs>
                  ) : (
                    eventsData &&
                    eventsData.map((item) => (
                      <Card
                        sx={{
                          minWidth: 190,
                          maxWidth: 190,
                          width: 190,
                          ml: "25px",
                        }}
                        className=" bshadow cardini2"
                      >
                        <CardMedia>
                          <img
                            src={item?.coverimage && JSON.parse(item?.coverimage)[0]}
                            alt="Preview"
                            style={{ borderRadius: "20px" }}
                            className="form-img__img-preview-ec"
                          />
                        </CardMedia>
                        <CardContent>
                          <span
                            title={item?.eventTitle ? item?.eventTitle : ""}
                          >
                            {(item.eventTitle &&
                              item.eventTitle.slice(0, 20)) ||
                              "-"}
                            {item.eventTitle && item.eventTitle.length > 20
                              ? "..."
                              : ""}
                          </span>
                          <br />
                          <span>
                            {Moment(item?.startDate).format("DD MMM YYYY")},
                            <span title={item?.location ? item?.location : ""}>
                              {(item.location && item.location.slice(0, 20)) ||
                                "-"}
                              {item.location && item.location.length > 20
                                ? "..."
                                : ""}
                            </span>
                          </span>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
          {onViewClickTitle === "Development Projects" && (
            <span
              style={{
                display: "flex",
                alignItems: "baseline",
                fontFamily: "HK Grotesk",
                color: "#505050",
                fontSize: "16px",
                fontWeight: "bold",
                marginTop: "15px",
                gap: "20px",
              }}
            >
              <h1
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "16px",
                  fontWeight: "bold",
                  marginLeft: "55px",
                }}
              >
                Completion Status :
              </h1>{" "}
              {details?.status}
            </span>
          )}
          {onViewClickTitle === "OP-ed's, Books & Media Coverage of" && (
            <span
              style={{
                display: "flex",
                alignItems: "baseline",
                fontFamily: "HK Grotesk",
                color: "#505050",
                fontSize: "16px",
                fontWeight: "bold",
                marginTop: "15px",
                gap: "20px",
              }}
            >
              <h1
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "16px",
                  fontWeight: "bold",
                  marginLeft: "55px",
                }}
              >
                Link :
              </h1>{" "}
              <Linkify as="p" options={{target:'blank'}}>{details?.url}</Linkify>
              {/* <a href={details?.url} target="_blank" rel="noopener noreferrer">{details?.url}</a> */}
            </span>
          )}
          {onViewClickTitle === "Seva aur Samarpan Campaign" && (
            <div>
              <span
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "16px",
                  fontWeight: "bold",
                  marginLeft: "55px",
                }}
              >
                Event Images :{files?.length === 0 || files === null && 0}
              </span>
              <Box>
                {files?.length > 1 ? (
                  <Tabs
                    variant="scrollable"
                    scrollButtons
                    aria-label="visible arrows tabs example"
                    sx={{
                      [`& .${tabsClasses.scrollButtons}`]: {
                        "&.Mui-disabled": { opacity: 0.3 },
                      },
                      "& .MuiTabs-flexContainer": { marginLeft: "-35px" },
                    }}
                  >
                    {files?.map((file, index) => (
                      <Card
                        sx={{ minWidth: 200, mr: 2, borderRadius: "20px" }}
                        className=" bshadow"
                        onClick={() => {
                          handleOpenPreviewImages(file, index);
                          setOnFilesSelect(true);
                        }}
                      >
                        <CardContent>
                          <div key={index}>{handlePreview(file)}</div>
                        </CardContent>
                      </Card>
                    ))}
                  </Tabs>
                ) : (
                  files?.map((file, index) => (
                    <Card
                      sx={{ minWidth: 200, mr: 2, borderRadius: "20px" }}
                      className="bshadow"
                      onClick={() => {
                        handleOpenPreviewImages(file, index);
                        setOnFilesSelect(true);
                      }}
                    >
                      <CardContent>
                        <div key={index}>{handlePreview(file)}</div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </Box>
              <Grid container>
                <Grid item xs={6}>
                  <span
                    style={{
                      fontFamily: "HK Grotesk",
                      color: "#356F92",
                      fontSize: "16px",
                      fontWeight: "bold",
                      marginLeft: "55px",
                    }}
                  >
                    Start Date :
                  </span>{" "}
                  {Moment(details?.startDate).format("DD/MM/YYYY")}
                </Grid>
                <Grid item xs={6}>
                  <span
                    style={{
                      fontFamily: "HK Grotesk",
                      color: "#356F92",
                      fontSize: "16px",
                      fontWeight: "bold",
                      marginLeft: "55px",
                    }}
                  >
                    End Date :
                  </span>{" "}
                  {details?.endDate !== null ? Moment(details?.endDate).format("DD/MM/YYYY") : "-"}
                </Grid>
              </Grid>
              <div
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "16px",
                  fontWeight: "bold",
                  marginLeft: "55px",
                  display: "block",
                  marginTop: "15px",
                }}
              >
                {" "}
                Location
              </div>
              <Grid container>
                <Grid
                  item
                  xs={12}
                  sx={{
                    fontFamily: "HK Grotesk",
                    color: "#505050",
                    fontSize: "18px",
                    fontWeight: "bold",
                    marginLeft: "55px",
                  }}
                >
                  {details?.location ?? ""}
                </Grid>
              </Grid>
            </div>
          )}
        </DialogContent>
        {
          // onViewClickTitle === "Ongoing Seva Initiatives" ||
          //   uniqueInitiativeClick ? null :
          <DialogActions sx={{ justifyContent: "Center" }}>
            {((isEdit && mpName) || details?.userId === mpProfileData?.id) &&
              user !== "Admin" &&
              user !== "Leader" && (
                <Button
                  variant="contained"
                  className="button-tr-2"
                  autoFocus
                  onClick={onEditClick}
                  sx={{ backgroundColor: "#ef7335" }}
                >
                  Edit
                </Button>
              )}
            {((isEdit && mpName) || details?.userId === mpProfileData?.id) &&
            (onViewClickTitle === "OP-ed's, Books & Media Coverage of" ||
              onViewClickTitle === "Development Projects") ? (
              <Button
                variant="outlined"
                className="button-tr-citizen-cancel"
                autoFocus
                onClick={(e) => {
                  handleShare(e, details);
                }}
              >
                Share
              </Button>
            ) : (
              ((isEdit && mpName) || details?.userId === mpProfileData?.id) &&
              user !== "Admin" &&
              user !== "Leader" && (
                <Button
                  variant="outlined"
                  className="button-tr-citizen-cancel"
                  autoFocus
                  onClick={handleCloseInitiativeDetails}
                  sx={{ mr: 8 }}
                >
                  Cancel
                </Button>
              )
            )}
          </DialogActions>
        }
        {openMediaCoverage && (
          <AddMediaCoverage
            openMediaCoverage={openMediaCoverage}
            handleCloseMediaCoverage={handleCloseMediaCoverage}
            isMediaCoverageEdit={isMediaCoverageEdit}
            details={details}
            mpId={mpId}
            opedsByMpId={opedsByMpId}
            handleCloseInitiativeDetails={handleCloseInitiativeDetails}
          />
        )}
        {openDevelopmentProjects && (
          <AddDevelopmentProjects
            openDevelopmentProjects={openDevelopmentProjects}
            handleCloseDevelopmentProjects={handleCloseDevelopmentProjects}
            isDevelopmentProjectsEdit={isDevelopmentProjectsEdit}
            details={details}
            handleCloseInitiativeDetails={handleCloseInitiativeDetails}
            developmentProjectsByMpId={developmentProjectsByMpId}
            mpId={mpId}
          />
        )}
        {openCreateEventDialog && (
          <CreateNewEvent
            handleCloseCreateEvent={handleCloseCreateEvent}
            openCreateEventDialog={openCreateEventDialog}
            isSevaEventEdit={isSevaEventEdit}
            details={details}
            mpId={mpId}
            handleCloseInitiativeDetails={handleCloseInitiativeDetails}
            eventByMpId={eventByMpId}
          />
        )}
        {openPreviewImages && (
          <PreviewImagesDialog
            openPreviewImages={openPreviewImages}
            handleClosePreviewImages={handleClosePreviewImages}
            files={onFilesSelect ? files : reportFiles}
            previewImageIndex={previewImageIndex}
            one={one}
            two={two}
          />
        )}
        <Dialog open={mediaShare} onClose={() => setMediaShare(false)}>
          <DialogTitle>
            <IconButton
              aria-label="close"
              onClick={() => setMediaShare(false)}
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
                border: "1px solid #9e9e9e",
                borderRadius: "50%",
                padding: "2px",
                cursor: "pointer",
              }}
            >
              <CloseIcon />
            </IconButton>
            <Typography
              sx={{
                display: "flex",
                justifyContent: "center",
                color: "#357092",
                fontFamily: "HK Grotesk",
                fontSize: "26px",
                fontWeight: "bold",
              }}
            >
              Share to Social Media
            </Typography>

            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "25px",
                gap: "40px",
              }}
            >
              <Share
                data={shareData}
                title={
                  onViewClickTitle === "OP-ed's, Books & Media Coverage of"
                    ? "OP-ed's, Books & Media Coverage of"
                    : "Development Projects"
                }
              />
            </div>
            {/* <CloseIcon onClick={() => setAddMembers(false)} /> */}
          </DialogTitle>
        </Dialog>
        {/* </BootstrapDialog> */}
      </Dialog>
    </>
  );
};

export default InitiativeDetails;
