import { ImageList, ImageListItem, Typography } from "@mui/material";
import React, { useEffect } from "react";
import folder from "../../../asserts/images/sharing/Folder.png";
import { getVideo } from "../../../store/action/video";
import { useDispatch, useSelector } from "react-redux";

const ItemData = ({ setFolderName }) => {
  const itemDataImages = [
    {
      id: 1,
      title: "Videos",
      img: folder,
    },
  ];

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getVideo(0));
  }, []);

  return (
    <>
      <ImageList>
        {itemDataImages &&
          itemDataImages?.map((item) => (
            <ImageListItem key={item.id}>
              <img
                className="bgfolder cursorshow"
                style={{margin:"0 auto"}}
                key={item.id}
                src={`${item.img}`}//?w=164&h=164&fit=crop&auto=format
                srcSet={`${item.img}`}//?w=164&h=164&fit=crop&auto=format&dpr=2 2x
                alt={item.title}
                onClick={() => {
                  setFolderName(item);
                }}
              />
              <Typography
                variant="subtitle1"
                sx={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "14px",
                  fontWeight: "bold",
                  margin:"0 auto"
                }}
              >
                {item.title}
              </Typography>
            </ImageListItem>
          ))}
      </ImageList>
    </>
  );
};

export default ItemData;
