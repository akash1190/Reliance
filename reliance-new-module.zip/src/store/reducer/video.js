
import {VIDEO_FAILURE,VIDEO_REQUEST,VIDEO_SUCCESS} from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const getVideo = (state = initialState, action) => {
    switch (action.type) {
        case VIDEO_REQUEST:
            return {
                state,
            }
        case VIDEO_SUCCESS:
            return {
                data: action.payload
            }
        case VIDEO_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}