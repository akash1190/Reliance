import axios from "axios";
import Constant from "../../utils/constant";
import {
  FETCH_HIGHLIGHTS_FAILURE,
  FETCH_HIGHLIGHTS_REQUEST,
  FETCH_HIGHLIGHTS_SUCCESS,
} from "./types";

export const fetchAllHighlightsRequest = () => {
  return {
    type: FETCH_HIGHLIGHTS_REQUEST,
  };
};
export const fetchAllHighlightsSuccess = (carMakes) => {
  return {
    type: FETCH_HIGHLIGHTS_SUCCESS,
    payload: carMakes,
  };
};
export const fetchAllHighlightsFailure = (error) => {
  return {
    type: FETCH_HIGHLIGHTS_FAILURE,
    payload: error,
  };
};

export const getAllHighlights = (mpId) => async (dispatch) => {
  dispatch(fetchAllHighlightsRequest);


  const tkn = localStorage.getItem("tokenDetails");

  return axios
    .get(Constant.BASE_URL + `/api/getglobalhighlightcount/${mpId ? mpId : 0}`,{
      headers: {
        Authorization: `Bearer ${tkn}`,
      }
      })
    .then((response) => {
      const result = response.data;
      dispatch(fetchAllHighlightsSuccess(result));
      return response;
    })
    .catch((error) => {
      const errorMsg = error.message;
      dispatch(fetchAllHighlightsFailure(errorMsg));
    });
};
