import axios from "axios"
import Constant from "../../utils/constant"
// import { MpList } from "../../Constants/MpList"
import { ASSIGN_MP_REQUEST, ASSIGN_MP_SUCCESS, ASSIGN_MP_FAILURE } from "./types"

export const fetchMpListRequest = () => {
    return {
        type: ASSIGN_MP_REQUEST
    }
}
export const fetchMpListSuccess = carMakes => {
    return {
        type: ASSIGN_MP_SUCCESS,
        payload: carMakes
    }
}
export const fetchMpListFailure = error => {
    return {
        type: ASSIGN_MP_FAILURE,
        payload: error
    }
}


export const getAssignMpList = (state) => async (dispatch) => {

    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchMpListRequest)
    await axios.get(Constant.BASE_URL + `/api/initiative/mpAssign?state_name=${state ? state : ''}`, {
        headers: {
            Authorization: `Bearer ${tkn}`,
        },
    })
        .then(response => {
            const result = response.data
            // const result = MpList
            dispatch(fetchMpListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchMpListFailure(errorMsg))
        })
}


