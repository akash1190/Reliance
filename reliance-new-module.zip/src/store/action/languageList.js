import axios from "axios"
import Constant from "../../utils/constant"
// import { mpList } from "../../Constants/mpList"
import { FETCH_LANGUAGE_LIST_REQUEST, FETCH_LANGUAGE_LIST_SUCCESS, FETCH_LANGUAGE_LIST_FAILURE } from "./types"

export const fetchLanguageListRequest = () => {
    return {
        type: FETCH_LANGUAGE_LIST_REQUEST
    }
}
export const fetchLanguageListSuccess = data => {
    return {
        type: FETCH_LANGUAGE_LIST_SUCCESS,
        payload: data
    }
}
export const fetchLanguageListFailure = error => {
    return {
        type: FETCH_LANGUAGE_LIST_FAILURE,
        payload: error
    }
}


export const getLanguageList = () => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchLanguageListRequest)
    await axios.get(Constant.BASE_URL + `/api/languages/getall/${0}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchLanguageListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchLanguageListFailure(errorMsg))
        })
}


