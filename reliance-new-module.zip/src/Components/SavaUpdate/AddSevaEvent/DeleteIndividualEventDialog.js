import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import axios from "axios"
import Constant from '../../../utils/constant';
import { getEventsListByMpId, getEventsList } from "../../../store/action/eventsList";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";
import CloseIcon from "@mui/icons-material/Close";
import { getIntiativesReportByIdList } from "../../../store/action/ongoingSevaInitiativesList";
import { IconButton } from "@mui/material";
import { useDispatch } from "react-redux";

export default function DeleteIndividualEventDialog(props) {
    const { eventId, mpId, openDeleteDialog, handleCloseDeleteDialog, eventByMpId,
        handleCloseInitiativeDetails, details, isSevaEventEdit, setDeleteClick } = props;
    const { setLoading } = useLoading();
    const { showNotification } = useNotificationContext();
    const dispatch = useDispatch();
    const tkn = localStorage.getItem("tokenDetails");
    const onDeleteClick = async () => {
        try {
            setLoading(true);
            const response = await axios.delete(Constant.BASE_URL + `/api/DeleteEvent/${mpId}/${eventId}`, {
                headers: {
                    Authorization: `Bearer ${tkn}`,
                },
            })
                .then(response => {
                    return response;
                })
            if (response.status === 200 || response.status === 201) {
                if (details) {
                    handleCloseInitiativeDetails && handleCloseInitiativeDetails();
                }
                if (isSevaEventEdit) {
                    setDeleteClick(true);
                }
                if (eventByMpId) {
                    dispatch(getEventsListByMpId(mpId));
                } else {
                    dispatch(getEventsList(0));
                }
            }
            showNotification("Success", response.data.message, 'success');
            handleCloseDeleteDialog();
        }
        catch (error) {
            showNotification("Error", "Failed to fetch");
        }
        finally {
            setLoading(false);
        }
    }

    return (
        <div>
            <Dialog
                open={openDeleteDialog}
                onClose={handleCloseDeleteDialog}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                sx={{ maxWidth: "550px", margin: "0 auto" }}

            >
                <IconButton
                    aria-label="close"
                    onClick={handleCloseDeleteDialog}
                    sx={{
                        position: "absolute",
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                        border: "1px solid #9e9e9e",
                        borderRadius: "50%",
                        padding: "2px",
                        cursor: "pointer",
                    }}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent>
                    <DialogContentText sx={{ minHeight: "200px", display: "flex", alignItems: "center", color: "#6C6C6C", fontFamily: 'HK Grotesk', fontSize: "22px", textAlign: "center", mt: 2 }}>
                        Deleting this event will have an impact on your Seva Score. Are you sure you want to proceed?
                    </DialogContentText>
                </DialogContent>
                <DialogActions sx={{ justifyContent: "center" }}>
                    <Button className="button-tr-2" sx={{ fontFamily: 'HK Grotesk', ml: 2, width: "250px", mb: 3, height: "44px" }} onClick={onDeleteClick}>Delete</Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}
