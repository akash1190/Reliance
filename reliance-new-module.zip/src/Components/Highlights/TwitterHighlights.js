import React, { useState, useEffect } from "react";
import SideMenu from "../SideMenu/SideMenu.js";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { Typography, Card, Box, Grid } from "@mui/material";
import { TwitterTweetEmbed } from "react-twitter-embed";
import { useDispatch, useSelector } from "react-redux";
import { getMostViewedTweets } from "../../store/action/getMostViewedTweets.js";
import { getMostRetweetedTweets } from "../../store/action/getMostRetweetedTweets.js";
import { getTopMostFollowers } from "../../store/action/getTopMostFollowers";
import "./Highlights.css";
import { useLocation } from "react-router";

const TwitterHighlights = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const { listTopMostViewedTweet } = useSelector(
    (state) => state?.mostViewedTweets?.data
  );
  const { listTopMostRetweetedTweet } = useSelector(
    (state) => state?.mostRetweetedTweets?.data
  );

  const { topMostFollowers } = useSelector(
    (state) => state?.mostTwiiterNewFollowers?.data
  );

  let newUser = location?.state?.user;

  useEffect(() => {
    dispatch(getMostViewedTweets());
    dispatch(getMostRetweetedTweets());
    dispatch(getTopMostFollowers());
  }, []);

  return (
    <div>
      {/* Leadership */}
      {newUser ? (
        <div className="twitterTopLeaders">
          <div className="tweetSectionHeader">
            <h3
              style={{
                fontFamily: "HK Grotesk",
                color: "#2C2C2C",
                fontSize: "20px",
                fontWeight: "bold",
                marginLeft: "11px",
                marginTop: "25px",
                marginBottom:"15px"
              }}
            >
              Most New Followers Added
            </h3>
          </div>
          <div style={{display:"flex",justifyContent:"space-evenly",gap:"5px"}}>
          {topMostFollowers &&
            topMostFollowers?.map((mp) => (
              <div>
                <div
                  className="card-size "
                  style={{ width:"150px" }}
                >
                  <div className="card" style={{ borderRadius: "20px" }}>
                    <div className="card-body position-relative twitterboxleader">
                      {mp.user_avatar ? (
                        <div className="text-center pt-3">
                          <img
                            src={mp.user_avatar}
                            className="img-circle leader-circle-img mr-1"
                            width="70"
                            height="70"
                            style={{ objectFit: "contain" }}
                          />
                        </div>
                      ) : (
                        <div className="text-center pt-3">
                          <AccountCircleIcon
                            sx={{
                              fontSize: "xx-large",
                              width: "70px",
                              height: "auto",
                            }}
                          />
                        </div>
                      )}
                      <div className="leader-content-tw ellipsewe-name">
                        <h2 style={{fontSize:"16px"}} className="ellipsewe-pcard">{mp.mpName}</h2>
                        <span className="initial ellipsewe-pcard" style={{marginTop:"1px",display:"block"}}> {mp.designation} </span>
                        <br />
                        <span className="constituency ellipsewe-pcard-1" style={{marginTop:"-18px",fontSize:"11px"}}>
                          Constituency : {mp.constituency_name}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}</div>
        </div>
      ) : null}
<div  style={{marginTop:"10px"}}>
      <div className="tweetSectionHeader">
        <h3
          style={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontSize: "20px",
            fontWeight: "bold",
            marginLeft: "12px",
            textAlign:"left"
          }}
        >
          Most Viewed Tweets
        </h3>
      </div>
      <div className="tweetsContainer">
        {listTopMostViewedTweet
          ? listTopMostViewedTweet.map((data) => (
              <div key={data.tweetId}>
                <TwitterTweetEmbed tweetId={data.tweetId} />
              </div>
            ))
          : null}
      </div>
      </div><div>
      <div className="tweetSectionHeader">
        <h3
          style={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontSize: "20px",
            fontWeight: "bold",
            marginLeft: "12px",
            marginTop: "25px",
            textAlign:"left"
          }}
        >
          Most Retweeted Tweets
        </h3>
      </div>
      <div className="tweetsContainer">
        {listTopMostRetweetedTweet
          ? listTopMostRetweetedTweet?.map((data) => (
              <div key={data.tweetId}>
                <TwitterTweetEmbed tweetId={data.tweetId} />
              </div>
            ))
          : null}
      </div>
      </div>
    </div>
  );
};

export default TwitterHighlights;
