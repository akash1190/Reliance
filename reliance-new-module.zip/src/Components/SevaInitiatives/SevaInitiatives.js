/* eslint-disable react/jsx-no-duplicate-props */
import {
  Grid,
  Paper,
  Typography,
  Button,
  InputAdornment,
  TextField,
  Tooltip,
  Card,
} from "@mui/material";
import { Box } from "@mui/system";
import { useNavigate } from "react-router";
import React, { useEffect, useState } from "react";
import SideMenu from "../SideMenu/SideMenu";
// import BorderColorIcon from "@mui/icons-material/BorderColor";
import { Link } from "react-router-dom";
import searchIcon from "../../asserts/images/Search.svg";
import { useLoading } from "../../utils/LoadingContext";
import { useNotificationContext } from "../../utils/NotificationContext";
import editIcon from "../../asserts/images/Edit.svg";
import illimageIcon from "../../asserts/images/Illustration.svg";
import { useDispatch, useSelector } from "react-redux";
import getInitiativeList from "../../store/action/initiativeList";
import {
  getOngoingSevaIntiativesListWithInitiativeId,
  getSocialMediaIntiativesListById,
} from "../../store/action/ongoingSevaInitiativesList";
import BorderColorIcon from "../../asserts/images/Create.svg";
import axios from "axios";
import Constant from "../../utils/constant";
import ClearIcon from "@mui/icons-material/Clear";
import { getEvents } from '../../store/action/getEvents';
import getUserProfile from "../../store/action/getUserProfile";

const SevaInitiatives = () => {
  const tkn = localStorage.getItem("tokenDetails");
  const navigate = useNavigate();
  const initiativeList = useSelector((state) => state?.initiativeList?.data);
  const { setLoading } = useLoading();
  const { showNotification } = useNotificationContext();
  const [clearIcon, setClearIcon] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const dispatch = useDispatch();
  const handleCreateNew = () => {
    navigate("/SevaInitiatives/createInitiative", {
      state: {
        create: true,
      },
    });
  };
  const handleSearch = (e) => {
    dispatch(getInitiativeList(e.target.value));
  };

  const onTwitterRefreshClick = async () => {
    try {
      setLoading(true);
      const response = await axios
        .get(Constant.BASE_URL + `/api/mp/updatetweets`, {
          headers: {
            Authorization: `Bearer ${tkn}`,
          },
        })
        .then((response) => {
          return response;
        });
      showNotification(
        "Success",
        response?.data && response?.data?.message,
        "success"
      );
    } catch (error) {
      showNotification("Error", "Access Denied", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (id) => {
    await dispatch(getSocialMediaIntiativesListById(id));
    await dispatch(getOngoingSevaIntiativesListWithInitiativeId(id));
    dispatch(getEvents(id))

    navigate(`/SevaInitiatives/editInitiative/${id}`, {
      state: {
        id: id,
        create: false,
      },
    });
  };
  const fetchData = async () => {
    try {
      setLoading(true);
      await dispatch(getUserProfile());
      await dispatch(getInitiativeList());
    } catch (error) {
      showNotification("Error", error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const blockInvalidChar = (e) =>
    [
      "#",
      "&",
      "+",
      "_",
      "!",
      "@",
      "%",
      "[",
      "]",
      "=",
      "*",
      "^",
      "-",
      "?",
      "/",
      "$",
      ")",
      "(",
    ].includes(e.key) && e.preventDefault();

  return (
    <>
      <div className="page-wrapper d-flex" >
        <SideMenu active="SevaInitiative" user="Admin" />
        <div className="main-wrapper" style={{ width: "100%" }}>
          <Grid container>
            <Grid md={12} lg={12} xl={12}>
              <div className="d-flex justify-content-between align-items-center">
                <h1
                  style={{
                    fontFamily: "HK Grotesk",
                    color: "#356F92",
                    fontSize: "26px",
                    fontWeight: "bold",
                    marginLeft: "10px",
                  }}
                >
                  {" "}
                  Seva Initiatives
                </h1>
                <Button
                  className="button-tr1-admin"
                  style={{ marginLeft: "-247px" }}
                  onClick={onTwitterRefreshClick}
                  disabled
                >
                  Twitter Refresh
                </Button>
                <TextField
                  className="search-filter-icon"
                  sx={{
                    "& fieldset": { border: "none" },
                  }}
                  onChange={(e) => {
                    setSearchValue(e.target.value);
                    handleSearch(e);
                    if (e.target.value !== "") {
                      setClearIcon(true);
                    } else {
                      setClearIcon(false);
                    }
                  }}
                  value={searchValue}
                  // onKeyDown={blockInvalidChar}
                  placeholder="Search Initiative"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="start">
                        {/* search icon  */}
                        {clearIcon ? (
                          <ClearIcon
                            position="start"
                            sx={{ cursor: "pointer" }}
                            onClick={() => {
                              dispatch(getInitiativeList());
                              setClearIcon(false);
                              setSearchValue("");
                            }}
                          />
                        ) : (
                          <img
                            className="searchIcon cursorshow"
                            width={20}
                            height={21}
                            src={searchIcon}
                          />
                        )}
                      </InputAdornment>
                    ),
                  }}
                ></TextField>
                {/* <div className="search-filter-icon-admin d-flex-admin">
                            <div style={{position: "relative",left: "90%"}}>
                            {/* <a className="d-block mr-2" href=""> */}
                {/* <svg
                                    className="searchIcon position-absolute"
                                    width="20"
                                    height="21"
                                    viewBox="0 0 20 21"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M9.58317 18.6253C4.87484 18.6253 1.0415 14.792 1.0415 10.0837C1.0415 5.37533 4.87484 1.54199 9.58317 1.54199C14.2915 1.54199 18.1248 5.37533 18.1248 10.0837C18.1248 14.792 14.2915 18.6253 9.58317 18.6253ZM9.58317 2.79199C5.55817 2.79199 2.2915 6.06699 2.2915 10.0837C2.2915 14.1003 5.55817 17.3753 9.58317 17.3753C13.6082 17.3753 16.8748 14.1003 16.8748 10.0837C16.8748 6.06699 13.6082 2.79199 9.58317 2.79199Z"
                                        fill="#5c819e"
                                    />
                                    <path
                                        d="M18.3335 19.4585C18.1752 19.4585 18.0169 19.4002 17.8919 19.2752L16.2252 17.6085C15.9835 17.3669 15.9835 16.9669 16.2252 16.7252C16.4669 16.4835 16.8669 16.4835 17.1085 16.7252L18.7752 18.3919C19.0169 18.6335 19.0169 19.0335 18.7752 19.2752C18.6502 19.4002 18.4919 19.4585 18.3335 19.4585Z"
                                        fill="#5c819e"
                                    />
                                </svg> 
                                <img className="searchIcon" width={20} height={21} src={searchIcon}/>
                             </a> 
                            </div>
                        </div> */}
              </div>
            </Grid>
            <Grid md={12} lg={12} xl={12}>
            <div style={{display:"flex",flexDirection:"column"}}>
            <div
              className="create-dash-new card"
              style={{
                borderRadius: "25px",
                border: "1px solid #FFFFFF",
                padding: "15px",
                backgroundColor: "#e3f5ff",
                fontFamily: "HK Grotesk",
                width:"650px"              }}
            >
              <Grid container sx={{ ml: 2 }}>
                <Typography
                  sx={{
                    fontFamily: "HK Grotesk",
                    color: "#505050",
                    fontSize: "24px",
                    fontWeight: "bolder !important",
                  }}
                >
                  Create Initiative
                </Typography>
              </Grid>
              <Grid container sx={{ ml: 2 }}>
                <Grid item xs={12}>
                  <Typography
                    sx={{
                      fontFamily: "HK Grotesk",
                      color: "#505050",
                      fontSize: "20px",
                      fontWeight: "normal",
                    }}
                  >
                    Would you like to create a Seva Initiative? Add the details
                    here
                  </Typography>
                </Grid>
              </Grid>
              <Grid container sx={{ ml: 2 }}>
                <Button
                  className="button-tr1-admin"
                  sx={{
                    textTransform: "none !important",
                    fontWeight: "bolder !important",
                    fontSize: "20px !important",
                    padding: "8px 20px",
                    width: "242px"
                  }}
                  // endIcon={<BorderColorIcon />}
                  onClick={handleCreateNew}
                >
                  Create Now
                  <img
                    src={BorderColorIcon}
                    width="20px"
                    style={{ marginBottom: "4px", marginLeft: "8px" }}
                  />
                </Button>
              </Grid>
            </div>
           
              <div>
              <Card className="text19"
                sx={{
                  mt: 4,
                  ml: 1,
                  width: "100%",
                  height: "56vh",
                  borderRadius: 6,
                  overflow: "auto",
                  // position:"relative",
                  // left:"50%"
                }}
              >
                 {initiativeList.length > 0 ? (
                  <>
                    {initiativeList?.map((initiativeItem) => {
                      return (
                        <div
                          className="create-dash-new card"
                          style={{
                            marginLeft: "20px",
                            borderRadius: "15px",
                            border: "1px solid #FFFFFF",
                            padding: "15px",
                            backgroundColor: "#e3f5ff",
                            fontFamily: "HK Grotesk",
                            height: "45px",
                            width: "calc(100% - 40px)",
                          }}
                        >
                          <Grid
                            container
                            sx={{
                              ml: 2,
                              justifyContent: "space-between",
                              alignItems: "center",
                              marginTop: "-10px",
                            }}
                          >
                             <Tooltip title= {initiativeItem.initiativeName} arrow>
                <span style={{fontFamily:'HKGrotesk-Bold', color: "#505050", fontSize: "24px" }} className="ellipsewehe12">  {initiativeItem.initiativeName} </span>
              </Tooltip>
              
                            <img
                              style={{
                                marginRight: "25px",
                                width: "30px",
                                cursor: "pointer",
                              }}
                              onClick={() => {
                                handleEdit(initiativeItem?.id);
                              }}
                              src={editIcon}
                            />
                          </Grid> 
                        </div>
                      );
                    })}
                  </>
                ) : ( 
                  <>
                    <img
                      className="imagecenter"
                      src={illimageIcon}
                      width="300"
                      alt=""
                      // style={{marginTop:"40px"}}
                    />
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        flexDirection: "column",
                        alignItems: "center",
                        // marginTop: "5%",
                      }}
                    >
                      <span
                        style={{
                          fontSize: "24px",
                          color: "#356F92",
                          fontFamily: "HK Grotesk",
                          fontWeight: "bold",
                        }}
                      >
                        No data found!
                      </span>
                      <span
                        style={{
                          fontSize: "20px",
                          color: "#2C2C2C",
                          fontFamily: "HK Grotesk",
                          fontWeight: "bold",
                        }}
                      >
                        Click{" "}
                        <Link to="/SevaInitiatives/createInitiative">here</Link>{" "}
                        to create an initiative
                      </span>
                    </div>
                  </>
                )}
              </Card>
              </div>
              </div>
              </Grid>
          </Grid>
     
        </div>
      </div>
    </>
  );
};

export default SevaInitiatives;
