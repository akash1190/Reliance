import React, { useEffect, useState } from "react";
import { VideoLoader } from "../../ReusableComponents.js/VideoLoader";

const VideosFolder = ({
  videoResponse,
  languageData,
  setViewVideo,
  folderName,
  setAllVideos,
}) => {
  const [videoData, setVideoData] = useState([]);

  useEffect(() => {
    handleVideos();
  }, []);

  const handleVideos = () => {
    const videos =
      videoResponse &&
      videoResponse.filter((data) => {
        return data.language === languageData;
      });
    setVideoData(videos);
    // setAllVideos(videos);
  };

  let videosArray = [];
  videoData &&
    videoData?.forEach((image) => {
      const video = JSON.parse(image.video);
      // image && image?.forEach((data) =)
      video && video?.forEach((data) => videosArray.push(data));
    });

  useEffect(() => {
    setAllVideos(videosArray);
  }, [videoData]);

  return (
    <>
      <div className="itemgrid2 cursorshow">
        {videosArray &&
          videosArray?.map((item) => (
            <div>
              <VideoLoader
                className=" im100 cursorshow"
                src={`${item}`} //?w=164&h=164&fit=crop&auto=format
                loading="lazy"
                onClick={() => setViewVideo(item)}
              />
              {/* <video
                className=" im100 cursorshow"
                src={`${item}?w=164&h=164&fit=crop&auto=format`}
                // srcSet={`${item.video}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                // alt={item.subTitle}
                loading="lazy"
                onClick={() => setViewVideo(item)}
              /> */}
              {/* <Typography variant="subtitle1">{item.title}</Typography> */}
            </div>
          ))}
      </div>
    </>
  );
};

export default VideosFolder;
