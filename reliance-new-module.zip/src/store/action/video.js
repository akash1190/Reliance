import axios from "axios"
import Constant from "../../utils/constant"
import { VIDEO_FAILURE,VIDEO_REQUEST,VIDEO_SUCCESS} from "./types"

export const getVideoRequest = () => {
    return {
        type: VIDEO_REQUEST
    }
}
export const getVideoSuccess = value => {
    return {
        type: VIDEO_SUCCESS,
        payload: value
    }
}
export const getVideoFailure = error => {
    return {
        type: VIDEO_FAILURE,
        payload: error
    }
}


const getVideo = (query) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(getVideoRequest)
    await axios.get(Constant.BASE_URL + `/api/videostemplate/getall/${query}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
    .then(response => {
        const result = response.data
        // const result = mpList
        dispatch(getVideoSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(getVideoFailure(errorMsg))
    })
}

const updateVideo = (formData) => async(dispatch)=>{
    const tkn = localStorage.getItem("tokenDetails");
    await axios.post(Constant.BASE_URL + `/api/user/update-mpdata/${formData.id}`,formData,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      });
}


export {updateVideo, getVideo}

