import {
  CircularProgress,
  FormHelperText,
  Grid,
  InputAdornment,
  Paper,
  TableContainer,
  TableHead,
  Tooltip,
} from "@mui/material";
import { Box } from "@mui/system";
import React, { useState, useRef, useEffect } from "react";
import SideMenu from "../../SideMenu/SideMenu";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import InputLabel from "@mui/material/InputLabel";
import TextField from "@mui/material/TextField";
import FormControl from "@mui/material/FormControl";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import AddIcon from "@mui/icons-material/Add";
import Table from "@mui/material/Table";
import { TableBody, TableRow, Button } from "@mui/material";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
// import AddTextTemplates from "./AddTextTemplateNew.js/AddTextTemplate";
import AddTextTemplates from "./AddTextTemplates";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import { tooltipClasses } from "@mui/material/Tooltip";
import AssignToMP from "./AssignToMP";
import AddImageTemplates from "./AddImageTemplate/AddImageTemplates";
import UploadCoverImage from "./UploadCoverImage";
import AddVideoTemplate from "./AddVideoTemplate/AddVideoTemplate";
import searchIcon from "../../../asserts/images/Search.svg";
import one from "../../../asserts/images/1.jpg";
import two from "../../../asserts/images/4.jpg";
import { yupResolver } from "@hookform/resolvers/yup";
import { createInitiativeSchema } from "../../../utils/Validations";
import { useForm } from "react-hook-form";
import { Card } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { postIntiative } from "../../../store/action/createInitiative";
import getInitiativeList from "../../../store/action/initiativeList";
import { useLocation } from "react-router";
import { getSocialMediaIntiativesListById } from "../../../store/action/ongoingSevaInitiativesList";
import { getLanguageList } from "../../../store/action/languageList";
import RemoveIcon from "@mui/icons-material/Remove";
import { useParams } from "react-router-dom";
import DeleteInitiativeDialog from "./DeleteInitiativeDialog";
import imagedelete from "../../../asserts/images/bin.png";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import { SvgIcon } from "@mui/material";
import infoic from "../../../asserts/images/Info.svg";
import WarningMessageDialog from "../WarningMessageDialog";
import { validateNotEmpty } from "../../ReusableComponents.js/reuseMethods";
import VideoPlayer from "../../ReusableComponents.js/VideoPlayer";
import { useNotificationContext } from "../../../utils/NotificationContext";
import getUserProfile from "../../../store/action/getUserProfile";

const defaultDeleteMessage = "Are you sure you want to delete this initiative?";

// https://github.com/styled-components/styled-components/issues/540#issuecomment-283664947
const BootstrapInput = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 8,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#fcfcfb" : "#2b2b2b",
    border: "1px solid #ced4da",
    fontSize: 16,
    width: 350,
    padding: "8px 10px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const BootstrapInput1 = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 8,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#fcfcfb" : "#2b2b2b",
    border: "1px solid #ced4da",
    fontSize: 16,
    width: 170,
    padding: "8px 10px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const CreateInitiatives = () => {
  // const { id } = useParams();
  const [addTextExpand, setAddTextExpand] = useState(false);
  const [addImageExpand, setAddImageExpand] = useState(false);
  const [addVideoExpand, setAddVideoExpand] = useState(false);
  const [openTextTemplateDialog, setOpenTextTemplateDialog] = useState(false);
  const [openUploadImageDialog, setOpenUploadImageDialog] = useState(false);
  const [openVideoTemplateDialog, setOpenVideoTemplateDialog] = useState(false);
  const [openImageTemplateDialog, setOpenImageTemplateDialog] = useState(false);
  const [openAssingToMPDialog, setOpenAssingToMPDialog] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [intiative, setIntiative] = useState();
  const [files, setImageFileData] = useState();
  const [openWarningDialog, setOpenWarningDialog] = useState(false);
  const [checkWarningClick, setCheckWarningClick] = useState(false);
  const { assignMpList } = useSelector((state) => state?.assignMpList);
  const { initiative, eventList, MPList } = useSelector(
    (state) => state?.ongoingIntiativeListWithID?.data
  );
  const editInitiativeDetails = useSelector(
    (state) => state?.socialMediaInitiativeById?.data[0]
  );
  const [editDetails, setEditDetails] = useState(editInitiativeDetails);
  const [editDetailsName, setEditDetailsName] = useState({
    prefix: editInitiativeDetails?.initiativeName?.split("-")[0],
    text: editInitiativeDetails?.initiativeName?.split("-")[1],
  });

  const [image, setImage] = useState(null);
  const [editTextDetails, setEditTextDetails] = useState(
    editInitiativeDetails?.texttemplates
  );
  const [checkTextDetails, setCheckDetails] = useState(false);
  const [preview, setPreview] = useState(editDetails?.coverimage);
  const img = editDetails?.coverimage?.substring(
    editDetails?.coverimage?.lastIndexOf("/") + 1
  );
  const [upload, setUpload] = useState(false);
  const coverImage = img?.substring(0, img.indexOf(".", 3));
  const [imagetemplates, setImagetemplates] = useState(
    editDetails?.imagetemplates
  );
  const [videoTemplates, setVideoTemplates] = useState(
    editDetails?.videotemplates
  );
  // const coverImage = editDetails?.coverimage?.match(/[^\/]+$/)[0].split('-')
  const [imageName, setImageName] = useState(coverImage);
  const { loading } = useSelector((state) => state?.ongoingIntiativeListWithID);
  const [targetedDate, setTargetDate] = useState(editDetails?.tagetDate);
  const languageList = useSelector(
    (state) => state.languageList?.data?.languagedata
  );
  const [textData, setTextData] = useState([editDetails?.texttemplates]);
  const [imageData, setImageData] = useState([]);
  const [videoData, setVideoData] = useState([]);
  const [onEditBrowse, setOnEditBrowse] = useState(false);
  const [updateValue, setUpdateValue] = useState(false);
  const [updateVideoValue, setUpdateVideoValue] = useState(false);
  const [checkCoverImage, setCheckCoverImage] = useState(false);
  const { showNotification } = useNotificationContext();
  const fileFormats = ["image/png", "image/jpeg", "image/jpg"];
  const { data: initiativeEventDetails } = useSelector(
    (state) => state?.getAllEvents
  );
  const [deleteMessage, setDeleteMessage] =
    React.useState(defaultDeleteMessage);

  useEffect(() => {
    setDeleteMessage(defaultDeleteMessage);
    if (
      Array.isArray(initiativeEventDetails) &&
      initiativeEventDetails?.length
    ) {
      setDeleteMessage(
        "Multiple MPs have created events for this initiative. It will be permanently deleted from MP Corner. Are you sure you want to delete this initiative?"
      );
    }
  }, [initiativeEventDetails]);

  useEffect(() => {
    if (textData?.length > 0) {
      setEditTextDetails(textData[0]);
    }
  }, [textData]);
  useEffect(() => {
    if (updateValue && imageData.length > 0) {
      const output = imageData[0].map((item) => ({
        typeof_image: item.imageType,
        imageLanguage: item.language,
        url: item.images,
        banner_size: item.bannerSize || "",
      }));
      setImagetemplates(output);
      setUpdateValue(false);
    }
  }, [imageData]);

  useEffect(() => {
    if (updateVideoValue && videoData.length > 0) {
      const output = videoData[0].map((item) => ({
        language: item.language,
        video: item.videos,
      }));
      setVideoTemplates(output);
      setUpdateVideoValue(false);
    }
  }, [videoData]);

  const handleImageDownload = (url, callback) => {
    fetch(url)
      .then((response) => response.blob())
      .then((blob) => {
        const fileName = url.split("/").pop();
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          const base64data = reader.result;
          const file = new File([blob], fileName, { type: blob.type });
          const formattedObject = {
            url: base64data,
            file: file,
          };
          callback(formattedObject);
        };
      })
      .catch((error) => console.error(error));
  };

  const handleVideoDownload = (url, callback) => {
    fetch(url)
      .then((response) => response.blob())
      .then((blob) => {
        const fileName = url.split("/").pop();
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          const base64data = reader.result;
          const file = new File([blob], fileName, { type: blob.type });
          const formattedObject = {
            url: base64data,
            file: file,
          };
          callback(formattedObject);
        };
      })
      .catch((error) => console.error(error));
  };

  useEffect(() => {
    if (!createNewClick) {
      setUpload(false);
      let temp = [[]];
      handleImageDownload(editDetails?.coverimage, (formattedObject) => {
        setImage(formattedObject.file);
        // do something with formattedObject
      });
      if (imagetemplates?.length > 0 && imageData?.length == 0) {
        imagetemplates.map((value, i) => {
          let val = {};
          val.imageType = value.typeof_image;
          val.language = value.imageLanguage;
          let urlTemp = JSON.parse(value.url);
          let urlData = [];
          urlTemp.map((url) =>
            handleImageDownload(url, (formattedObject) => {
              urlData.push(formattedObject);
              // do something with formattedObject
            })
          );
          val.images = urlData;
          value.banner_size && (val.bannerSize = value.banner_size);
          temp[0].push(val);
        });
        setUpdateValue(true);
        setImageData(temp);
      }
    }
  }, [editDetails]);

  useEffect(() => {
    if (!createNewClick) {
      let temp = [[]];
      if (videoTemplates?.length > 0 && videoData?.length == 0) {
        videoTemplates.map((value, i) => {
          let val = {};
          val.language = value.language;
          let urlTemp = JSON.parse(value.video);
          let urlData = [];
          urlTemp.map((videos) =>
            handleVideoDownload(videos, (formattedObject) => {
              urlData.push(formattedObject);
              // do something with formattedObject
            })
          );
          val.videos = urlData;
          temp[0].push(val);
        });
        setUpdateVideoValue(true);
        setVideoData(temp);
      }
    }
  }, [editDetails]);
  useEffect(() => {
    if (!id) {
      setPreview("");
      setImageName("");
      setImageData([]);
      setTargetDate(null);
      setVideoData([]);
      // setOpenUploadImageDialog(true)
    }
    dispatch(getLanguageList());
  }, []);

  // useEffect(() => {
  //   if (id) {
  //     dispatch(getUserProfile());
  //     dispatch(getSocialMediaIntiativesListById(id));
  //   }
  // }, []);

  // useEffect(() => {
  //   if (id && editInitiativeDetails) {
  //     setEditDetails(editInitiativeDetails);
  //     setValue("initiativeName", editInitiativeDetails?.initiativeName?.split("-")[1]);
  //     setEditDetailsName({
  //       prefix: editInitiativeDetails?.initiativeName?.split("-")[0],
  //       text: editInitiativeDetails?.initiativeName?.split("-")[1],
  //     });
  //     setEditTextDetails(editInitiativeDetails?.texttemplates);
  //     let coverImg = editInitiativeDetails?.coverimage?.substring(
  //       editInitiativeDetails?.coverimage?.lastIndexOf("/") + 1
  //     );
  //     let coverImageName = coverImg?.substring(0, coverImg.indexOf(".", 3));
  //     setImageName(coverImageName);
  //     setUpload(true);
  //     setPreview(editInitiativeDetails?.coverimage);
  //     setTargetDate(editInitiativeDetails?.tagetDate);
  //     setValue("hashTags", editInitiativeDetails?.hashTags);
  //     setImagetemplates(editInitiativeDetails?.imagetemplates);
  //     setVideoTemplates(editInitiativeDetails?.videotemplates);
  //   }
  // }, [editInitiativeDetails]);

  const dispatch = useDispatch();
  const { id } = useParams();

  const hiddenFileInput = useRef(null);
  const location = useLocation();
  // let id = location ?.state?.id
  let createNewClick = location?.state?.create;
  const handleClick = (event) => {
    hiddenFileInput.current?.click();
    // setOnEditBrowse(createNewClick ? false : true);

    event?.stopPropagation();
  };

  useEffect(() => {
    if (createNewClick) {
      setEditDetails({});
      setEditTextDetails([]);
      setCheckDetails(true);
      setVideoData([]);
      setImageData([]);
      setTextData([]);
    }
  }, [createNewClick]);

  const onFileUpload = (event) => {
    const type = event.target.files[0].type;
    const isRightFormat = fileFormats.includes(type);
    if (!isRightFormat) {
      showNotification(
        "Error",
        "You can only upload jpg, jpeg and png image",
        "error"
      );
      return;
    }
    setImage(event.target.files[0]);
    setUpload(true);
    setPreview(URL.createObjectURL(event.target.files[0]));
    setImageName(event.target.files[0].name);
    // handleCloseUploadImageDialog();
    setOnEditBrowse(createNewClick ? false : true);
  };
  // const formOptions = { resolver: yupResolver(createInitiativeSchema) };
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm();
  useEffect(() => {
    if (checkWarningClick) {
      handleCloseWarningDialog(true);
      setOpenTextTemplateDialog(false);
      setOpenImageTemplateDialog(false);
      setOpenVideoTemplateDialog(false);
      setCheckWarningClick(false);
    }
  }, [checkWarningClick]);
  // const [rows,setRows]=useState()
  // const updateMp = (idList) => {
  //     let output= assignMpList?.mpAssignData.filter(val=>{idList.includes(val.id)})
  //     // setPersonalDetail({...personalDetail,[key]:value})
  //   }
  const handleOpenTextTemplateDialog = () => {
    setOpenTextTemplateDialog(true);
  };

  // const handleClickOpenWarningDialog = () => {
  //   setOpenWarningDialog(true);
  // }

  const handleCloseWarningDialog = () => setOpenWarningDialog(false);

  const handleCloseTextTemplateDialog = (warningDialog) => {
    if (warningDialog) {
      setOpenWarningDialog(true);
    } else {
      setOpenTextTemplateDialog(false);
    }
  };

  const handleOpenImageTemplateDialog = () => {
    setOpenImageTemplateDialog(true);
  };

  const handleCloseImageTemplateDialog = (warningDialog) => {
    if (warningDialog) {
      setOpenWarningDialog(true);
    } else {
      setOpenImageTemplateDialog(false);
    }
  };

  const handleOpenVideosTemplateDialog = () => {
    setOpenVideoTemplateDialog(true);
  };

  const handleCloseVideosTemplateDialog = (warningDialog) => {
    if (warningDialog) {
      setOpenWarningDialog(true);
    } else {
      setOpenVideoTemplateDialog(false);
    }
  };

  const handleCloseUploadImageDialog = () => {
    setOpenUploadImageDialog(false);
  };

  const handleOpenUploadImageDialog = () => {
    setOpenUploadImageDialog(true);
  };

  const handleClickOpenDeleteDialog = () => {
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setOpenDeleteDialog(false);
  };

  const addCoverImageToFormData = async (formData, coverImage) => {
    const response = await fetch(coverImage);
    const blob = await response.blob();
    const file = new File([blob], `image.jpg`, { type: blob.type });
    formData.append(`coverimage1`, file, file.name);
  };

  const handleOpenAssingToMPDialog = async (data) => {
    console.log("data", data);
    if (!imageName) return;
    const formData = new FormData();
    !createNewClick &&
      formData.append(
        "initiativeName",
        editDetailsName?.prefix + "-" + data?.initiativeName
      );
    createNewClick && formData.append("initiativeName", data?.initiativeName);
    formData.append("initiativeDetails", data?.initiativeDetails);
    formData.append("steps", data?.steps);
    formData.append("hashTags", data?.hashTags);
    formData.append(
      "targetDate",
      targetedDate
      //  Moment(targetedDate).format('YYYY-MM-DD')
    );
    textData[0]?.map((value, i) => {
      formData.append(`textLanguage[${i + 1}]`, value.language);
      formData.append(`text[${i + 1}]`, value.text);
      formData.append(`hashtag[${i + 1}]`, value.hashtag);
    });
    // formData.append("textdatacounter", textData.length)

    imageData[0]?.map((value, i) => {
      // if (imageData[0].length != i + 1) {
      const files = value?.images?.map((val) => val.file);
      formData.append(`typeof_image[${i + 1}]`, value.imageType);
      Array.from(files).forEach((file) =>
        formData.append(`imagemedia${i + 1}`, file, file?.name)
      );
      formData.append(`imageLanguage[${i + 1}]`, value.language);
      value?.bannerSize &&
        formData.append(`banner_size[${i + 1}]`, value.bannerSize);
      // }
    });
    videoData[0]?.map((value, i) => {
      // if (videoData[0].length != i + 1) {
      const files = value?.videos?.map((val) => val?.file);
      formData.append(`videoLanguage[${i + 1}]`, value.language);
      Array.from(files).forEach((file) =>
        formData.append(`videomedia${i + 1}`, file, file?.name)
      );
      // }
    });

    formData.append(
      "textdatacounter",
      textData[0]?.length ? textData[0]?.length : 0
    );
    formData.append(
      "imagedatacounter",
      imageData[0]?.length ? imageData[0]?.length : 0
    );
    formData.append(
      "videodatacounter",
      videoData[0]?.length ? videoData[0]?.length : 0
    );

    createNewClick && formData.append(`coverimage1`, image, imageName);
    !createNewClick &&
      upload &&
      formData.append(
        `coverimage1`,
        image.file ? image.file : image,
        imageName ? imageName : coverImage
      );
    // !createNewClick && (await addCoverImageToFormData(formData, image));

    // Array.from(image).forEach((file,i) => formData.append(`media[${i}]`, file, file.name));

    setIntiative(formData);
    setOpenAssingToMPDialog(true);
  };
  const handleCloseAssingToMPDialog = () => {
    setOpenAssingToMPDialog(false);
  };

  // const onCreateInitiativeSubmit = (data) => {

  // }

  // function createData(id, language, text, hashtags) {
  //     return { id, language, text, hashtags };
  // }

  // const rows = [
  //     createData(1, 'English', "I am organizing a blood donation camp", "#DonateBlood"),
  //     createData(2, 'Hindi', "This is the new text", "#DonateBlood"),
  // ];

  const dateConvert = (dateStr) => {
    const date = new Date(dateStr);
    let month = date.getMonth() + 1; // getMonth() returns 0-indexed month, so add 1
    let day = date.getDate();
    let year = date.getFullYear();
    // month= && "0"+month;
    // day=day.length==1 && "0"+day;
    const formattedDate = `${year}-${month < 10 ? "0" + month : month}-${day < 10 ? "0" + day : day
      }`;
    return formattedDate;
  };

  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: "#F5F6FA",
      color: "#2e739c",
      fontWeight: "bold",
      fontSize: 18,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 16,
      fontWeight: "bold",
      backgroundColor: "#fff",
      color: "#505050",
    },
  }));

  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    "&:last-child td, &:last-child th": {
      border: 0,
    },
  }));
  // const BootstrapTooltip = styled(({ className, ...props }: TooltipProps) => (
  //     <Tooltip {...props} arrow classes={{ popper: className }} />
  //   ))(({ theme }) => ({
  //     [`& .${tooltipClasses.arrow}`]: {
  //       color: theme.palette.common.black,
  //     },
  //     [`& .${tooltipClasses.tooltip}`]: {
  //       backgroundColor: theme.palette.common.black,
  //     },
  //   }));
  const BootstrapTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} arrow classes={{ popper: className }} />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.arrow}`]: {
      color: theme.palette.common.white,
    },
    [`& .${tooltipClasses.tooltip}`]: {
      color: theme.palette.common.black,
      backgroundColor: theme.palette.common.white,
      border: "1px solid #fff",
      boxShadow: theme.shadows[1],
    },
  }));

  const validateDate = (value, fieldName) => {
    const regex = new RegExp("^[a-zA-Z][a-zA-Z]*");
    const inputDate = new Date(targetedDate);
    const currentDate = new Date();
    if (inputDate < currentDate || regex.test(targetedDate)) {
      return "Please enter a valid date";
    }
    return true;
  };

  // useEffect(()=>{
  //     if(id){

  //     }
  //     // dispatch(getInitiativeList())

  // },[])
  return (
    <>
      <div className="page-wrapper1 d-flex">
        <SideMenu
          active="SevaInitiative"
          user="Admin"
          createInitiative={true}
        />
        {/* <SideMenu active="SevaInitiative" user="Admin" /> */}

        {/* <Grid item xs={4} md={2} lg={2} xl={2}  >



            </Grid> */}

        <Grid
          item
          xs={8}
          md={10}
          lg={10}
          xl={10}
          className={"main-wrapper"}
          style={{ width: "100%" }}
        >
          <div
            className="d-flex justify-content-between align-items-center"
            style={{ padding: "30px", fontFamily: "HK Grotesk" }}
          >
            <h1
              style={{
                fontFamily: "HK Grotesk",
                color: "#356F92",
                fontSize: "26px",
                fontWeight: "bold",
                width: "94%",
                margin: "0 auto",
              }}
            >
              {" "}
              Seva Initiatives
            </h1>
            {/* <div className="search-filter-icon-admin d-flex-admin">
                        <div style={{ position: "relative", left: "90%" }}>

                            <img className="searchIcon" width={20} height={21} src={searchIcon} />

                        </div>
                    </div> */}
          </div>
          {loading ? (
            <CircularProgress />
          ) : (
            <form>
              <Card
                sx={{
                  fontFamily: "HK Grotesk",
                  width: "90%",
                  margin: "0 auto",
                  padding: "45px",
                  borderRadius: "20px",
                }}
              >
                <Grid
                  item
                  xs={10}
                  md={10}
                  lg={10}
                  xl={10}
                  sx={{ fontFamily: "HK Grotesk" }}
                >
                  <h1
                    style={{
                      fontFamily: "HK Grotesk",
                      color: "#356F92",
                      fontSize: "22px",
                      fontWeight: "bold",
                    }}
                  >
                    {" "}
                    {id ? "Edit Initiative" : "Create Initiative"}
                  </h1>
                  <FormControl variant="standard" sx={{ marginTop: "25px" }}>
                    <InputLabel
                      shrink
                      htmlFor="bootstrap-input"
                      sx={{ color: "#2e739c" }}
                    >
                      <b
                        className="headincreateini"
                        style={{
                          fontFamily: "HK Grotesk",
                          fontSize: "20px",
                          fontWeight: "bold",
                        }}
                      >
                        Initiative Name
                      </b>
                    </InputLabel>
                    <BootstrapInput
                      id="bootstrap-input"
                      inputProps={{
                        maxLength: 300,
                      }}
                      defaultValue={id ? editDetailsName?.text : ""}
                      {...register("initiativeName", {
                        required: "Please enter Initiative Name",
                        maxLength: {
                          value: 300,
                          message: "Maximum character length is 300",
                        },
                        validate: (value) =>
                          validateNotEmpty(value, "Initiative Name"),
                      })}
                    />
                  </FormControl>
                  <FormHelperText sx={{ color: "#d32f2f" }}>
                    {errors && errors?.initiativeName?.message}
                  </FormHelperText>
                </Grid>

                <Grid item xs={10} md={10} lg={10} xl={10}>
                  <FormControl variant="standard" sx={{ marginTop: "25px" }}>
                    <InputLabel
                      shrink
                      htmlFor="bootstrap-input"
                      sx={{ color: "#2e739c" }}
                    >
                      <b
                        className="headincreateini"
                        style={{
                          fontFamily: "HK Grotesk",
                          fontSize: "20px",
                          fontWeight: "bold",
                        }}
                      >
                        Initiative Details
                      </b>
                    </InputLabel>
                    <BootstrapInput
                      id="bootstrap-input"
                      placeholder="Initiative Details"
                      style={{ marginTop: "20px" }}
                      defaultValue={id ? editDetails?.initiativeDetails : ""}
                      inputProps={{
                        maxLength: 1000,
                      }}
                      multiline
                      rows={2}
                      {...register("initiativeDetails", {
                        required: "Please enter Initiative Details",
                        maxLength: {
                          value: 1000,
                          message: "Maximum character length is 1000",
                        },
                        validate: (value) =>
                          validateNotEmpty(value, "Initiative Details"),
                      })}
                    />
                  </FormControl>
                  <FormHelperText sx={{ color: "#d32f2f" }}>
                    {errors && errors?.initiativeDetails?.message}
                  </FormHelperText>
                </Grid>

                {/* <BootstrapInput id="bootstrap-input" > */}

                <Grid
                  item
                  xs={10}
                  md={10}
                  lg={10}
                  xl={10}
                  sx={{ marginTop: "25px" }}
                >
                  <InputLabel
                    shrink
                    htmlFor="bootstrap-input"
                    sx={{ color: "#2e739c" }}
                  >
                    <b
                      className="headincreateini"
                      style={{
                        fontFamily: "HK Grotesk",
                        fontSize: "20px",
                        fontWeight: "bold",
                      }}
                    >
                      Upload Initiative Cover Image
                    </b>
                  </InputLabel>
                  <BootstrapTooltip
                    title="Only files with the following extensions are allowed:png,jpg,jpeg"
                    placement="right-start"
                    componentsProps={{
                      tooltip: {
                        sx: {
                          fontSize: "18px",
                          fontFamily: "HK Grotesk",
                          padding: "15px",
                        },
                      },
                    }}
                    style={{ marginTop: "-5px" }}
                  >
                    <div className="cls-input-sty texcretei">
                      <input
                        type="file"
                        accept="image/png, image/jpeg, image/jpg"
                        ref={hiddenFileInput}
                        style={{ display: "none" }}
                        onChange={onFileUpload}
                        required
                      />
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <Button
                          onClick={
                            !preview ? handleClick : handleOpenUploadImageDialog
                          }
                          style={{
                            fontFamily: "HK Grotesk",
                            background: "#e3f5ff",
                            marginTop: "4px",
                            marginLeft: "5px",
                            borderRadius: "8px",
                            height: "28px",
                            textTransform: "initial",
                            marginRight: "10px",
                          }}
                        >
                          {preview ? "Preview" : "Browse"}
                        </Button>
                        {imageName ? (
                          <Typography
                            sx={{ display: "block", fontSize: "14px" }}
                            className="ellipsewehe"
                            onClick={handleOpenUploadImageDialog}
                          >
                            {imageName}
                          </Typography>
                        ) : null}
                      </div>
                      <FormHelperText sx={{ color: "#d32f2f" }}>
                        {checkCoverImage &&
                          !imageName &&
                          "Please upload cover image"}
                      </FormHelperText>
                    </div>
                  </BootstrapTooltip>
                </Grid>

                <div
                  style={{
                    display: "flex",
                    fontFamily: "HK Grotesk",
                    gap: "8px",
                  }}
                >
                  <Grid
                    item
                    xs={10}
                    md={10}
                    lg={10}
                    xl={10}
                    sx={{ marginTop: "30px" }}
                  >
                    <FormControl variant="standard" sx={{ width: "180px" }}>
                      <InputLabel
                        shrink
                        htmlFor="bootstrap-input"
                        sx={{ color: "#2e739c" }}
                      >
                        <b
                          className="headincreateini"
                          style={{
                            fontFamily: "HK Grotesk",
                            fontSize: "20px",
                            fontWeight: "bold",
                          }}
                        >
                          Event Hashtag
                        </b>
                      </InputLabel>
                      <BootstrapInput1
                        id="bootstrap-input"
                        defaultValue={id ? editDetails?.hashTags : ""}
                        inputProps={{
                          maxLength: 280,
                        }}
                        {...register("hashTags", {
                          required: "Please enter a hashtag",
                          maxLength: {
                            value: 280,
                            message: "Maximum character length is 280",
                          },
                          validate: (value) =>
                            validateNotEmpty(value, "hashtag"),
                        })}
                      />
                      <FormHelperText sx={{ color: "#d32f2f" }}>
                        {errors && errors?.hashTags?.message}
                      </FormHelperText>
                    </FormControl>
                  </Grid>
                  <Grid
                    item
                    xs={10}
                    md={10}
                    lg={10}
                    xl={10}
                    sx={{ marginTop: "30px" }}
                  >
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <InputLabel
                        shrink
                        htmlFor="bootstrap-input"
                        sx={{ color: "#2e739c", marginBottom: "0px" }}
                      >
                        <b
                          className="headincreateini"
                          style={{
                            fontFamily: "HK Grotesk",
                            fontSize: "20px",
                            fontWeight: "bold",
                          }}
                        >
                          Target Date
                        </b>
                      </InputLabel>
                      <DatePicker
                        components={{
                          OpenPickerIcon: CalendarMonthIcon,
                        }}
                        InputProps={{
                          disableUnderline: true,
                          sx: {
                            "& .MuiSvgIcon-root": {
                              color: "#fff",
                              background: "#356f92",
                              width: "30px",
                              height: "30px",
                              padding: "5px",
                              borderRadius: "5px",
                              ml: "15px",
                              mt: "2px",
                            },
                          },
                        }}
                        // {...register("targetDate", { required: true })}
                        defaultValue={id ? editDetails?.tagetDate : ""}
                        inputFormat="DD/MM/YYYY"
                        value={targetedDate}
                        minDate={new Date()}
                        className="cls-input-sty-2"
                        sx={{
                          fontFamily: "HK Grotesk",
                          backgroundColor: "red",
                        }}
                        onChange={(newValue) => {
                          setTargetDate(dateConvert(newValue));
                        }}
                        renderInput={(params) => (
                          <FormControl
                            sx={{
                              fontFamily: "HK Grotesk",
                              backgroundColor: "#fcfcfb",
                              width: "182px",
                            }}
                          >
                            {/* <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c" }}>
                                                            <b>Event</b>
                                                        </InputLabel> */}
                            <TextField
                              variant="standard"
                              value={watch("targetDate")}
                              sx={{
                                "& .MuiInputBase-input": {
                                  width: "100px", // Set your height here.
                                  marginTop: "5px",
                                  marginLeft: "10px",
                                },
                              }}
                              // onKeyDown={(e) => {
                              //   e.preventDefault();
                              // }}
                              {...register("targetDate", {
                                required: !targetedDate
                                  ? "Target date is required"
                                  : false,
                                validate: (value) =>
                                  validateDate(value, "targetDate"),
                              })}
                              tooltip={false}
                              {...params}
                              error={
                                // !targetedDate &&
                                Boolean(errors?.targetDate?.message)
                              }
                              helperText={
                                // !targetedDate &&
                                errors?.targetDate?.message
                              }
                            // {...register("targetDate", { required: true })}
                            />
                          </FormControl>
                        )}
                      />
                      {/* <FormHelperText sx={{ color: "#d32f2f" }}>
                                        {errors && errors?.targetDate?.message}</FormHelperText> */}
                    </LocalizationProvider>
                  </Grid>
                </div>
                <Grid
                  item
                  xs={10}
                  md={10}
                  lg={10}
                  xl={10}
                  sx={{ marginTop: "25px" }}
                >
                  <FormControl variant="standard">
                    <InputLabel
                      shrink
                      htmlFor="bootstrap-input"
                      sx={{ color: "#2e739c" }}
                    >
                      <b
                        className="headincreateini"
                        style={{
                          fontFamily: "HK Grotesk",
                          fontSize: "20px",
                          fontWeight: "bold",
                        }}
                      >
                        Steps
                      </b>
                    </InputLabel>
                    <BootstrapInput
                      id="bootstrap-input"
                      defaultValue={id ? editDetails?.steps : ""}
                      multiline
                      rows={3}
                      inputProps={{
                        maxLength: 1000,
                      }}
                      {...register("steps", {
                        required: "Please enter Steps",
                        maxLength: {
                          value: 1000,
                          message: "Maximum character length is 1000",
                        },
                        validate: (value) => validateNotEmpty(value, "Steps"),
                      })}
                    />
                    <Grid container>
                      <Grid item xs={8}>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.steps?.message}
                        </FormHelperText>
                      </Grid>
                      <Grid item xs={4}>
                        <span style={{ color: "grey", fontSize: "14px" }}>
                          (Max length 1000)
                        </span>
                      </Grid>
                    </Grid>
                  </FormControl>
                </Grid>

                <Grid item xs={10} md={10} lg={10} xl={10} sx={{ mt: 2 }}>
                  <h1
                    className="createKitText"
                  >
                    {" "}
                    Create Social Media Kit
                  </h1>
                  <Accordion
                    className="bradiusaccord"
                    sx={{
                      backgroundColor: "#E3F5FF",
                      mb: 2,
                      fontFamily: "HK Grotesk",
                      mt: 2,
                      border: "0",
                      color: "#505050",
                      "&:before": {
                        display: "none",
                      },
                    }}
                    onClick={
                      checkTextDetails && textData[0] === undefined
                        ? handleOpenTextTemplateDialog
                        : (editDetails &&
                          editDetails?.texttemplates?.length === 0) ?
                          handleOpenTextTemplateDialog : undefined
                    }
                  // expanded={(textData?.length > 0) ? true : false}
                  >
                    <AccordionSummary
                      expandIcon={
                        addTextExpand ? (
                          <RemoveIcon color="primary" />
                        ) : (
                          <AddIcon color="primary" />
                        )
                      }
                      aria-controls="panel1a-content"
                      id="panel1a-header"
                      onClick={() => setAddTextExpand(!addTextExpand)}
                    >
                      <Typography
                        sx={{ fontFamily: "HK Grotesk", fontWeight: "bold" }}
                      >
                        Add Text Templates
                        {/* <BootstrapTooltip title="Only files with the following extensions are allowed:png,jpg,jpeg" placement="right"
                                            componentsProps={{
                                                tooltip: {
                                                    sx: {
                                                        fontSize: "18px",
                                                        fontFamily: 'HK Grotesk',
                                                        padding: "15px",
                                                    }
                                                }
                                            }} >
                                            <img src={infoic} style={{ width: "20px", marginLeft: "8px" }} />
                                            {/* <ErrorOutlineIcon sx={{ ml: 2, color: "#387194" }} /> */}
                        {/* </BootstrapTooltip> */}
                      </Typography>
                    </AccordionSummary>
                    {textData?.length > 0 ||
                      (editDetails && editDetails?.texttemplates?.length > 0) ? (
                      <AccordionDetails>
                        <TableContainer component={Paper}>
                          <Table
                            sx={{ minWidth: 810, tableLayout: "fixed" }}
                            aria-label="customized table"
                          >
                            <TableHead>
                              <StyledTableCell
                                sx={{ fontFamily: "HK Grotesk" }}
                              >
                                Language
                              </StyledTableCell>
                              <StyledTableCell
                                sx={{ fontFamily: "HK Grotesk" }}
                              >
                                Text
                              </StyledTableCell>
                              <StyledTableCell
                                sx={{ fontFamily: "HK Grotesk" }}
                              >
                                Hashtags
                              </StyledTableCell>
                            </TableHead>
                            <TableBody>
                              {(textData[0] || editDetails?.texttemplates)?.map(
                                (row) => (
                                  <StyledTableRow key={row.id}>
                                    <StyledTableCell component="th" scope="row">
                                      {row.language
                                        ? row?.language
                                        : row?.language}
                                    </StyledTableCell>
                                    <StyledTableCell
                                      title={row.text ? row.text : ""}
                                    >
                                      {(row.text && row.text.slice(0, 25)) ||
                                        "-"}
                                      {row.text && row.text.length > 25
                                        ? "..."
                                        : ""}{" "}
                                    </StyledTableCell>
                                    <StyledTableCell>
                                      {row.hashtag}
                                    </StyledTableCell>
                                  </StyledTableRow>
                                )
                              )}
                              <Button
                                variant="outlined"
                                className="button-tr-citizen-admin"
                                startIcon={<AddIcon sx={{ mt: "5px" }} />}
                                sx={{
                                  mt: 1,
                                  ml: 1,
                                  mb: 1,
                                  fontFamily: "HK Grotesk",
                                }}
                                onClick={handleOpenTextTemplateDialog}
                              >
                                Edit
                              </Button>
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </AccordionDetails>
                    ) : null}
                  </Accordion>
                  <Accordion
                    className="bradiusaccord"
                    sx={{
                      backgroundColor: "#E3F5FF",
                      mb: 2,
                      fontFamily: "HK Grotesk",
                      fontSize: "18px",
                      mt: 2,
                      border: "0",
                      "&:before": {
                        display: "none",
                      },
                      color: "#505050",
                    }}
                    onClick={
                      imageData.length === 0 && handleOpenImageTemplateDialog
                    }
                  >
                    <AccordionSummary
                      expandIcon={
                        addImageExpand ? (
                          <RemoveIcon color="primary" />
                        ) : (
                          <AddIcon color="primary" />
                        )
                      }
                      onClick={() => setAddImageExpand(!addImageExpand)}
                      aria-controls="panel1a-content"
                      id="panel1a-header"
                    >
                      <Typography
                        sx={{ fontFamily: "HK Grotesk", fontWeight: "bold" }}
                      >
                        Add Images
                        <BootstrapTooltip
                          title="Only files with the following extensions are allowed:png,jpg,jpeg"
                          placement="right"
                          componentsProps={{
                            tooltip: {
                              sx: {
                                fontSize: "18px",
                                fontFamily: "HK Grotesk",
                                padding: "15px",
                              },
                            },
                          }}
                        >
                          <img
                            src={infoic}
                            style={{ width: "20px", marginLeft: "8px" }}
                          />
                          {/* <ErrorOutlineIcon sx={{ ml: 2, color: "#387194" }} /> */}
                        </BootstrapTooltip>
                      </Typography>
                    </AccordionSummary>
                    {imageData[0]?.length > 0 && (
                      <AccordionDetails>
                        <TableContainer component={Paper}>
                          <Table
                            sx={{ minWidth: 810 }}
                            aria-label="customized table"
                          >
                            {/* <TableHead>
                                                        <StyledTableCell>Language</StyledTableCell>
                                                    </TableHead>
                                                    <TableBody> */}
                            {imageData[0]?.map((item, i) => (
                              <div
                                style={{
                                  marginLeft: "10px",
                                  marginTop: "10px",
                                }}
                              >
                                <h6
                                  style={{
                                    fontFamily: "HK Grotesk",
                                    color: "#356F92",
                                    fontSize: "18px",
                                    fontWeight: "bold",
                                    backgroundColor: "#F5F6FA",
                                    marginLeft: "-10px",
                                    marginTop: "-10px",
                                    padding: "10px",
                                  }}
                                >
                                  {item.imageType} - {item.language}
                                </h6>
                                <div className="itemfixed10">
                                  {/* {
                                                            item?.videos?.map(video => (
                                                                <video width="80" height="80" controls>
                                                                    <source src={video.url} type="video/mp4" />

                                                                </video>
                                                            ))
                                                        } */}
                                  {item?.images?.map((img) => (
                                    //class used for fetching image
                                    <img
                                      className={`fetchImage${i}`}
                                      src={img.url ? img.url : img}
                                      alt=""
                                      width="120"
                                      height="120"
                                      style={{ objectFit: "cover" }}
                                    />
                                  ))}
                                </div>
                                {/* <img src={item['images'][0].url} alt="" width="50" height="50" /> */}
                              </div>
                            ))}
                            <Button
                              variant="outlined"
                              className="button-tr-citizen-admin"
                              startIcon={<AddIcon sx={{ mt: "5px" }} />}
                              sx={{
                                mt: 1,
                                ml: 1,
                                mb: 1,
                                fontFamily: "HK Grotesk",
                              }}
                              onClick={handleOpenImageTemplateDialog}
                            >
                              Edit
                            </Button>
                            {/* </TableBody> */}
                          </Table>
                        </TableContainer>
                      </AccordionDetails>
                    )}
                  </Accordion>
                  <Accordion
                    className="bradiusaccord"
                    sx={{
                      backgroundColor: "#E3F5FF",
                      fontFamily: "HK Grotesk",
                      mt: 2,
                      border: "0",
                      "&:before": {
                        display: "none",
                      },
                      color: "#505050",
                    }}
                    onClick={
                      videoData.length === 0 && handleOpenVideosTemplateDialog
                    }
                  >
                    <AccordionSummary
                      expandIcon={
                        addVideoExpand ? (
                          <RemoveIcon color="primary" />
                        ) : (
                          <AddIcon color="primary" />
                        )
                      }
                      onClick={() => setAddVideoExpand(!addVideoExpand)}
                      aria-controls="panel1a-content"
                      id="panel1a-header"
                    >
                      <Typography
                        sx={{ fontFamily: "HK Grotesk", fontWeight: "bold" }}
                      >
                        Add Videos
                        <BootstrapTooltip
                          title="Only files with the following extensions are allowed:mp4"
                          placement="right"
                          componentsProps={{
                            tooltip: {
                              sx: {
                                fontSize: "18px",
                                fontFamily: "HK Grotesk",
                                padding: "15px",
                              },
                            },
                          }}
                        >
                          <img
                            src={infoic}
                            style={{ width: "20px", marginLeft: "8px" }}
                          />
                        </BootstrapTooltip>
                      </Typography>
                    </AccordionSummary>
                    {videoData[0]?.length > 0 && (
                      <AccordionDetails>
                        <TableContainer component={Paper}>
                          <Table
                            sx={{ minWidth: 810, fontFamily: "HK Grotesk" }}
                            aria-label="customized table"
                          >
                            {/* <TableHead>
                                                        <StyledTableCell>Language</StyledTableCell>
                                                    </TableHead>
                                                    <TableBody> */}
                            {videoData[0]?.map((item, i) => (
                              // <StyledTableRow key={row.id}>
                              //     <StyledTableCell component="th" scope="row">
                              //         {row.language}
                              //     </StyledTableCell>
                              //     <StyledTableCell title={row.text ? row.text : ""} >{(row.text &&
                              //         row.text.slice(0, 25)) ||
                              //         "-"}
                              //         {row.text &&
                              //             row.text.length > 25
                              //             ? "..."
                              //             : ""}{" "}</StyledTableCell>
                              //     <StyledTableCell >{row.hashtags}</StyledTableCell>
                              // </StyledTableRow>
                              <div
                                style={{
                                  marginLeft: "10px",
                                  marginTop: "10px",
                                }}
                              >
                                <h6
                                  style={{
                                    fontFamily: "HK Grotesk",
                                    color: "#356F92",
                                    fontSize: "18px",
                                    fontWeight: "bold",
                                    backgroundColor: "#F5F6FA",
                                    marginLeft: "-10px",
                                    marginTop: "-10px",
                                    padding: "10px",
                                  }}
                                >
                                  {item.language}
                                </h6>
                                <div className="itemfixed10">
                                  {item?.videos?.map((video) => (
                                    <VideoPlayer
                                      width="80"
                                      height="80"
                                      className={`fetchVideo${i}`}
                                      src={video.url ? video.url : video}
                                      controls="play"
                                    />
                                    // <video
                                    //
                                    //   controls
                                    //   className={`fetchVideo${i}`}
                                    // >
                                    //   <source
                                    //     src={video.url ? video.url : video}
                                    //     type="video/mp4"
                                    //   />
                                    // </video>
                                  ))}
                                </div>
                                {/* <img src={item['videos'][0].url} alt="" width="50" height="50" /> */}
                              </div>
                            ))}
                            <Button
                              variant="outlined"
                              className="button-tr-citizen-admin"
                              startIcon={<AddIcon sx={{ mt: "5px" }} />}
                              sx={{
                                mt: 1,
                                ml: 1,
                                mb: 1,
                                fontFamily: "HK Grotesk",
                              }}
                              onClick={handleOpenVideosTemplateDialog}
                            >
                              Edit
                            </Button>
                            {/* </TableBody> */}
                          </Table>
                        </TableContainer>
                      </AccordionDetails>
                    )}
                  </Accordion>
                </Grid>
                <Grid item xs={10} md={10} lg={10} xl={10}>
                  <Button
                    variant="contained"
                    onClick={handleSubmit(handleOpenAssingToMPDialog)}
                    onFocus={() => setCheckCoverImage(true)}
                    className="button-tr-assign"
                    sx={{ fontFamily: "HKGrotesk-Black!important", mt: "24px!important",fontSize:"18px!important",height:"42px",letterSpacing:"1.2px" }}
                  >
                    Assign
                  </Button>
                  {id && (
                    <img
                      src={imagedelete}
                      onClick={handleClickOpenDeleteDialog}
                      className="deleteimgcss1 cursorshow"
                      alt="delete"
                    />
                  )}
                  {openTextTemplateDialog && (
                    <AddTextTemplates
                      openTextTemplateDialog={openTextTemplateDialog}
                      handleCloseTextTemplateDialog={
                        handleCloseTextTemplateDialog
                      }
                      setText={setTextData}
                      languages={languageList}
                      // editTextTemplateDetails={editDetails}
                      createNewClick={createNewClick}
                      editTextTemplateDetails={editTextDetails}
                    />
                  )}
                  {openAssingToMPDialog && (
                    <AssignToMP
                      handleCloseAssingToMPDialog={handleCloseAssingToMPDialog}
                      openAssingToMPDialog={openAssingToMPDialog}
                      intiativeData={intiative}
                      image={image}
                      id={id}
                      selectedMP={MPList}
                      createNewClick={createNewClick}
                      eventList={eventList}
                    />
                  )}
                  {openImageTemplateDialog && (
                    <AddImageTemplates
                      handleCloseImageTemplateDialog={
                        handleCloseImageTemplateDialog
                      }
                      openImageTemplateDialog={openImageTemplateDialog}
                      setImageData={setImageData}
                      languages={languageList}
                      imageData={imageData}
                      editDetails={imageData.length > 0 && imagetemplates}
                      createNewClick={createNewClick}
                      setUpdateValue={setUpdateValue}
                    />
                  )}
                  {openVideoTemplateDialog && (
                    <AddVideoTemplate
                      handleCloseVideosTemplateDialog={
                        handleCloseVideosTemplateDialog
                      }
                      openVideoTemplateDialog={openVideoTemplateDialog}
                      languages={languageList}
                      editDetails={videoData.length > 0 && videoTemplates}
                      setVideoData={setVideoData}
                      setUpdateVideoValue={setUpdateVideoValue}
                    // initialVideos={initialVideos}
                    // setInitialVideos={setInitialVideos}
                    />
                  )}
                  {openDeleteDialog && (
                    <DeleteInitiativeDialog
                      handleCloseDeleteDialog={handleCloseDeleteDialog}
                      openDeleteDialog={openDeleteDialog}
                      initiativeId={id && id}
                      message={deleteMessage}
                    />
                  )}
                  {openUploadImageDialog && (
                    <UploadCoverImage
                      handleCloseUploadImageDialog={
                        handleCloseUploadImageDialog
                      }
                      openUploadImageDialog={openUploadImageDialog}
                      image={image}
                      setImage={setImage}
                      setImageFileData={setImageFileData}
                      preview={preview}
                      setPreview={setPreview}
                      setImageName={setImageName}
                      handleClick={handleClick}
                      createNewClick={createNewClick}
                      onEditBrowse={onEditBrowse}
                    />
                  )}
                  {openWarningDialog && (
                    <WarningMessageDialog
                      openWarningDialog={openWarningDialog}
                      handleCloseWarningDialog={handleCloseWarningDialog}
                      setCheckWarningClick={setCheckWarningClick}
                    />
                  )}
                </Grid>
              </Card>
            </form>
          )}
          {/* <Grid item xs={10} md={10} lg={10} xl={10}>
                    <React.Fragment>
                        <Box sx={{ display: "flex", flexDirection: "row", pl: 28, mb: 2, mt: 2 }}>
                            <Button
                                variant="contained"
                                sx={{ p: 1, mr: 1, backgroundColor: "#ef7335", borderRadius: 4, fontFamily: 'HK Grotesk' }}
                                className="button-tr-2"
                                onClick={handleSubmit(onCreateInitiativeSubmit)}
                            >
                                Submit
                            </Button>
                            <Box sx={{ flex: "1 1 auto" }} />
                        </Box>
                    </React.Fragment>
                </Grid> */}
        </Grid>
      </div>
    </>
  );
};

export default CreateInitiatives;
