import React, { useEffect, useState } from "react";
import {
  Grid,
  ImageListItem,
  ImageList,
  Typography,
  Button,
} from "@mui/material";
import { ImageLoader } from "../../ReusableComponents.js/ImageLoader";
const ImagesFolder = ({
  languageData,
  setViewImage,
  folderName,
  imageResponse,
  setAllImages,
}) => {
  const [imageData, setImageData] = useState([]);
  const [selectedBannerRatio, setSelectedBannerRatio] = useState('')
  const [bannerFilter, setBannerFilter] = useState(false);

  useEffect(() => {
    if (folderName == "Outdoor Banner") {
      setBannerFilter(true);
    } else {
      setImageData(handleImages);
      // setAllImages(handleImages);
    }
  }, []);

  const handleImages =
    imageResponse &&
    imageResponse.filter((data) => {
      return (
        data.typeof_image === folderName && data.imageLanguage === languageData
      );
    });

  const handleBannerImages = () => {
    return (
      <Grid container sx={{ mb: 1 }}>
        <Grid item xs={4}>
          <Button
            className="butbanner"
            sx={[{ borderRadius: "17px" }, selectedBannerRatio === '1:1' && { backgroundColor: '#356f92', color: '#fff' }]}
            variant="outlined"
            onClick={() => handleFilter("1:1")}
          >
            1:1
          </Button>
        </Grid>
        <Grid item xs={4}>
          <Button
            className="butbanner"
            sx={[{ borderRadius: "17px" }, selectedBannerRatio === '16:9' && { backgroundColor: '#356f92', color: '#fff' }]}
            variant="outlined"
            onClick={() => handleFilter("16:9")}
          >
            16:9
          </Button>
        </Grid>
        <Grid item xs={4}>
          <Button
            className="butbanner"
            sx={[{ borderRadius: "17px" }, selectedBannerRatio === '3:6' && { backgroundColor: '#356f92', color: '#fff' }]}
            variant="outlined"
            onClick={() => handleFilter("3:6")}
          >
            3:6
          </Button>
        </Grid>
      </Grid>
    );
  };

  const handleFilter = (value) => {
    const data =
      imageResponse &&
      imageResponse.filter((data) => {
        return (
          data.typeof_image === folderName &&
          data.imageLanguage === languageData &&
          data.banner_size.trim() === value
        );
      });
    setImageData(data);
    setSelectedBannerRatio(value)
    // setAllImages(data);
  };

  let imagesArray = [];
  imageData &&
    imageData?.forEach((image) => {
      const url = JSON.parse(image.url);
      // image && image?.forEach((data) =)
      url && url?.forEach((data) => imagesArray.push(data));
    });

  useEffect(() => {
    setAllImages(imagesArray);
  }, [imageData]);

  return (
    <>
      {bannerFilter ? handleBannerImages() : null}
      <div className="itemgrid2 cursorshow" >
        {imagesArray &&
          imagesArray?.map((item) => (
            <div>
              <ImageLoader
                src={`${item}`}
                className=" im100"
                srcSet={`${item}`}
                onClick={() => {
                  setViewImage(item);
                }}
              />
              {/* <img
                className=" im100"
                src={`${item}?w=164&h=130&fit=crop&auto=format`}
                // src={`${NoImageFound}?w=164&h=130&fit=crop&auto=format`}
                srcSet={`${item}?w=164&h=130&fit=crop&auto=format&dpr=2 2x`}
                // alt={item.subTitle}
                loading="lazy"
                onClick={() => setViewImage(item)}
              /> */}
              {/* <Typography
                variant="subtitle1"
                sx={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "12px",
                  fontWeight: "bold",
                  textAlign: "center",
                }}
              >
                {item.title}
              </Typography> */}
            </div>
          ))}
      </div>
    </>
  );
};

export default ImagesFolder;
