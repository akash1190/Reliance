import React, { useState, useEffect, useRef } from "react";
import PropTypes from "prop-types";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import AddIcon from "@mui/icons-material/Add";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import one from "../../../asserts/images/1.jpg";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";
import two from "../../../asserts/images/4.jpg";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  FormControl,
  FormHelperText,
  Grid,
  Paper,
  TextField,
} from "@mui/material";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import { useForm } from "react-hook-form";
import UploadIcon from "@mui/icons-material/Upload";
import { postCreateInitiativeReportBy } from "../../../store/action/createInitiativeReportBy";
import { useDispatch } from "react-redux";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";
import closeIconp from "../../../asserts/images/close.png";
import PreviewImagesDialog from "./PreviewImagesDialog";
import Moment from "moment";
import Constant from "../../../utils/constant";
import DeleteEventDialog from "./DeleteEventDialog";
import { getIds } from "../../ReusableComponents.js/getIds";

const UpdateInitiativeReportDetails = ({
  openUpdateIntiativeDialog,
  handleCloseUpdateInitiativeDetails,
  initiativeReportDetailsByMPIdAndIntiativeId,
  details,
  initiativeName,
  allInitiativeReportsPage,
}) => {
  const [reportFiles, setReportFiles] = useState([]);
  const [openPreviewImages, setOpenPreviewImages] = useState(false);
  const reportsData =
    initiativeReportDetailsByMPIdAndIntiativeId &&
    initiativeReportDetailsByMPIdAndIntiativeId?.reportdata;
  const eventsData =
    initiativeReportDetailsByMPIdAndIntiativeId &&
    initiativeReportDetailsByMPIdAndIntiativeId?.Eventdata;
  const { setLoading } = useLoading();
  const dispatch = useDispatch();
  const { showNotification } = useNotificationContext();
  const [uploadFiles, setUploadFiles] = useState([]);
  const [onEdit, setOnEdit] = useState(false);
  const [eventId, setEventId] = useState();
  const [mpId, setMpId] = useState();
  const [initiativeId, setInitiativeId] = useState();
  const hiddenFileInput = useRef(null);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const fileFormats = ["image/png", "image/jpeg", "image/jpg"];
  const [checkImages, setCheckImages] = useState(false);
  const loggedInId = getIds();
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();

  useEffect(() => {
    if (reportsData) {
      setReportFiles(reportsData?.media && JSON.parse(reportsData?.media));
    }
  }, [reportsData]);

  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };

  const handleImageChange = (e) => {
    const uploadedFiles = e.target.files;
    setOnEdit(true);
    setUploadFiles([...uploadFiles, ...uploadedFiles]);
    let newFiles = [];
    for (let i = 0; i < uploadedFiles.length; i++) {
      const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
        if (uploadedFiles[i].type.startsWith("image")) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          newFiles.push({
            type: "image",
            url: reader.result,
            file: uploadedFiles[i],
          });
        } else if (uploadedFiles[i].type.startsWith("video")) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          newFiles.push({
            type: "video",
            url: reader.result,
            file: uploadedFiles[i],
          });
        } else {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
        }
        if (i === uploadedFiles.length - 1) {
          setReportFiles([...newFiles, ...reportFiles]);
        }
      };
    }
  };

  const handlePreview = (file) => {
    if (file.type === "image") {
      return (
        <img
          src={typeof file === "string" ? file : file.url}
          onError={(e) => (e.target.src = NoImageFound)}
          alt="Preview"
          className="imageupload form-img__img-preview-4"
          id="imageupload"
        />
      );
    }
    if (file.type === "video") {
      return (
        <video
          controls
          className="imageupload form-img__img-preview-4"
          id="imageupload"
        >
          <source
            src={typeof file === "string" ? file : file.url}
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      );
    }
    const images = ["jpg", "gif", "png", "svg", "jfif"];
    const videos = ["mp4", "3gp", "ogg"];
    const url = new URL(file);
    const extension = url.search.split(".")[1];
    if (details && images.includes(extension)) {
      return (
        <img
          src={file}
          onError={(e) => (e.target.src = NoImageFound)}
          alt="Preview"
          className="imageupload form-img__img-preview-4"
          id="imageupload"
        />
      );
    }
    if (details && videos.includes(extension)) {
      return (
        <video
          controls
          className="imageupload form-img__img-preview-4"
          id="imageupload"
        >
          <source
            src={typeof file === "string" ? file : file.url}
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      );
    }
  };

  const handleClickOpenDeleteDialog = (mpId, eventId, initiativeId) => {
    setInitiativeId(initiativeId);
    setEventId(eventId);
    setMpId(mpId);
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => setOpenDeleteDialog(false);

  const handleOpenPreviewImages = () => {
    setOpenPreviewImages(true);
  };
  const handleClosePreviewImages = () => {
    setOnEdit(false);
    setOpenPreviewImages(false);
  };

  const addImagesToFormData = async (formData, images) => {
    for (let i = 0; i < images.length; i++) {
      const response = await fetch(images[i].src);
      const blob = await response.blob();
      const file = new File([blob], `image${i}.jpg`, { type: "image/*" });
      formData.append(`media`, file, file.name);
    }
  };

  const onUpdateSubmit = async (data) => {
    if (reportFiles.length === 0) return;
    setLoading(true);
    const tkn = localStorage.getItem("tokenDetails");
    const imgList = document.querySelectorAll(".imageupload");
    const formData = new FormData();
    formData.append("desc", data?.desc);
    formData.append("participant", data?.participant);
    formData.append("initiativeId", reportsData?.initiativeId);
    // formData.append("target", Moment(targetDate).format('YYYY-MM-DD'));
    formData.append("mpmodelId", loggedInId);
    await addImagesToFormData(formData, imgList);
    // Array.from(uploadFiles).forEach((file, i) =>
    //     formData.append(`media[${[i]}]`, file, file.name)
    // );
    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${tkn}`,
      },
    };
    try {
      const response = await dispatch(
        postCreateInitiativeReportBy(reportsData?.id, formData, config)
      );
      if (response.status === 200 || response.status === 201) {
        showNotification("Success", response.data.message, "success");
        handleCloseUpdateInitiativeDetails(
          reset,
          setReportFiles,
          setUploadFiles
        );
        // Object.keys(data).map(val => resetField(val));
        // setFiles([]);
        // setUploadFiles([]);
      }
    } catch (error) {
      showNotification("Error", "Failed to fetch");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (index) => {
    hiddenFileInput.current.value = "";
    const tempImages = [...reportFiles];
    tempImages.splice(index, 1);
    setReportFiles(tempImages);
  };

  const blockInvalidChar = (e) => {
    if (["e", "E", "+", "-", "."].includes(e.key) || e.keyCode === 40) {
      e.preventDefault();
    }
    if (e.keyCode === 40) {
      // 40 is the key code for down arrow
      const currentValue = e.target.value;
      if (currentValue > 1) {
        e.target.value = Number(currentValue) - 1;
      }
      e.preventDefault();
    }
  };

  const onPasteCLick = (e) => {
    var clipboardData = e.clipboardData.getData("text");
    var cleanedData = clipboardData.replace(/[-e]/gi, "");
    if (cleanedData.length === 0) {
      e.preventDefault();
    } else {
      document.execCommand("insertText", false, cleanedData);
      e.preventDefault();
    }
  };

  return (
    <>
      <Dialog
        open={openUpdateIntiativeDialog}
        onClose={() =>
          handleCloseUpdateInitiativeDetails(
            reset,
            setReportFiles,
            setUploadFiles
          )
        }
        sx={{ height: "96vh", marginTop: "25px" }}
      >
        <DialogTitle
          id="customized-dialog-title"
          onClose={() =>
            handleCloseUpdateInitiativeDetails(
              reset,
              setReportFiles,
              setUploadFiles
            )
          }
        >
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <h6
              style={{
                fontFamily: "HK Grotesk",
                color: "#2C2C2C",
                fontSize: "20px",
                fontWeight: "bolder",
                textTransform: "capitalize",
              }}
            >{`Initiative Report by ${reportsData?.user?.user_name ?? ""}`}</h6>
            <h1
              style={{
                fontFamily: "HK Grotesk",
                color: "#356F92",
                fontSize: "26px",
                fontWeight: "bolder",
                textTransform: "capitalize",
              }}
            >
              {initiativeName && (initiativeName ?? "")}
            </h1>
          </div>
          <hr></hr>
        </DialogTitle>

        <DialogContent>
          <div className="text-center pt-1">
            {reportsData?.user?.user_avatar ? (
              <img
                src={reportsData?.user?.user_avatar}
                className="img-circle leader-circle-img mr-1"
                width="80"
                height="80px"
              />
            ) : (
              <AccountCircleIcon
                sx={{ fontSize: "xx-large", width: "80px", height: "80px" }}
              />
            )}
          </div>
          <div className="card-content">
            <div>
              <span
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#11243D",
                  fontSize: "15px",
                  fontWeight: "bold",
                }}
              >
                {reportsData?.user?.designation?.length > 0
                  ? reportsData?.user?.designation + " ,"
                  : ""}{" "}
                {reportsData?.user?.party ?? ""}
              </span>
              <br />
              <span
                className="constituency"
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#707A89",
                  fontSize: "14px",
                  fontWeight: "bold",
                }}
              >
                {"Constituency" +
                  " : " +
                  (reportsData?.user?.constituency_name
                    ? reportsData?.user?.constituency_name
                    : "-")}
              </span>
              <br />
              {/* <div style={{ display: "inline-block", background: "#fef6f2", padding: "5px", borderRadius: "10px", marginTop: "10px" }}>Participants: {reportsData?.participant ?? ""}</div> */}
            </div>
          </div>
          <Grid container className="bg-white" sx={{ overflowX: "hidden" }}>
            <Grid item xs={12} md={12}>
              <Grid item xs={12} md={12} sx={{ p: 4 }}>
                <Box>
                  <form>
                    <Grid
                      container
                      spacing={1}
                      justifyContent="left"
                      alignItems="center"
                    >
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <b
                          style={{
                            fontFamily: "HK Grotesk",
                            color: "#357092",
                            fontSize: "16px",
                            fontWeight: "bold",
                            marginLeft: "5px",
                            marginBottom: "2px",
                          }}
                        >
                          Participants
                        </b>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <TextField
                            className="stepperFormInput partic"
                            name="participant"
                            fullWidth
                            placeholder="Enter participants count"
                            size="small"
                            required
                            type="number"
                            autoComplete="off"
                            {...register("participant", {
                              required: "Please enter the count of participant",
                              maxLength: {
                                value: 10,
                                message:
                                  "Maximum number of participants is a 10 digit number",
                              },
                              validate: (value) => {
                                if (value === "0") {
                                  return "Participants count cannot be 0";
                                } else if (/^0+$/.test(value)) {
                                  return "Participants count cannot be 0";
                                }
                                return true;
                              },
                            })}
                            defaultValue={
                              details?.participant
                                ? allInitiativeReportsPage
                                  ? reportsData?.participant
                                  : details?.participant
                                : reportsData?.participant
                            }
                            onKeyDown={blockInvalidChar}
                            onPaste={onPasteCLick}
                            onWheel={(e) => {
                              e.target.blur();
                              e.stopPropagation();
                            }}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.participant?.message}
                        </FormHelperText>
                      </Grid>
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#357092",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b> Initiative Description</b>
                          </div>

                          <TextField
                            className="stepperFormInput"
                            // label="Title"
                            name="desc"
                            fullWidth
                            placeholder="Enter description"
                            size="small"
                            required
                            multiline
                            rows={3}
                            defaultValue={
                              details?.desc ? details.desc : reportsData?.desc
                            }
                            autoComplete="off"
                            {...register("desc", {
                              required: "Description is required",
                              maxLength: {
                                value: 1000,
                                message: "Max length 1000",
                              },
                            })}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.desc?.message}
                        </FormHelperText>
                      </Grid>
                    </Grid>
                  </form>
                </Box>
              </Grid>
            </Grid>
            <div>
              <span
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "16px",
                  fontWeight: "bold",
                  marginLeft: "55px",
                }}
              >
                Images
              </span>
              <div
                className="contpopup1"
                style={{
                  flexDirection: "row-reverse",
                  marginLeft: "0px !important",
                }}
              >
                <div
                  style={{
                    width: "475px",
                    marginLeft: "0px !important",
                  }}
                  className="postionabs-2 itemfixed-update"
                >
                  {reportFiles && reportFiles.length > 1 ? (
                    <Tabs
                      variant="scrollable"
                      scrollButtons
                      aria-label="visible arrows tabs example"
                      sx={{
                        [`& .${tabsClasses.scrollButtons}`]: {
                          "&.Mui-disabled": { opacity: 0.3 },
                        },
                        // marginLeft: "-45px",
                      }}
                    >
                      {reportFiles &&
                        reportFiles.map((file, index) => (
                          <Card
                            sx={{ minWidth: 200, mr: 2 }}
                            className=" bshadow"
                          >
                            <CardContent>
                              <div
                                key={index}
                                onClick={handleOpenPreviewImages}
                              >
                                {handlePreview(file)}
                              </div>
                            </CardContent>
                            <img
                              src={closeIconp}
                              onClick={() => handleDelete(index)}
                              className="imageclose-updateinire"
                            />
                          </Card>
                        ))}
                    </Tabs>
                  ) : (
                    reportFiles &&
                    reportFiles.map((file, index) => (
                      <Card
                        sx={{ minWidth: 200, mr: 2, position: "relative" }}
                        className=" bshadow"
                      >
                        <CardContent>
                          <div key={index} onClick={handleOpenPreviewImages}>
                            {handlePreview(file)}
                          </div>
                        </CardContent>
                        <img
                          src={closeIconp}
                          onClick={() => handleDelete(index)}
                          className="imageclose-updateinire"
                        />
                      </Card>
                    ))
                  )}
                </div>
              </div>
              <Grid item xs={6}>
                <input
                  type="file"
                  ref={hiddenFileInput}
                  style={{ display: "none" }}
                  multiple
                  onChange={handleImageChange}
                  accept="image/png,image/jpeg, image/jpg"
                />
                <Button
                  className="button-tr-citizen"
                  startIcon={
                    <AddIcon sx={{ fontSize: "20", marginTop: "4px" }} />
                  }
                  onClick={handleClick}
                  sx={{ mr: 1 }}
                >
                  Add More
                </Button>
              </Grid>
            </div>
            <div style={{ marginTop: "20px" }}>
              <span
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "16px",
                  fontWeight: "bold",
                  marginLeft: "55px",
                }}
              >
                {" "}
                Event Conducted :{" "}
                {(initiativeReportDetailsByMPIdAndIntiativeId &&
                  initiativeReportDetailsByMPIdAndIntiativeId?.eventcount) ||
                  0}
              </span>
              <div className="gridinirepo" style={{ marginTop: "20px" }}>
                <div>
                  {eventsData && eventsData.length > 1 ? (
                    <Tabs
                      variant="scrollable"
                      scrollButtons
                      aria-label="visible arrows tabs example"
                      sx={{
                        [`& .${tabsClasses.scrollButtons}`]: {
                          "&.Mui-disabled": { opacity: 0.3 },
                        },
                      }}
                    >
                      {eventsData &&
                        eventsData.map((item, index) => (
                          <Card
                            sx={{ minWidth: 190, position: "relative" }}
                            className=" bshadow cardini2"
                          >
                            <CardMedia>
                              <img
                                src={
                                  item?.coverimage &&
                                  JSON.parse(item?.coverimage)[0]
                                }
                                onError={(e) => (e.target.src = NoImageFound)}
                                alt="Preview"
                                style={{ borderRadius: "20px" }}
                                className="form-img__img-preview-ec"
                              />
                            </CardMedia>

                            <CardContent sx={{ height: "70px" }}>
                              <div style={{ marginTop: "-12px" }}>
                                <span
                                  style={{
                                    fontFamily: "HK Grotesk",
                                    color: "#2C2C2C",
                                    fontSize: "13px",
                                    fontWeight: "bold",
                                    textTransform: "capitalize",
                                  }}
                                  title={
                                    item?.eventTitle ? item?.eventTitle : ""
                                  }
                                >
                                  {(item.eventTitle &&
                                    item.eventTitle.slice(0, 20)) ||
                                    "-"}
                                  {item.eventTitle &&
                                  item.eventTitle.length > 20
                                    ? "..."
                                    : ""}
                                </span>
                                <br />
                                <span
                                  style={{
                                    fontFamily: "HK Grotesk",
                                    color: "#2C2C2C",
                                    fontSize: "12px",
                                    fontWeight: "bold",
                                    textTransform: "capitalize",
                                  }}
                                >
                                  {Moment(item?.startDate).format(
                                    "DD MMM YYYY"
                                  )}
                                  ,
                                  <span
                                    title={item?.location ? item?.location : ""}
                                  >
                                    {(item.location &&
                                      item.location.slice(0, 20)) ||
                                      "-"}
                                    {item.location && item.location.length > 20
                                      ? "..."
                                      : ""}
                                  </span>
                                </span>
                              </div>
                            </CardContent>
                            <img
                              src={closeIconp}
                              className="imageclose-up2-new"
                              onClick={() =>
                                handleClickOpenDeleteDialog(
                                  item?.userId,
                                  item?.id,
                                  item?.initiativeId
                                )
                              }
                            />
                          </Card>
                        ))}
                    </Tabs>
                  ) : (
                    eventsData &&
                    eventsData.map((item, index) => (
                      <Card
                        sx={{
                          position: "relative",
                          minWidth: "190px",
                          maxWidth: "190px",
                          width: "190px",
                          marginLeft: "25px",
                        }}
                        className=" bshadow cardini2"
                      >
                        <CardMedia>
                          <img
                            src={
                              item?.coverimage &&
                              JSON.parse(item?.coverimage)[0]
                            }
                            onError={(e) => (e.target.src = NoImageFound)}
                            alt="Preview"
                            style={{ borderRadius: "20px" }}
                            className="form-img__img-preview-ec2"
                          />
                        </CardMedia>
                        <CardContent
                          sx={{
                            fontFamily: "HK Grotesk",
                            color: "#2C2C2C",
                            fontSize: "12px",
                            fontWeight: "bold",
                            height: "70px",
                          }}
                        >
                          <span
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#2C2C2C",
                              fontSize: "13px",
                              fontWeight: "bold",
                            }}
                            title={item?.eventTitle ? item?.eventTitle : ""}
                          >
                            {(item.eventTitle &&
                              item.eventTitle.slice(0, 20)) ||
                              "-"}
                            {item.eventTitle && item.eventTitle.length > 20
                              ? "..."
                              : ""}
                          </span>
                          <br />
                          <span
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#2C2C2C",
                              fontSize: "12px",
                              fontWeight: "bold",
                            }}
                          >
                            {Moment(item?.startDate).format("DD MMM YYYY")},
                            <span title={item?.location ? item?.location : ""}>
                              {(item.location && item.location.slice(0, 20)) ||
                                "-"}
                              {item.location && item.location.length > 20
                                ? "..."
                                : ""}
                            </span>
                          </span>
                        </CardContent>
                        <img
                          src={closeIconp}
                          className="imageclose-new"
                          onClick={() =>
                            handleClickOpenDeleteDialog(
                              index,
                              item?.userId,
                              item?.id,
                              item?.initiativeId
                            )
                          }
                        />
                      </Card>
                    ))
                  )}
                </div>
              </div>
            </div>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ justifyContent: "center" }}>
          <React.Fragment>
            <Box sx={{ display: "flex", flexDirection: "row" }}>
              <Button
                variant="contained"
                className="button-tr-2"
                autoFocus
                sx={{ backgroundColor: "#ef7335" }}
                onClick={handleSubmit(onUpdateSubmit)}
              >
                Update
              </Button>
              <Button
                variant="outlined"
                className="button-tr-citizen-cancel"
                autoFocus
                onClick={() =>
                  handleCloseUpdateInitiativeDetails(
                    reset,
                    setReportFiles,
                    setUploadFiles
                  )
                }
              >
                Cancel
              </Button>
              <Box sx={{ flex: "1 1 auto" }} />
            </Box>
          </React.Fragment>
        </DialogActions>
        <PreviewImagesDialog
          openPreviewImages={openPreviewImages}
          handleClosePreviewImages={handleClosePreviewImages}
          files={reportFiles}
        />
        {openDeleteDialog && (
          <DeleteEventDialog
            openDeleteDialog={openDeleteDialog}
            handleCloseDeleteDialog={handleCloseDeleteDialog}
            mpId={mpId}
            eventId={eventId}
            initiativeId={initiativeId}
          />
        )}
      </Dialog>
    </>
  );
};

export default UpdateInitiativeReportDetails;
