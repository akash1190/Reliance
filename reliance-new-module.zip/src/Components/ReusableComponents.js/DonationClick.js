import axios from "axios";
import Constant from "../../utils/constant";
import { getIds } from "./getIds";


const DonationClick = async () => {
    const loggedInId = getIds()
    const tkn = localStorage.getItem("tokenDetails");
    try {
        await axios.post(Constant.BASE_URL + `/api/mp/inviteDonationScore/${loggedInId}`, false, {
            headers: {
                Authorization: `Bearer ${tkn}`,
            },
        })
            .then(response => {
                return response;
            })
    }
    catch (error) {
        console.log("Error", error);
    }
}

export default DonationClick;