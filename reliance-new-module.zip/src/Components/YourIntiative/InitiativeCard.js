import React, { useRef, useState } from "react";
import Slider from "react-slick";
import "./InitiativeCard.css";
import dayjs from "dayjs";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Grid from "@mui/material/Grid";
import HighlightOffOutlinedIcon from "@mui/icons-material/HighlightOffOutlined";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import { Card, CardContent, DialogActions } from "@mui/material";
import { useFormik } from "formik";
import * as yup from "yup";
import CloseIcon from "../../asserts/images/Close.svg";

const validationSchema = yup.object({
  eventTitle: yup.string("Please enter title").required("title is required"),
  location: yup
    .string("Please enter a valid address")
    .required("location is required"),
  startDate: yup.string("Please set a start date").required("date is required"),
  startTime: yup.string("Please set a start time").required("time is required"),
  desc: yup.string("Please set a Event").required("Event is required"),
});

const cardsData = [
  "https://images.pexels.com/photos/60597/dahlia-red-blossom-bloom-60597.jpeg?auto=compress&cs=tinysrgb&w=1600",
  "https://images.pexels.com/photos/33109/fall-autumn-red-season.jpg?auto=compress&cs=tinysrgb&w=1600",
  "https://images.pexels.com/photos/1198802/pexels-photo-1198802.jpeg?auto=compress&cs=tinysrgb&w=1600",
  "https://images.pexels.com/photos/443446/pexels-photo-443446.jpeg?auto=compress&cs=tinysrgb&w=1600",
  "https://images.pexels.com/photos/60597/dahlia-red-blossom-bloom-60597.jpeg?auto=compress&cs=tinysrgb&w=1600",
  // "https://images.pexels.com/photos/33109/fall-autumn-red-season.jpg?auto=compress&cs=tinysrgb&w=1600",
  // "https://images.pexels.com/photos/1198802/pexels-photo-1198802.jpeg?auto=compress&cs=tinysrgb&w=1600"",,
];
const InitiativeCard = ({
  data,
  handleCardData,
  onClose,
  update,
  setFormImg  
}) => {
  // const [dateValue, setDateValue] = React.useState(dayjs("2014-08-18T21:11:54"));
  const [open, setOpen] = useState(false);
  const [carddata, setCardData] = useState(data);
  const [filteredImgs, setfilteredImgs] = useState(cardsData);
  const [imgPreview, setimgPreview] = useState([]);
  const [images, setImages] = useState([]);
  const hiddenFileInput = useRef(null);

  // const [value, setValue] = useState(0);
  const handleClose = () => {
    setOpen(false);
  };

  const formik = useFormik({
    initialValues: {
      eventTitle: "",
      location: "",
      startDate: "",
      endDate: "",
      startTime: "",
      endTime: "",
      desc: "",
      media: "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      values.id = carddata.id;
      values.status = "Ongoing"
      handleCardData(values);
      onClose();
    },
  });

  const handleDelete = (id) => {
    // setfilteredImgs(filteredImgs.filter((x) => x !== id));
    const updatedimgs = imgPreview.filter((x) => x !== id);
    setimgPreview(updatedimgs);

  };

  const handleImageChange = (e) => {
    const uploadedFiles = e.target.files[0];
    setFormImg(uploadedFiles)
    formik.setFieldValue("media", URL.createObjectURL(uploadedFiles));
    setimgPreview([...imgPreview, URL.createObjectURL(uploadedFiles)]);
  };
  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };
  const handleStartTime = (e)=>{
formik.setFieldValue('startTime', formik.values.startDate +"T"+ e.target.value)
  }
  const handleEndTime = (e)=>{
    formik.setFieldValue('endTime', formik.values.endDate +"T"+ e.target.value)
      }
   
  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 6,
    slidesToScroll: 4,
    arrows: true,
  };

  return (
    <form>
      <Dialog
        className="dialog-custom"
        fullWidth
        maxWidth="sm"
        open={true}
        onClose={() => onClose(false)}
        style={{ height: "inherit" }}
      >
        <DialogContent className="main_content">
          <Box sx={{ width: "100%" }}>
            <Grid rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
              <Grid item>
                <Grid direction="row" container>
                  <Grid item xs={11}>
                  {update ? <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        fontSize: "22px",
                        fontWeight: "bold",
                        color: "#2C2C2C",
                      }}
                    >
                       Edit an Event for
                    </Typography> : 
                    <Typography
                    sx={{
                      fontFamily: "HK Grotesk",
                      fontSize: "22px",
                      fontWeight: "bold",
                      color: "#2C2C2C",
                    }}
                  >
                    Create a Event for
                  </Typography>
                    }
                    <div>
                      <Typography
                        sx={{
                          fontFamily: "HK Grotesk",
                          fontSize: "27px",
                          fontWeight: "bold",
                          color: "#356F92",
                        }}
                        className="subcontent"
                      >
                        {" "}
                        {`seva -${data.id} ${data.name}`}
                      </Typography>
                    </div>
                  </Grid>
                  <Grid item xs={1}>
                    <HighlightOffOutlinedIcon
                      onClick={() => onClose(false)}
                      className="close_icon"
                    />
                  </Grid>
                </Grid>
                <Grid
                  container
                  rowSpacing={1}
                  columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                >
                  <Grid item xs={12}>
                    <label className="label-text">Event Title</label>
                    <TextField
                      fullWidth
                      margin="dense"
                      variant="outlined"
                      // label="Event Title"
                      id="eventTitle"
                      name="eventTitle"
                      value={formik.values.eventTitle}
                      onChange={formik.handleChange}
                      error={
                        formik.touched.eventTitle && Boolean(formik.errors.eventTitle)
                      }
                      helperText={formik.touched.eventTitle && formik.errors.eventTitle}
                    ></TextField>
                  </Grid>

                  <Grid item xs={12}>
                    <label className="label-text">Location</label>

                    <TextField
                      fullWidth
                      margin="dense"
                      variant="outlined"
                      // label="City"
                      id="location"
                      name="location"
                      value={formik.values.location}
                      onChange={formik.handleChange}
                      error={
                        formik.touched.location &&
                        Boolean(formik.errors.location)
                      }
                      helperText={
                        formik.touched.location && formik.errors.location
                      }
                    />
                  </Grid>

                  <Grid item xs={6}>
                    <label className="label-text">Start Date</label>
                    <TextField
                      fullWidth
                      margin="dense"
                      variant="outlined"
                      type="date"
                      id="startDate"
                      name="startDate"
                      value={formik.values.startDate}
                      onChange={formik.handleChange}
                      error={formik.touched.startDate && Boolean(formik.errors.startDate)}
                      helperText={formik.touched.startDate && formik.errors.startDate}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <label className="label-text">End Date </label>
                    <TextField
                      fullWidth
                      margin="dense"
                      variant="outlined"
                      type="date"
                      id="endDate"
                      name="endDate"
                      value={formik.values.endDate}
                      onChange={formik.handleChange}
                      error={formik.touched.endDate && Boolean(formik.errors.endDate)}
                      helperText={formik.touched.endDate && formik.errors.endDate}
                    />
                  </Grid>
                  {/* </Grid> */}
                  <Grid item xs={6}>
                    <label className="label-text">Start Time</label>
                    <TextField
                      fullWidth
                      margin="dense"
                      variant="outlined"
                      type="time"
                      id="startTime"
                      name="startTime"
                      value={formik.values.startTime.split("T")[1]}
                      onChange={(e)=>handleStartTime(e)}
                      error={formik.touched.startTime && Boolean(formik.errors.startTime)}
                      helperText={formik.touched.startTime && formik.errors.startTime}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <label className="label-text">End Time</label>
                    <TextField
                      fullWidth
                      margin="dense"
                      variant="outlined"
                      type="time"
                      id="endTime"
                      name="endTime"
                      value={formik.values.endTime.split("T")[1]}
                      onChange={(e)=>handleEndTime(e)}
                      error={formik.touched.endTime && Boolean(formik.errors.endTime)}
                      helperText={formik.touched.endTime && formik.errors.endTime}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <label className="label-text">About Event</label>

                    <TextField
                      fullWidth
                      margin="dense"
                      className="description-input"
                      variant="outlined"
                      multiline
                      rows={2}
                      // maxRows={4}  
                      type="event"
                      id="desc"
                      name="desc"
                      value={formik.values.desc}
                      onChange={formik.handleChange}
                      error={
                        formik.touched.desc && Boolean(formik.errors.desc)
                      }
                      helperText={formik.touched.desc && formik.errors.desc}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <label className="label-text">
                      Upload Promotional images
                    </label>
                    <p className="image_note">
                      Note: select one of the image as a cover photo
                      <span>*</span>
                    </p>

                    <div className="d-flex justify-content-between leaders-cards">
                      <Box
                        sx={{
                          flexGrow: 1,
                          minWidth: { xs: 400, sm: 600 },
                          // bgcolor: 'background.paper',
                        }}
                      >
                        <Tabs
                          className="cards_coniner"
                          // value={value}
                          // onChange={handleChange}
                          variant="scrollable"
                          scrollButtons
                          aria-label="visible arrows tabs example"
                          sx={{
                            [`& .${tabsClasses.scrollButtons}`]: {
                              "&.Mui-disabled": { opacity: 0.3 },
                            }
                          }}
                        >
                          {imgPreview.length > 0 &&
                            imgPreview.map((item) => (
                              <div style={{ position: "relative" }}>
                                <img
                                  src={item}
                                  width="120px"
                                  height="120px"
                                  style={{ margin: "8px" }}
                                  id={item}
                                />
                                <img
                                  src={CloseIcon}
                                  className="img-circle leader-circle-img mr-1"
                                  style={{
                                    position: "absolute",
                                    right: "10px",
                                    top: "13px",
                                    cursor: "pointer",
                                  }}
                                  width="20"
                                  onClick={() => handleDelete(item)}
                                />
                              </div>
                            ))}

                          {/* {filteredImgs?.map(
                            (item) => (
                              // <Tab label={item.name}>
                              <Card
                                sx={{ minWidth: 200, mr: 2 }}
                                className="card-size"
                              >
                                <CardContent>
                                  <Grid item sm={1}>
                                  </Grid>
                                  <img width="38.49" src={first} className="position-absolute" alt="" />
                                  <div className="text-center pt-3" key={item}>
                                    <HighlightOffOutlinedIcon
                          
                                      onClick={() => handleDelete(item)}
                                      className="close_icon_images"
                                    />
                                    <img src={img} className="img-circle leader-circle-img mr-1" width="70" />
                                    <img
                                      src={item}
                                      width="170"
                                      height="125"
                                      padding="10"
                                      style={{ borderRadius: "10px" }}
                                      onClick={() =>
                                        formik.setFieldValue("url", item)
                                      }
                                    />
                                  </div>
                                  <div className="card-content">
                                                    <h2>Shri Ramesh Bidhuri</h2>
                                                    <span className="initial">Lok Sabha MP</span><br />
                                                    <span className="constituency">Constituency : Navasari (Gujarat)</span>
                                                </div>
                                </CardContent>
                              </Card>
                            )
                          )} */}
                        </Tabs>
                      </Box>
                    </div>

                    <div class="image-upload">
                      <label for="file-input" className="label-text">
                        + Add More
                      </label>

                      <input
                        id="file-input"
                        type="file"
                        accept="image/png, image/jpeg"
                        style={{ display: "none" }}
                        onChange={handleImageChange}
                      />
                    </div>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12} mt-2>
                <Grid container className="mx-auto">
                  <Grid item xs={12} className="mx-auto">
                    <DialogActions className="submit_save">
                      {update ? (
                        <div style={{ display: "flex" }}>
                          <Button
                            variant="contained"
                            className="submit_button"
                            autoFocus
                            sx={{ backgroundColor: "#ef7335" }}
                          >
                            UPDATE
                          </Button>
                          <Button
                            variant="contained"
                            className="submit_button"
                            autoFocus
                            sx={{ backgroundColor: "#ef7335" }}
                          >
                            UPLOAD EVENT IMAGES
                          </Button>
                        </div>
                      ) : (
                        <Button
                          variant="contained"
                          className="submit_button"
                          autoFocus
                          onClick={handleClose && formik.handleSubmit}
                          sx={{ backgroundColor: "#ef7335" }}
                        >
                          Save
                        </Button>
                      )}
                    </DialogActions>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
      </Dialog>
    </form>
  );
};

export default InitiativeCard;
