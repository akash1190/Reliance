import axios from "axios";
import Constant from "../../utils/constant";
import {
    POST_CREATE_EVENT_FAILURE,
    POST_CREATE_EVENT_REQUEST,
    POST_CREATE_EVENT_SUCCESS,
} from "./types";

export const postCreateEventRequest = () => {
    return {
        type: POST_CREATE_EVENT_REQUEST,
    };
};
export const postCreateEventSuccess = (value) => {
    return {
        type: POST_CREATE_EVENT_SUCCESS,
        payload: value,
    };
};
export const postCreateEventFailure = (error) => {
    return {
        type: POST_CREATE_EVENT_FAILURE,
        payload: error,
    };
};

export const postCreateEvent = (id, payload, config) => async (dispatch) => {
    dispatch(postCreateEventRequest);
    return axios
        .post(Constant.BASE_URL + `/api/event/create/${id}`, payload, config,)
        .then((response) => {
            const result = response.data;
            dispatch(postCreateEventSuccess(result));
            return response;
        })
        .catch((error) => {
            const errorMsg = error.message;
            dispatch(postCreateEventFailure(errorMsg));
        });
};