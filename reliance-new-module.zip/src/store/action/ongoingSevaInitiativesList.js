import axios from "axios"
import Constant from "../../utils/constant"
// import { mpList } from "../../Constants/mpList"
import {
    FETCH_ONGOING_SEVA_INITIATIVES_LIST_REQUEST, FETCH_ONGOING_SEVA_INITIATIVES_LIST_SUCCESS, FETCH_ONGOING_SEVA_INITIATIVES_LIST_FAILURE,
    FETCH_ONGOING_SEVA_INITIATIVES_LIST_WITHID_REQUEST, FETCH_ONGOING_SEVA_INITIATIVES_LIST_WITHID_SUCCESS, FETCH_ONGOING_SEVA_INITIATIVES_LIST_WITHID_FAILURE,
    FETCH_ONGOING_SEVA_INITIATIVES_LIST_BY_MP_ID_REQUEST, FETCH_ONGOING_SEVA_INITIATIVES_LIST_BY_MP_ID_SUCCESS, FETCH_ONGOING_SEVA_INITIATIVES_LIST_BY_MP_ID_FAILURE,
    FETCH_INITIATIVE_REPORT_BY_ID_LIST_REQUEST, FETCH_INITIATIVE_REPORT_BY_ID_LIST_SUCCESS, FETCH_INITIATIVE_REPORT_BY_ID_LIST_FAILURE,
    FETCH_INITIATIVE_REPORT_BY_INITIATIVE_ID_AND_MP_ID_REQUEST, FETCH_INITIATIVE_REPORT_BY_INITIATIVE_ID_AND_MP_ID_SUCCESS, FETCH_INITIATIVE_REPORT_BY_INITIATIVE_ID_AND_MP_ID_FAILURE,
    FETCH_SOCIAL_MEDIA_INITIATIVES_BY_ID_REQUEST, FETCH_SOCIAL_MEDIA_INITIATIVES_BY_ID_SUCCESS, FETCH_SOCIAL_MEDIA_INITIATIVES_BY_ID_FAILURE
} from "./types"

export const fetchOngoingSevaIntiativesListRequest = () => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_REQUEST
    }
}
export const fetchOngoingSevaIntiativesListSuccess = data => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_SUCCESS,
        payload: data
    }
}
export const fetchOngoingSevaIntiativesListFailure = error => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_FAILURE,
        payload: error
    }
}

export const fetchOngoingSevaIntiativesListWithInitiativeIdRequest = () => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_WITHID_REQUEST
    }
}
export const fetchOngoingSevaIntiativesListWithInitiativeIdSuccess = data => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_WITHID_SUCCESS,
        payload: data
    }
}
export const fetchOngoingSevaIntiativesListWithInitiativeIdFailure = error => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_WITHID_FAILURE,
        payload: error
    }
}

export const fetchOngoingSevaIntiativesListByMpIdRequest = () => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_BY_MP_ID_REQUEST
    }
}
export const fetchOngoingSevaIntiativesListByMpIdSuccess = data => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_BY_MP_ID_SUCCESS,
        payload: data
    }
}
export const fetchOngoingSevaIntiativesListByMpIdFailure = error => {
    return {
        type: FETCH_ONGOING_SEVA_INITIATIVES_LIST_BY_MP_ID_FAILURE,
        payload: error
    }
}


export const fetchIntiativesReportByIdListRequest = () => {
    return {
        type: FETCH_INITIATIVE_REPORT_BY_ID_LIST_REQUEST
    }
}
export const fetchIntiativesReportByIdListSuccess = data => {
    return {
        type: FETCH_INITIATIVE_REPORT_BY_ID_LIST_SUCCESS,
        payload: data
    }
}
export const fetchIntiativesReportByIdListFailure = error => {
    return {
        type: FETCH_INITIATIVE_REPORT_BY_ID_LIST_FAILURE,
        payload: error
    }
}

export const fetchIntiativesReportByInitiativeIdAndMpIdtRequest = () => {
    return {
        type: FETCH_INITIATIVE_REPORT_BY_INITIATIVE_ID_AND_MP_ID_REQUEST
    }
}
export const fetchIntiativesReportByInitiativeIdAndMpIdSuccess = data => {
    return {
        type: FETCH_INITIATIVE_REPORT_BY_INITIATIVE_ID_AND_MP_ID_SUCCESS,
        payload: data
    }
}
export const fetchIntiativesReportByInitiativeIdAndMpIdFailure = error => {
    return {
        type: FETCH_INITIATIVE_REPORT_BY_INITIATIVE_ID_AND_MP_ID_FAILURE,
        payload: error
    }
}

export const fetchSocialMediaInitiativeByIdRequest = () => {
    return {
        type: FETCH_SOCIAL_MEDIA_INITIATIVES_BY_ID_REQUEST
    }
}
export const fetchSocialMediaInitiativeByIdSuccess = data => {
    return {
        type: FETCH_SOCIAL_MEDIA_INITIATIVES_BY_ID_SUCCESS,
        payload: data
    }
}
export const fetchSocialMediaInitiativeByIdFailure = error => {
    return {
        type: FETCH_SOCIAL_MEDIA_INITIATIVES_BY_ID_FAILURE,
        payload: error
    }
}


export const getOngoingSevaIntiativesListWithInitiativeId = (id) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchOngoingSevaIntiativesListWithInitiativeIdRequest)
    await axios.get(Constant.BASE_URL + `/api/initiative/getall/${id}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchOngoingSevaIntiativesListWithInitiativeIdSuccess(result))

        })
        .catch(error => {
            const errorMsg = error.message;
            dispatch(fetchOngoingSevaIntiativesListWithInitiativeIdFailure(errorMsg))
        })
}


export const getOngoingSevaIntiativesList = () => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchOngoingSevaIntiativesListRequest)
    await axios.get(Constant.BASE_URL + `/api/initiative/getall/${0}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response?.data?.initiative
            // const result = mpList
            dispatch(fetchOngoingSevaIntiativesListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchOngoingSevaIntiativesListFailure(errorMsg))
        })
}

export const getOngoingSevaIntiativesListByMpId = (mpId) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchOngoingSevaIntiativesListByMpIdRequest)
    await axios.get(Constant.BASE_URL + `/api/initiative/getbymp/${mpId}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response?.data?.initiative;
            // const result = mpList
            dispatch(fetchOngoingSevaIntiativesListByMpIdSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchOngoingSevaIntiativesListByMpIdFailure(errorMsg))
        })
}

export const getIntiativesReportByIdList = (initiativeId) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchIntiativesReportByIdListRequest)
    await axios.get(Constant.BASE_URL + `/api/report/getbyintiativeid/${initiativeId}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response?.data;
            // const result = mpList
            dispatch(fetchIntiativesReportByIdListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchIntiativesReportByIdListFailure(errorMsg))
        })
}

export const getIntiativesReportByInitiativeIdAndMpId = (initiativeId, mpId) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchIntiativesReportByInitiativeIdAndMpIdtRequest)
    return axios.get(Constant.BASE_URL + `/api/report/getByInitiativeIdAndMpId/${initiativeId}/${mpId}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response?.data;
            // const result = mpList
            dispatch(fetchIntiativesReportByInitiativeIdAndMpIdSuccess(result));
            return response;
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchIntiativesReportByInitiativeIdAndMpIdFailure(errorMsg))
        })
}

export const getSocialMediaIntiativesListById = (id) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchSocialMediaInitiativeByIdRequest)
    await axios.get(Constant.BASE_URL + `/api/socialMedia/getbyInitiative/${id}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response?.data;
            // const result = mpList
            dispatch(fetchSocialMediaInitiativeByIdSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchSocialMediaInitiativeByIdFailure(errorMsg))
        })
}


