import React from 'react'
import Constant from '../../utils/constant'

export const getIds = () => {
  const CryptoJS=require("crypto-js")
    let v=localStorage.getItem("mpId") && CryptoJS.AES.decrypt(localStorage.getItem("mpId"),Constant.idKey).toString(CryptoJS.enc.Utf8)

  return parseInt(v)
    
}

export const getRoles = () => {
  const CryptoJS=require("crypto-js")

    return (
      localStorage.getItem("userId") && CryptoJS.AES.decrypt(localStorage.getItem("userId"),Constant.roleKey).toString(CryptoJS.enc.Utf8)
    )
  }

