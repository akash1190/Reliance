import React, { useState, useRef, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import {
  Select,
  MenuItem,
  Button,
  TextField,
  Grid,
  Box,
  FormControl,
  InputLabel,
  Card,
  CardContent,
  Paper,
  IconButton,
  FormHelperText,
} from "@mui/material";
import { useForm } from "react-hook-form";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import "./AddMediaCoverage.css";
import UploadIcon from "@mui/icons-material/Upload";
import { useDispatch, useSelector } from "react-redux";
import { getMediaCoverageTypesList } from "../../../store/action/mediaCoverageList";
import { postCreateOpeds } from "../../../store/action/createNewOpeds";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";
import {
  getMediaCoverageList,
  getMediaCoverageListByMpID,
} from "../../../store/action/mediaCoverageList";
import closeIconp from "../../../asserts/images/close.png";
import Constant from "../../../utils/constant";
import { getIds } from "../../ReusableComponents.js/getIds";
import DeleteMediaCoverageDialog from "./DeleteMediaCoverageDialog";
import { validateNotEmpty } from "../../ReusableComponents.js/reuseMethods";
import CloseIcon from "@mui/icons-material/Close";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";

const AddMediaCoverage = ({
  handleCloseMediaCoverage,
  openMediaCoverage,
  isMediaCoverageEdit,
  details,
  handleCloseInitiativeDetails,
  mpId,
  opedsByMpId,
}) => {
  const [images, setImages] = useState([]);
  // const [value, setValue] = useState(0);
  const [files, setFiles] = useState([]);
  const dispatch = useDispatch();
  const { setLoading } = useLoading();
  const { showNotification } = useNotificationContext();
  const mediaCoverageTypesList = useSelector(
    (state) => state?.mediaCoverageTypesList?.data
  );
  const {
    register,
    handleSubmit,
    formState: { errors },
    resetField,
    reset,
  } = useForm();
  const hiddenFileInput = useRef(null);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [deleteClick, setDeleteClick] = useState(false);
  const [checkImages, setCheckImages] = useState(false);
  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  const loggedInId = getIds(); // const handleChange = (event, newValue) => {
  //     setValue(newValue);
  // };
  const fileFormats = ["image/png", "image/jpeg", "image/jpg"];
  const [type, setType] = React.useState(
    mediaCoverageTypesList && mediaCoverageTypesList[0]?.type
  );

  const handleTypeChange = (event) => {
    setType(event.target.value);
  };

  const validateURL = (URL) => {
    if (URL === "") {
      return true;
    }
    const regex = new RegExp(
      "(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?"
    );
    if (regex.test(URL)) {
      return true;
    }
    // if(URL)
    return "URL is not valid";
  };

  useEffect(() => {
    if (details) {
      setImages(details?.media && JSON.parse(details?.media));
    }
  }, [details]);

  useEffect(() => {
    if (deleteClick) {
      handleCloseMediaCoverage(reset, setImages, setFiles);
    }
  }, [deleteClick]);

  const onAddMediaCoverage = async (data) => {
    if (images.length === 0) return;
    setLoading(true);
    const tkn = localStorage.getItem("tokenDetails");
    const filesList = document.querySelectorAll(".imageupload");

    const formData = new FormData();
    formData.append("title", data?.projectTitle);
    formData.append("url", data?.url);
    formData.append("type", data?.type);
    formData.append("mpmodelId", loggedInId);
    formData.append("desc", data?.desc);
    // Array.from(files).forEach(file => formData.append(`media`, file, file.name));
    await addImagesToFormData(formData, filesList);

    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${tkn}`,
      },
    };
    const id = details?.id ? details?.id : 0;
    try {
      const response = await dispatch(postCreateOpeds(id, formData, config));
      if (response.status === 200 || response.status === 201) {
        showNotification("Success", response.data.message, "success");
        handleCloseMediaCoverage(reset, setImages, setFiles);
        if (details) {
          handleCloseInitiativeDetails();
        }
        if (opedsByMpId) {
          dispatch(getMediaCoverageListByMpID(mpId));
        } else {
          dispatch(getMediaCoverageList(0));
        }
        // Object.keys(data).map(val => resetField(val));
        // setImages([]);
        // setFiles([]);
      }
    } catch (error) {
      showNotification("Error", "Failed to fetch");
    } finally {
      setLoading(false);
    }
  };

  const addImagesToFormData = async (formData, files) => {
    for (let i = 0; i < files.length; i++) {
      const response = await fetch(files[i].src);
      const blob = await response.blob();
      const file = new File(
        [blob],
        blob.type.startsWith("image/") ? `image${i}.jpg` : `video${i}.mp4`,
        { type: files[i].type === "image" ? "image/*" : "video/*" }
      );
      formData.append(`media`, file, file.name);
    }
  };

  useEffect(() => {
    //call api to update store
    dispatch(getMediaCoverageTypesList());
  }, []);

  const handleClickOpenDeleteDialog = () => {
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => setOpenDeleteDialog(false);

  useEffect(() => {
    setType(mediaCoverageTypesList && mediaCoverageTypesList[0]?.type);
  }, [mediaCoverageTypesList]);

  const handleDelete = (index) => {
    hiddenFileInput.current.value = "";
    const tempImages = [...images];
    tempImages.splice(index, 1);
    setImages(tempImages);
    const tempFiles = [...files];
    tempFiles.splice(index, 1);
    setFiles(tempFiles);
  };

  const handleImageChange = (e) => {
    const uploadedFiles = e.target.files;
    setFiles([...files, ...uploadedFiles]);
    let newFiles = [];
    for (let i = 0; i < uploadedFiles.length; i++) {
      const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
        if (uploadedFiles[i].type.startsWith("image")) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          newFiles.push({
            type: "image",
            url: reader.result,
            file: uploadedFiles[i],
          });
        } else if (uploadedFiles[i].type.startsWith("video")) {
          if (!isRightFormat) {
            showNotification(
              "Error",
              "You can only upload jpg, jpeg and png images",
              "error"
            );
            return;
          }
          newFiles.push({
            type: "video",
            url: reader.result,
            file: uploadedFiles[i],
          });
        }
        if (i === uploadedFiles.length - 1) {
          setImages([...newFiles, ...images]);
        }
      };
    }
  };

  // const handleImageChange = (e) => {
  //     const uploadedFiles = e.target.files;
  //     setFiles([...files, ...uploadedFiles]);
  //     let newImages = [];
  //     for (let i = 0; i < uploadedFiles.length; i++) {
  //         const reader = new FileReader();
  //         reader.readAsDataURL(uploadedFiles[i]);
  //         reader.onload = () => {
  //             newImages.push({ url: reader.result, file: uploadedFiles[i] });
  //             if (i === uploadedFiles.length - 1) {
  //                 setImages([...images, ...newImages]);
  //             }
  //         };
  //     }
  // };

  const handlePreview = (file) => {
    // if (file.type === "image" || details) {
    //     return <img src={typeof file === 'string' ? file : file.url} alt="Preview" className="imageupload form-img__img-preview-ed1" id="imageupload" />;
    // }
    // if (file.type === "video" || details) {
    //     return (
    //         <video controls className="imageupload form-img__img-preview-ed1" id="imageupload">
    //             <source src={typeof file === 'string' ? file : file.url} />
    //             Your browser does not support the video tag.
    //         </video>
    //     );
    // }
    if (file.type === "image") {
      return (
        <img
          src={typeof file === "string" ? file : file.url}
          alt="Preview"
          className="imageupload form-img__img-preview-ed1"
          id="imageupload"
          onESrror={(e) => (e.target.src = NoImageFound)}
        />
      );
    }
    if (file.type === "video") {
      return (
        <video
          controls
          className="imageupload form-img__img-preview-ed1"
          id="imageupload"
        >
          <source
            src={typeof file === "string" ? file : file.url}
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      );
    }
    const images = ["jpg", "gif", "png", "svg", "jfif"];
    const videos = ["mp4", "3gp", "ogg"];
    const url = new URL(file);
    const extension = url.search.split(".")[1];
    if (images.includes(extension)) {
      return (
        <img
          src={file}
          alt="Preview"
          className="imageupload form-img__img-preview-ed1"
          id="imageupload"
        />
      );
    }
    if (videos.includes(extension)) {
      return (
        <div>
          {/* <img src={playicon} onClick={handleHideImage} /> */}
          <video
            controls
            className="imageupload form-img__img-preview-ed1"
            id="imageupload"
          >
            <source
              src={typeof file === "string" ? file : file.url}
              type="video/mp4"
            />
            Your browser does not support the video tag.
          </video>
        </div>
      );
    }
  };

  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };

  return (
    <>
      <Dialog
        open={openMediaCoverage}
        onClose={() => handleCloseMediaCoverage(reset, setImages, setFiles)}
        sx={{ height: "96vh", mt: 2.5, overflowX: "hidden" }}
      >
        <DialogTitle>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              color: "#357092",
              fontFamily: "HK Grotesk",
              fontSize: "26px",
              fontWeight: "bold",
            }}
          >
            <div>
              <b>Op-ed's, Books & Media Coverage</b>
            </div>
            <CloseIcon
              className="pageHeader"
              onClick={() =>
                handleCloseMediaCoverage(reset, setImages, setFiles)
              }
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
                border: "1px solid #9e9e9e",
                borderRadius: "50%",
                padding: "2px",
                cursor: "pointer",
              }}
            />
          </Box>
        </DialogTitle>
        <Grid container className="bg-white" sx={{ overflowX: "hidden" }}>
          <Grid item xs={12} md={12}>
            <Grid item xs={12} md={12} sx={{ p: 4 }}>
              <Box>
                <form>
                  <Grid
                    container
                    spacing={1}
                    justifyContent="left"
                    alignItems="center"
                  >
                    <Grid container sx={{ mb: 2 }}>
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#357092",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                            }}
                          >
                            <b> Title</b>
                          </div>
                          <TextField
                            className="stepperFormInput"
                            // label="Title"
                            name="title"
                            fullWidth
                            placeholder="Enter title"
                            size="small"
                            required
                            defaultValue={details && details?.title}
                            autoComplete="off"
                            {...register("projectTitle", {
                              required: "Please enter title",
                              maxLength: {
                                value: 50,
                                message: "Max length 50",
                              },
                              validate: (value) =>
                                validateNotEmpty(value, "title"),
                            })}
                            //   error={Boolean(errors?.employeeId?.message)}
                            //   helperText={errors?.employeeId?.message}
                            //   onChange={() => setIsUpdateButton(false)}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.projectTitle?.message}
                        </FormHelperText>
                      </Grid>
                    </Grid>
                    <Grid container sx={{ mb: 2 }}>
                      <Grid item xs={12}>
                        <div
                          style={{
                            fontFamily: "HK Grotesk",
                            color: "#357092",
                            fontSize: "16px",
                            fontWeight: "bold",
                            marginLeft: "5px",
                            marginBottom: "2px",
                          }}
                        >
                          <b> Type</b>
                        </div>

                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <InputLabel
                            id="demo-simple-select-label"
                            sx={{ marginTop: "-6px" }}
                          ></InputLabel>
                          <Select
                            className="stepperFormInput"
                            // label="Type"
                            name="type"
                            fullWidth
                            defaultValue={details?.type}
                            required
                            size="small"
                            autoComplete="off"
                            {...register("type", {
                              required: "Please select type",
                            })}
                            SelectDisplayProps={{
                              renderValue: (defaultValue) => defaultValue,
                            }}
                            onChange={handleTypeChange}
                            // value={type}
                            // error={errors?.roleId}
                            // helperText={errors?.roleId?.message}
                            // onChange={() => setIsUpdateButton(false)}
                          >
                            {mediaCoverageTypesList &&
                              mediaCoverageTypesList.map((s) => {
                                return (
                                  <MenuItem
                                    native
                                    key={s.type}
                                    sx={{ width: "100%" }}
                                    value={s.type}
                                    size="small"
                                  >
                                    {s.type}
                                  </MenuItem>
                                );
                              })}
                          </Select>
                          <FormHelperText
                            sx={{ color: "#d32f2f", ml: "10px", mr: 0 }}
                          >
                            {errors && errors?.type?.message}
                          </FormHelperText>
                        </FormControl>
                      </Grid>
                    </Grid>
                    <Grid container>
                      <div
                        style={{
                          fontFamily: "HK Grotesk",
                          color: "#357092",
                          fontSize: "16px",
                          fontWeight: "bold",
                          marginLeft: "5px",
                          marginBottom: "20px",
                        }}
                      >
                        <b> Attach Media</b>
                      </div>
                      <div
                        className="contpopup1"
                        style={{
                          flexDirection: "row-reverse",
                          marginLeft: "5px",
                        }}
                      >
                        {/* {images?.length > 0 ? ( */}
                        <>
                          <div
                            style={{ width: "470px", top: "0px", marginLeft: "35px" }}
                            className="postionabs-2 itemfixed-update"
                          >
                            {images?.length > 1 ? (
                              <Tabs
                                // value={value}
                                // onChange={handleChange}
                                variant="scrollable"
                                scrollButtons
                                aria-label="visible arrows tabs example"
                                sx={{
                                  [`& .${tabsClasses.scrollButtons}`]: {
                                    "&.Mui-disabled": { opacity: 0.3 },
                                  },
                                }}
                              >
                                {images?.map((file, index) => (
                                  <Card
                                    sx={{
                                      minWidth: 200,
                                      borderRadius: 0,
                                      boxShadow: "none",
                                    }}
                                    className="form-img__img-preview-ed1 "
                                  >
                                    <CardContent>
                                      {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                      <div key={index}>
                                        {handlePreview(file)}
                                      </div>
                                      {/* <img key={index} src={typeof image === 'string' ? image : image.url} alt="" className="form-img__img-preview" /> */}
                                      <img
                                        src={closeIconp}
                                        onClick={() => handleDelete(index)}
                                        className="imageclose-2"
                                      />
                                      {/* <Button onClick={() => handleDelete(index)}>delete</Button> */}
                                    </CardContent>
                                  </Card>
                                ))}
                              </Tabs>
                            ) : (
                              images?.map((file, index) => (
                                <Card
                                  sx={{
                                    minWidth: 200,
                                    borderRadius: 0,
                                    boxShadow: "none",
                                  }}
                                  className="form-img__img-preview-ed1"
                                >
                                  <CardContent>
                                    {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                    <div key={index}>{handlePreview(file)}</div>
                                    {/* <img key={index} src={typeof image === 'string' ? image : image.url} alt="" className="form-img__img-preview" /> */}
                                    {/* <Button onClick={() => handleDelete(index)}>delete</Button> */}
                                    <img
                                      src={closeIconp}
                                      onClick={() => handleDelete(index)}
                                      className="imageclose-2"
                                    />
                                  </CardContent>
                                </Card>
                              ))
                            )}
                          </div>
                          <Grid item xs={6}>
                            <input
                              type="file"
                              ref={hiddenFileInput}
                              style={{ display: "none" }}
                              multiple
                              onChange={handleImageChange}
                              accept="image/png, image/jpeg, image/jpg"
                            />
                            {/* <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} /> */}
                            <Box
                              sx={{
                                // ml: "-95px",
                                display: "flex",

                                // position: 'relative',
                                "& > :not(style)": {
                                  width: 150,
                                  height: 140,
                                  // position: "relative",
                                  //  left: "-31%",
                                  // top: "8%",
                                  // marginTop: "32px",
                                },
                              }}
                            >
                              <Paper
                                variant="outlined"
                                square
                                sx={{
                                  border: "dotted 3px #1976d2",
                                  padding: "50px",
                                  width: "40%",
                                  borderRadius: "14px",
                                }}
                              >
                                <IconButton
                                  color="primary"
                                  aria-label="Upload"
                                  onClick={handleClick}
                                  sx={{
                                    display: "flex",
                                    marginTop: "-10px",
                                    justifyContent: "center",
                                  }}
                                >
                                  <UploadIcon />
                                </IconButton>

                                <b
                                  style={{
                                    display: "flex",
                                    justifyContent: "center",
                                    position: "relative",
                                    // top: "25%",
                                    whiteSpace: "nowrap",
                                  }}
                                >
                                  {" "}
                                  Add More Images
                                </b>
                                <FormHelperText
                                  sx={{
                                    color: "#d32f2f",
                                    width: "max-content",
                                    marginTop: "38px",
                                    marginLeft: "-45px !important",
                                  }}
                                >
                                  {checkImages &&
                                    images.length === 0 &&
                                    "Please upload images"}
                                </FormHelperText>
                              </Paper>
                            </Box>
                          </Grid>
                        </>
                        {/* ) : null} */}
                        {/*  */}
                      </div>
                    </Grid>

                    <Grid container sx={{ mb: 2, mt: 1 }}>
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#357092",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "2px",
                              marginTop: "3%",
                            }}
                          >
                            <b> Description</b>
                          </div>
                          <TextField
                            className="stepperFormInput"
                            // label="Description"
                            name="desc"
                            placeholder="Enter Description"
                            fullWidth
                            required
                            multiline
                            rows={4}
                            defaultValue={details && details.desc}
                            size="small"
                            autoComplete="off"
                            {...register("desc", {
                              required: "Please enter description",
                              maxLength: {
                                value: 1000,
                                message: "Max length 1000",
                              },
                              validate: (value) =>
                                validateNotEmpty(value, "description"),
                            })}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.desc?.message}
                        </FormHelperText>
                      </Grid>
                    </Grid>
                    <Grid container>
                      <Grid item xs={12} sx={{ pr: 1 }}>
                        <FormControl
                          fullWidth
                          sx={{
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderRadius: "14px",
                            },
                          }}
                        >
                          <div
                            style={{
                              fontFamily: "HK Grotesk",
                              color: "#357092",
                              fontSize: "16px",
                              fontWeight: "bold",
                              marginLeft: "5px",
                              marginBottom: "5px",
                            }}
                          >
                            <b> Link</b>
                          </div>

                          <TextField
                            className="stepperFormInput"
                            // label="Link"
                            name="url"
                            // placeholder="Link"
                            fullWidth
                            required
                            defaultValue={details && details.url}
                            size="small"
                            autoComplete="off"
                            {...register("url", {
                              //   required: "Please enter url",
                              maxLength: {
                                value: 50,
                                message: "Max length 50",
                              },
                              //   validate: (value) =>
                              //     validateNotEmpty(value, "url"),
                              validate: (value) => validateURL(value),
                              // , validate: {
                              //     pattern: /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/g,
                              //     // message: "Invalid "
                              // }
                            })}
                          />
                        </FormControl>
                        <FormHelperText sx={{ color: "#d32f2f" }}>
                          {errors && errors?.url?.message}
                        </FormHelperText>
                      </Grid>
                    </Grid>
                  </Grid>
                </form>
              </Box>
            </Grid>
            <React.Fragment>
              <Box sx={{ display: "flex", flexDirection: "row", p: 2, pl: 30 }}>
                <Button
                  variant="contained"
                  sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                  className="button-tr-2"
                  onClick={handleSubmit(onAddMediaCoverage)}
                  onFocus={() => setCheckImages(true)}
                >
                  {isMediaCoverageEdit ? "Update" : "Submit"}
                </Button>
                {isMediaCoverageEdit && (
                  <Button
                    variant="outlined"
                    onClick={handleClickOpenDeleteDialog}
                    sx={{ p: 1, mr: 1 }}
                    className="button-tr-2-1 "
                  >
                    Delete
                  </Button>
                )}
                {!isMediaCoverageEdit && (
                  <Button
                    variant="outlined"
                    onClick={() =>
                      handleCloseMediaCoverage(reset, setImages, setFiles)
                    }
                    sx={{ p: 1, mr: 1 }}
                    className="button-tr-2-1 "
                  >
                    Cancel
                  </Button>
                )}
                {/* <div style={{ marginTop: "12px" }}>
                                    {isMediaCoverageEdit && (
                                        <img
                                            src={imagedelete}
                                            onClick={handleClickOpenDeleteDialog}
                                            className="deleteimgcss1 cursorshow"
                                            style={{ marginTop: "0px", marginLeft: "15px" }}
                                            alt="delete"
                                        />
                                    )}
                                </div> */}
                <Box sx={{ flex: "1 1 auto" }} />
              </Box>
            </React.Fragment>
            {openDeleteDialog && (
              <DeleteMediaCoverageDialog
                openDeleteDialog={openDeleteDialog}
                handleCloseDeleteDialog={handleCloseDeleteDialog}
                opedId={details?.id}
                mpId={mpProfileData?.id || mpId}
                handleCloseMediaCoverage={handleCloseMediaCoverage}
                opedsByMpId={opedsByMpId}
                handleCloseInitiativeDetails={handleCloseInitiativeDetails}
                details={details}
                setDeleteClick={setDeleteClick}
                isMediaCoverageEdit={isMediaCoverageEdit}
              />
            )}
          </Grid>
        </Grid>
      </Dialog>
    </>
  );
};

export default AddMediaCoverage;
