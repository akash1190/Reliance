import axios from "axios";
import Constant from "../../utils/constant";
import {
    POST_CREATE_OPEDS_FAILURE,
    POST_CREATE_OPEDS_REQUEST,
    POST_CREATE_OPEDS_SUCCESS,
} from "./types";

export const postCreateOpedsRequest = () => {
    return {
        type: POST_CREATE_OPEDS_REQUEST,
    };
};
export const postCreateOpedsSuccess = (value) => {
    return {
        type: POST_CREATE_OPEDS_SUCCESS,
        payload: value,
    };
};
export const postCreateOpedsFailure = (error) => {
    return {
        type: POST_CREATE_OPEDS_FAILURE,
        payload: error,
    };
};

export const postCreateOpeds = (id, payload, config) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(postCreateOpedsRequest);

    return axios
        .post(Constant.BASE_URL + `/api/opeds/create/${id}`, payload, config, {
            headers: {
                Authorization: `Bearer ${tkn}`,
            },
        })
        .then((response) => {
            const result = response.data;
            dispatch(postCreateOpedsSuccess(result));
            return response;
        })
        .catch((error) => {
            const errorMsg = error.message;
            dispatch(postCreateOpedsFailure(errorMsg));
        });
};