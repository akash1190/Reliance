import React, { useEffect, useRef, useState } from 'react';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import CloseIcon from '@mui/icons-material/Close';
import { IconButton, Grid, Box, Button, Toolbar } from '@mui/material';
import DialogActions from '@mui/material/DialogActions';
import closeIconp from "../../../../asserts/images/close-1.png";
import { useNotificationContext } from "../../../../utils/NotificationContext";
import AddIcon from "@mui/icons-material/Add";

const UploadImages = ({ handleCloseUploadDialog, state, setValue, getValue, initialImages, setImagesNew,
    setInputData, fileFormats, setCheckWarningPopup }) => {
    const [images, setImages] = useState(initialImages.length > 0 && initialImages);
    const [files, setFiles] = useState([]);
    const [uploadMore, setUploadMore] = useState(false)
    const { showNotification } = useNotificationContext();
    const handleFileChange = (e) => {
        const uploadedFiles = e.target.files;
        if (uploadedFiles.length > 0) {
            setCheckWarningPopup(true);
        }
        setFiles([...files, ...uploadedFiles]);
        let newImages = [];
        for (let i = 0; i < uploadedFiles.length; i++) {
            const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
            const reader = new FileReader();
            reader.readAsDataURL(uploadedFiles[i]);
            reader.onload = () => {
                newImages.push({ url: reader.result, file: uploadedFiles[i] });
                if (i === uploadedFiles.length - 1) {
                    // setImages(prevState => [...prevState, ...newImages])
                    if (!isRightFormat) {
                        showNotification("Error", "You can only upload jpg, jpeg and png images", "error");
                        return;
                    }
                    setImages([...images, ...newImages]);

                    setImagesNew([...images, ...newImages]);
                    setUploadMore(true);
                }
            };
        }
    };

    const handleDelete = (index) => {
        setCheckWarningPopup(true);
        const tempImages = [...images]
        tempImages.splice(index, 1)
        setImages(tempImages);
    }

    const closeDialog = (event, reason) => {
        if (reason && reason == "backdropClick") 
            return;
        setImages([])
        setInputData(prevState => {
            const newState = [...prevState]; // make a copy of the state array
            delete newState[`${state.for}`].imagesData
            // newState[`${state.for}`] = { ...newState[`${state.for}`], imagesData: [] }; // update the i'th object's imagesData

            return newState;
        });
        setValue(`${state.for}.images`, [])
        handleCloseUploadDialog()
    }

    useEffect(() => {
    }, [getValue])
    useEffect(() => {
        setValue(`${state.for}.images`, images)

        // setInputData(`${state.for}.imagesData`,images)
        setInputData(prevState => {
            const newState = [...prevState]; // make a copy of the state array
            newState[`${state.for}`] = { ...newState[`${state.for}`], imagesData: images }; // update the i'th object's imagesData

            return newState;
        });

    }, [images])

    useEffect(() => {
        setImages(initialImages)
    }, [initialImages])

    useEffect(() => {
        setInputData(prevState => {
            const newState = [...prevState]; // make a copy of the state array
            newState[`${state.for}`] = { ...newState[`${state.for}`], imagesData: images }; // update the i'th object's imagesData

            return newState;
        });
        if (images?.length === 0 && getValue(`${state.for}.images`)?.length) {

            setValue(`${state.for}`, images)
        }
    }, [getValue, images, setValue, state])


    useEffect(() => {
        if (uploadMore) {
            // getValue(`${state.for}`) && setImages(getValue(`${state.for}`))
            // setValue(`${state.for}.images`, images)
            // setInputData(`${state.for}.imagesData`,images)
            setUploadMore(false)
        }
        // }, [getValue, state])

    }, [images])

    return (

        <Dialog onClose={closeDialog} 
        disableEscapeKeyDown  open={state.open} sx={{ borderRadius: "14px" }}  >
            <DialogTitle sx={{ fontFamily: 'HK Grotesk', color: "#2e739c", fontWeight: "700", textAlign: "center", fontSize: "26px" }}>Image Preview</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={closeDialog}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                    border: "1px solid #9e9e9e",
                    borderRadius: "50%"
                }}
            >
                <CloseIcon />
            </IconButton>
            <Grid item xs={6}  >
                {/* <span style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "18px", fontWeight: 'bold', marginLeft: "15px", position: "relative", bottom: "10px" }}>Image Preview</span> */}
                <div style={{ height: "50vh" }}  >
                    <Box
                        sx={{
                            overflow: "auto",
                            display: 'flex',
                            '& > :not(style)': {
                                marginLeft: "15px",
                                width: 200,
                                height: 350,
                            },
                        }}
                    >
                        <div className="image-column-align image-container">

                            {images && images.map((image, index) => (
                                <div key={Date.now() + index}>
                                    <img key={index} className={`imageuploadFinal${state.for}`} src={typeof image === "string"
                                        ? image
                                        : image.url} alt="" style={{ width: 180, height: 150 }} />
                                    {/* <Button className='imageclose' >delete</Button> */}
                                    <img src={closeIconp} onClick={() => handleDelete(index)} className="imageclose" />
                                </div>
                            ))}
                        </div>


                        {/* <Button onClick={handleClick} variant="contained" sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                        className="button-primary-alt-contained">Upload Videos</Button> */}
                        {/* Add More Videos */}
                        {/* </Paper> */}
                    </Box>
                </div>



            </Grid>

            <DialogActions sx={{ justifyContent: "flex-start", marginBottom: "10px", marginLeft: "15px" }}>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "row",
                        mb: 2,
                        marginLeft: "-15px",
                    }}
                >
                    <Button
                        variant="outlined"
                        className="button-tr-citizen-admin"
                        startIcon={<AddIcon sx={{ mt: "5px" }} />}
                    >
                        <input type="file" multiple onChange={handleFileChange} accept="image/png, image/jpeg, image/jpg" style={Styles.input} />
                        Add More
                    </Button>
                    <Box sx={{ flex: "1 1 auto" }} />
                </Box>
                {/* <Button variant="contained" className='button-tr-2' style={Styles.button}>
                    <input type="file" multiple onChange={handleFileChange} accept="image/png, image/jpeg, image/jpg" style={Styles.input} />
                    Upload More</Button> */}
                <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                <Button
                        variant="contained"
                        className="button-tr-2"
                        autoFocus
                        onClick={handleCloseUploadDialog}
                        sx={{ backgroundColor: "#ef7335", left: "50%", }}
                    >
                        Save
                    </Button>
                    <Box sx={{ flex: "1 1 auto" }} />
                </Box>
                <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                    <Button
                        variant="outlined"
                        className="button-tr-citizen-cancel"
                        sx={{
                            p: 1,
                            mr: 1,
                            backgroundColor: "#ef7335",
                            borderRadius: 4,
                            position: "relative",
                            left: "40%",
                        }}
                        // className="button-tr-2"
                        type="submit"
                        onClick={closeDialog}
                    >
                        Cancel
                    </Button>
                    <Box sx={{ flex: "1 1 auto" }} />
                </Box>
            </DialogActions>
        </Dialog >


    )
}

const Styles = {
    // button: {
    //     position: 'relative',
    //     overflow: 'hidden',
    //     width: 'fit-content'
    // },
    input: {
        position: 'absolute',
        opacity: '0',
        cursor: 'pointer'
    }
}

export default UploadImages;