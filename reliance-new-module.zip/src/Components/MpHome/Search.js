import {
  Card,
  CardActionArea,
  CardContent,
  CardMedia,
  Hidden,
  InputAdornment,
  List,
  TextField,
  Typography,
  Button
} from "@mui/material";
import { Box } from "@mui/system";
import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router";
import searchIcon from "../../asserts/images/Search.svg";
import closeIcon from "../../asserts/images/close.png";
import { shallowEqual, useDispatch, useSelector } from "react-redux";
import { searchMpList } from "../../store/action/mpSearch";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import NoImageFound from "../../asserts/images/noImageFound.jpg";

const Search = ({ user }) => {
  const inputRef = useRef(null);
  const [searchInput, setSearchInput] = useState([]);
  const [filteredList, setFilteredList] = useState([]);
  const [anchorEl, setAnchorEl] = React.useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const mpList = useSelector((state) => state?.mpSearchList?.data);
  const isSearching = useSelector((state) => state?.mpSearchList?.loading, shallowEqual);
  const handleClose = () => {
    setSearchInput([])
    setAnchorEl(false);

  };

  const handleSearch = (event) => {

    setSearchInput(event.target.value)

    if (event.target.value.length >= 1) {
      setAnchorEl(true)
    } else {

      setAnchorEl(false)
    }
    dispatch(searchMpList(event?.target?.value));
    if (mpList) {
      const filtered = mpList.filter((value) =>
        value.user_name.toUpperCase().includes(event.target.value.toUpperCase())
      );
      setFilteredList(filtered);
    }
    // open = true;
  };

  const blockInvalidChar = e => ['#', '&', '+', '_', '!', '@', '%', '[', ']', '=', '*', '^', '-', '?', '/', '$', ')', '('].includes(e.key) && e.preventDefault();

  useEffect(() => {
    if(searchInput.length>0)
    dispatch(searchMpList(searchInput));

  }, [searchInput])
  return (
    <div className="cursorshow" style={{ position: "relative" }}>
      <TextField
        className="search-filter-icon cursorshow"
        sx={{
          "& fieldset": { border: "none" },
        }}
        onChange={(e) => {
          handleSearch(e);
        }}
        onKeyDown={blockInvalidChar}
        inputRef={inputRef}
        value={searchInput}
        placeholder="Search MP / Constituency"
        InputProps={{
          endAdornment: (
            <InputAdornment position="start">
              {/* search icon  */}
              <img
                className="searchIcon cursorshow"
                width={20}
                height={21}
                src={searchIcon}
                onClick={() => {
                  inputRef.current.focus();
                }}
              />
            </InputAdornment>
          ),
        }}
      > </TextField>
      {(mpList && mpList.length !== 0 && anchorEl) ? (
        <>
          <div className="searchfixed-2">
            <Typography
              sx={{ margin: "2% 8% 2% 8%", display: "inline-flex", fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "24px", fontWeight: "bold" }}
              variant={"h5"}
            >
              Results for “{searchInput}”
            </Typography>
            <img
              src={closeIcon}
              width={16}
              height={16}
              className="m-3"
              onClick={handleClose}
              style={{ float: "right", cursor: "pointer" }}
              alt="close"
            />

            <List
              sx={{
                width: "400px",
                bgcolor: "background.paper",
                position: "absolute",
                zIndex: 1000,
                // marginTop: "8px",
                // borderRadius: "5%",
                overflowX: "hidden",
                overflowY: "auto",
                maxHeight: "430px",
                minHeight: "100px",
                "& ul": { padding: 0 },
                borderBottomLeftRadius: "20px",
                borderBottomRightRadius: "20px",
                paddingBottom: "10px"
              }}
              subheader={<li />}

            >

              {/* <ul style={{position:"absolute",zIndex:1000,background:"white",width:"500px",textAlign:"center"}}> */}
              {mpList.map((i) => (
                // <li key={i.name}>{i.name} - {i.constituency}</li>
                <Card
                  sx={{ margin: "2% 8% 2% 4%", width: "360px", borderRadius: "14px" }}
                  onClick={() =>
                    navigate("/Mp_SevaUpdate", {
                      state: {
                        MpName: i.user_name,
                        user: user,
                        mpId: i.id,
                        mpClick: true,
                      mpData: i && i
                      },
                    })
                  }
                // onClick={(e) => {
                  
                    
                   
                    
                    
                //   if (!window.getSelection().toString()) {
                //     navigate("/Mp_SevaUpdate", {
                //       state: {
                //         MpName: item.user_name,
                //         user: user,
                //         mpId: item.id,
                //         mpClick: true,
                //       },
                //     });
                //   }
                // }}
                >
                  <CardActionArea >

                    {i.user_avatar? (<img
                      src={i.user_avatar}
                      alt={i.user_name}
                      className="card-image-search circularimagesearch"
                    />): (
                        <div className="text-center pt-3">
                          <AccountCircleIcon
                            sx={{
                              fontSize: "xx-large",
                              width: "70px",
                              height: "auto",
                              border:0,
                              background:"white",
                              top:
                                    i.coverimage 
                                      ? "45px"
                                      : "80px"
                              
                            }}                                               
                             className="card-image-search circularimagesearch"

                          />
                        </div>
                      )}
                    {i.coverimage ? (
                      <CardMedia
                        component="img"
                        height="65px"
                        image={i.coverimage}
                        alt={i.user_name}
                        sx={{ maxWidth: "100%!important" }}
                        onError={e=>e.target.src= NoImageFound}
                      />
                    ) : (
                      <Box height="6.3em" sx={{ backgroundColor: "#DFF6FF" }} />
                    )}
                    <CardContent sx={{ paddingLeft: "90px" }}>
                      <Typography className="serach-card-head" component="div">
                        {i.user_name}
                      </Typography>
                      <Typography
                        className="serach-card-head-2 "
                        color="text.secondary"
                      >
                      { i.designation && i.party &&<> {i.designation} -{i.party},<br /></>}
                        {i.constituency_name}
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              ))}
              {/* </ul> */}
            </List>  </div></>

      )
        :
        searchInput?.length > 0 && !isSearching && (
          <div className="searchfixed-2">
            <Typography
              sx={{ margin: "2% 8% 2% 8%", display: "inline-flex", fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "24px", fontWeight: "bold" }}
              variant={"h5"}
            >
              Results for “{searchInput}”
              <br />
              <br />
              No Results Found
            </Typography>
          </div>
        )
      }
    </div>
  );
};

export default Search;
