import React, { useEffect, useState } from 'react'
import { isMobile } from 'react-device-detect';
import {
  FacebookShareButton,

  TwitterShareButton,
  WhatsappShareButton,
  EmailShareButton,
  FacebookIcon,
  TwitterIcon,
  WhatsappIcon,
  EmailIcon,
  MailruShareButton,
} from 'react-share';
import CopyAndShareClick from './CopyAndShareAPI';
import exampleImage from "../../asserts/images/profile.jpg"

import DonationClick from "./DonationClick";
const Share = ({ data, content, linkurl, title, initiativeReport, donation }) => {
  let eventName = ""
  let organizerName = ""
  if (title) {
    organizerName = data?.user?.user_name;
    switch (title) {
      case "Ongoing Seva Initiatives":
        eventName = initiativeReport ? data?.eventTitle : data.initiativeName
        organizerName = "India"
        break;
      case "Seva aur Samarpan Campaign":
        eventName = data.eventTitle;
        organizerName = data?.user?.user_name;
        break;
      case "OP-ed's, Books & Media Coverage of":
        eventName = data.title
        break;
      case "Development Projects":
        eventName = data.projecttitle
        break;


      default:
        break;
    }
  }


  const eventLink = "https://example.com/event";

  // const title = 'GitHub';
  const [link, setLink] = useState("http://apps.apple.com/ or https://play.google.com/")
  const [shareMessage, setShareMessage] = useState(`Join an exciting and interesting event "${eventName}" organised by ${organizerName} ${eventLink} via NaMo app.
    Install NaMo app on App store or play store.`);

  const handleShare = () => {
    // const link = "https://example.com";
    const subject = "Share NAMO APP";
    navigator.share({ title: subject, url: link, body: shareMessage })
      .then(() => {
      })
      .catch((error) => {
        if (error.message === "cancelled") {
        } else {
        }
      });
  };
  useEffect(() => {
    if (content) {
      setShareMessage(content)
      linkurl && setLink(linkurl)
    }
  }, [])
  return (
    <>

      <div>
        <FacebookShareButton
          url={link}
          hashtag="NamoApp"
          quote={shareMessage}
          // onClick={donation=="check" ? DonationClick : CopyAndShareClick }
          onClick={donation ? DonationClick : CopyAndShareClick}
        >
          <FacebookIcon size={60} round />
        </FacebookShareButton>
        <figcaption className="ssfigcap">Facebook</figcaption>
      </div>



      <div>
        <TwitterShareButton
          url={link}
          title={shareMessage}
          onClick={donation ? DonationClick : CopyAndShareClick}
        >
          <TwitterIcon size={60} round />
        </TwitterShareButton>
        <figcaption className="ssfigcap">Twitter</figcaption>
      </div>


      <div className="Demo__some-network">
        <WhatsappShareButton
          url={link}
          title={shareMessage}
          onClick={donation ? DonationClick : CopyAndShareClick}
          separator=":: "
        >
          <WhatsappIcon size={60} round />
        </WhatsappShareButton>

        <figcaption className="ssfigcap">Whatsapp</figcaption>
      </div>



      <div className="Demo__some-network">
        <EmailShareButton
          subject={"Share NAMO APP"}
          // body={shareMessage}
          openShareDialogOnClick
          url={link}
          onClick={() => {
            donation ? DonationClick() : CopyAndShareClick()
          }
          }
        >
          <EmailIcon size={60} round />
        </EmailShareButton>
        <figcaption className="ssfigcap">Email</figcaption>
      </div>



    </>
  )
}

export default Share