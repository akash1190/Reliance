
import {TEXT_FAILURE,TEXT_REQUEST,TEXT_SUCCESS} from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const getText = (state = initialState, action) => {
    switch (action.type) {
        case TEXT_REQUEST:
            return {
                state,
            }
        case TEXT_SUCCESS:
            return {
                data: action.payload
            }
        case TEXT_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}