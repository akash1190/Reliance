import axios from "axios"
import Constant from "../../utils/constant"
import { GET_EVENT_FAILURE,GET_EVENT_REQUEST,GET_EVENT_SUCCESS} from "./types"

export const fetchGetMpEventsRequest = () => {
    return {
        type: GET_EVENT_REQUEST
    }
}
export const fetchGetMpEventsSuccess = value => {
    return {
        type: GET_EVENT_SUCCESS,
        payload: value
    }
}
export const fetchGetMpEventsFailure = error => {
    return {
        type: GET_EVENT_FAILURE,
        payload: error
    }
}

export const getEvents = (id) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchGetMpEventsRequest)
    await axios.get(Constant.BASE_URL + `/api/event/getall/${id}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
    .then(response => {
        const result = response.data
        dispatch(fetchGetMpEventsSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(fetchGetMpEventsFailure(errorMsg))
    })
}


