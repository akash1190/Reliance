import { useState, useEffect } from "react";
import CircularProgress from '@mui/material/CircularProgress';

export function VideoLoader({ src, onClick, srcSet, className, width, loading, iframe,
    height, allow }) {
    const [isLoading, setIsLoading] = useState(true);
    const [videoSrc, setVideoSrc] = useState(null);

    useEffect(() => {
        const video = document.createElement('video');
        video.src = src;
        video.preload = 'metadata';
        video.addEventListener('loadedmetadata', () => {
            setIsLoading(false);
            setVideoSrc(src);
        });
    }, [src]);

    return (
        <div>
            {isLoading ? <div style={{ textAlignLast: "center" }} >  <CircularProgress color="inherit" /></div> :
                (iframe ?
                    <iframe
                        width={width && width}
                        height={height && height}
                        src={src && src}
                        frameBorder="0"
                        allow={allow && allow}
                        allowFullScreen
                    ></iframe>

                    : <video src={videoSrc && videoSrc} alt="" onClick={onClick && onClick}
                        srcSet={srcSet && srcSet} className={className && className} width={width && width}
                        loading={loading && loading} />)}
        </div>
    );
}