import axios from "axios"
import Constant from "../../utils/constant"
import { TEXT_FAILURE, TEXT_REQUEST, TEXT_SUCCESS } from "./types"

export const getTextRequest = () => {
    return {
        type: TEXT_REQUEST
    }
}
export const getTextSuccess = value => {
    return {
        type: TEXT_SUCCESS,
        payload: value
    }
}
export const getTextFailure = error => {
    return {
        type: TEXT_FAILURE,
        payload: error
    }
}


const getTextData = (query) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(getTextRequest)
    await axios.get(Constant.BASE_URL + `/api/texttemplate/getall/${query}`, {
        headers: {
            Authorization: `Bearer ${tkn}`,
        },
    })
        .then(response => {
            const result = response.data.textdata
            // const result = mpList
            dispatch(getTextSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(getTextFailure(errorMsg))
        })
}

const updateTextData = (formData) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    await axios.post(Constant.BASE_URL + `/api/user/update-mpdata/${formData.id}`, formData, {
        headers: {
            Authorization: `Bearer ${tkn}`,
        },
    });
}


export { getTextData, updateTextData }

