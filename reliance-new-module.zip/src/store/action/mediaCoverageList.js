import axios from "axios"
import Constant from "../../utils/constant"
// import { mpList } from "../../Constants/mpList"
import {
    FETCH_MEDIA_COVERAGE_LIST_REQUEST, FETCH_MEDIA_COVERAGE_LIST_SUCCESS, FETCH_MEDIA_COVERAGE_LIST_FAILURE,
    FETCH_MEDIA_COVERAGE_TYPES_LIST_REQUEST, FETCH_MEDIA_COVERAGE_TYPES_LIST_SUCCESS, FETCH_MEDIA_COVERAGE_TYPES_LIST_FAILURE,
    FETCH_MEDIA_COVERAGE_LIST_BY_MP_ID_REQUEST, FETCH_MEDIA_COVERAGE_LIST_BY_MP_ID_SUCCESS, FETCH_MEDIA_COVERAGE_LIST_BY_MP_ID_FAILURE
} from "./types"

export const fetchMediaCoverageListRequest = () => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_REQUEST
    }
}
export const fetchMediaCoverageListSuccess = (data) => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_SUCCESS,
        payload: data
    }
}
export const fetchMediaCoverageListFailure = error => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_FAILURE,
        payload: error
    }
}

export const fetchMediaCoverageListByMpIdRequest = () => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_BY_MP_ID_REQUEST
    }
}
export const fetchMediaCoverageListByMpIdSuccess = (data) => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_BY_MP_ID_SUCCESS,
        payload: data
    }
}
export const fetchMediaCoverageListByMpIdFailure = error => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_BY_MP_ID_FAILURE,
        payload: error
    }
}

export const fetchMediaCoverageTypesListRequest = () => {
    return {
        type: FETCH_MEDIA_COVERAGE_TYPES_LIST_REQUEST
    }
}
export const fetchMediaCoverageTypesListSuccess = (data) => {
    return {
        type: FETCH_MEDIA_COVERAGE_TYPES_LIST_SUCCESS,
        payload: data
    }
}
export const fetchMediaCoverageTypesListFailure = error => {
    return {
        type: FETCH_MEDIA_COVERAGE_TYPES_LIST_FAILURE,
        payload: error
    }
}



export const getMediaCoverageList = (id) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchMediaCoverageListRequest)
    await axios.get(Constant.BASE_URL + `/api/opeds/getallopeds/${id ? id : 0}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data;
            // const result = mpList
            dispatch(fetchMediaCoverageListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchMediaCoverageListFailure(errorMsg))
        })
}

export const getMediaCoverageListByMpID = (mpId) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchMediaCoverageListByMpIdRequest)
    await axios.get(Constant.BASE_URL + `/api/getOpEdDataByMpId/${mpId}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data;
            // const result = mpList
            dispatch(fetchMediaCoverageListByMpIdSuccess(result));
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchMediaCoverageListByMpIdFailure(errorMsg));
        })
}

export const getMediaCoverageTypesList = () => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");
    dispatch(fetchMediaCoverageTypesListRequest)
    await axios.get(Constant.BASE_URL + '/api/opeds/types',{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchMediaCoverageTypesListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchMediaCoverageTypesListFailure(errorMsg))
        })
}


