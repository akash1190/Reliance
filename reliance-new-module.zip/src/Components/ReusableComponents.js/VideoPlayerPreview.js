import { useRef } from 'react';
import play from "../../asserts/images/Play.svg"
import pause from "../../asserts/images/Pause.png"
import { useState } from 'react';
function VideoPlayerPreview({ src, controls, className, width, height, position, top, left, transform, background, onClick }) {
    const videoRef = useRef(null);
    const playWidth = `${(width / 5)}px`
    const [playbtn, setPlay] = useState(true)
    function togglePlay(e) {
        const video = videoRef.current;
        e.stopPropagation();
        e.preventDefault();
        if (video.paused) {
            video.play();
            setPlay(false)
        } else {
            video.pause();
            setPlay(true)
        }
    }

    return (
        <div style={{ position: "relative" }}>
            <video ref={videoRef} className={className && className}
                width={width && width} height={height && height} onClick={onClick && onClick}
                style={{ position, top, left, transform, background }}
                src={src && src}
            >
            </video>

            <button onClick={(e) => togglePlay(e)}
                style={{ border: "0", padding: "0", borderRadius: "100%", top: "0%", left: "-60%", position: "absolute", width: width ? playWidth : "50px", background: "none" }}>
                <img style={{ width: "inherit" }} src={playbtn ? play : pause} />
            </button>

        </div>
    );
}


export default VideoPlayerPreview