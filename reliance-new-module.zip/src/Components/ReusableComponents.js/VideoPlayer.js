import { useRef } from 'react';
import play from "../../asserts/images/Play.svg"
import pause from "../../asserts/images/Pause.png"
import { useState } from 'react';
function VideoPlayer({ src, controls, className, width, height, position, top, left, transform, background, onClick }) {
  const videoRef = useRef(null);
  const playWidth = `${(width / 5)}px`
  const [playbtn, setPlay] = useState(true)
  function togglePlay() {
    const video = videoRef.current;

    if (video.paused) {
      video.play();
      setPlay(false)
    } else {
      video.pause();
      setPlay(true)
    }
  }
  return (
    <div style={{ position: "relative" }}>
      <video ref={videoRef} className={className && className}
        width={width && width} height={height && height} onClick={onClick && onClick}
        style={{ position, top, left, transform, background }}
      >
        <source src={src} type="video/mp4" />
      </video>

      <button onClick={togglePlay} style={{ border: "0", padding: "0", borderRadius: "100%", top: "38%", left: width ? `${width / 2.5}px` : "20%", position: "absolute", width: width ? playWidth : "50px", background: "none" }}>
        <img style={{ width: "inherit" }} src={playbtn ? play : pause} />
      </button>
    </div>
  );
}

export default VideoPlayer