import React, { useEffect, useRef, useState } from "react";
// import 'bootstrap/dist/css/bootstrap.min.css';
import ProfileCard from "../ReusableComponents.js/ProfileCard";
import SideMenu from "../SideMenu/SideMenu";
import TableHighlights from "../Highlights/TableHighlights";
import ThreeCards from "./ThreeCards";
import { Grid, MenuItem, Select, Tabs } from "@mui/material";
import Search from "./Search";
import DateFilter from "../ReusableComponents.js/DateFilter";

import StickyHeadTable from "./MpTable";
import { useDispatch, useSelector } from "react-redux";
import { getMpList } from "../../store/action/mpList";
import { getMpProfile } from "../../store/action/individualMP";
import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import Constant from "../../utils/constant";
import { getIds } from "../ReusableComponents.js/getIds";
const MpHome = () => {
  const [cardClick, setCardClick] = useState("sevaScore");
  const [tabactive, settabactive] = useState(1);
  const [flag, setFlag] = useState(101);
  //redux get store data
  const mpList = useSelector((state) => state?.mpList?.data);
  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  const CryptoJS = require("crypto-js");
  const loggedInId = getIds();
  const dispatch = useDispatch();

  useEffect(() => {
    //call api to update store
    dispatch(getMpProfile(loggedInId));
    dispatch(getMpList(flag));
  }, [flag]);

  const containerRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const [scrollRight, setScrollRight] = useState(true);
  const handleMouseDown = (event) => {
    setIsDragging(true);
    setStartX(event.pageX - containerRef.current.offsetLeft);
    setScrollLeft(containerRef.current.scrollLeft);
  };

  useEffect(() => {
    setScrollLeft(containerRef.current.scrollLeft);
    const container = containerRef.current;
    if (
      Math.floor(container.scrollLeft) + container.clientWidth == container.scrollWidth ||
      Math.floor(container.scrollLeft) + container.clientWidth + 1 == container.scrollWidth ||
      Math.ceil(container.scrollLeft) + container.clientWidth == container.scrollWidth
    ) {
      setScrollRight(false);
    }
    else {
      setScrollRight(true);
    }
  }, [containerRef?.current?.scrollLeft])

  const handleMouseMove = (event) => {
    if (!isDragging) return;
    event.preventDefault();
    const x = event.pageX - containerRef.current.offsetLeft;
    const distance = (x - startX) * 2;
    containerRef.current.scrollLeft = scrollLeft - distance;
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const scrollLeftTab = () => {
    const container = containerRef.current;
    if (
      Math.floor(container.scrollLeft) + container.clientWidth == container.scrollWidth ||
      Math.floor(container.scrollLeft) + container.clientWidth + 1 == container.scrollWidth ||
      Math.ceil(container.scrollLeft) + container.clientWidth == container.scrollWidth
    ) {
      setScrollRight(false);
    }
    else {
      setScrollRight(true);
    }
    if (container.scrollLeft > 0) {
      containerRef.current.scrollLeft = containerRef?.current?.scrollLeft - container.offsetWidth / 2
      // container.scrollTo({
      //   left: container.scrollLeft - container.offsetWidth / 2,
      //   behavior: "smooth",
      // });
    }
  };

  const scrollRightTab = () => {
    const container = containerRef.current;
    if (
      Math.floor(container.scrollLeft) + container.clientWidth == container.scrollWidth ||
      Math.floor(container.scrollLeft) + container.clientWidth + 1 == container.scrollWidth ||
      Math.ceil(container.scrollLeft) + container.clientWidth == container.scrollWidth
    ) {
      setScrollRight(false);
    }
    else {
      setScrollRight(true);
    }
    if (container.scrollLeft < container.scrollWidth - container.offsetWidth) {
      container.scrollTo({
        left: container.scrollLeft + container.offsetWidth / 2,
        behavior: "smooth",
      });
    }
  };
  return (
    <>
      {/* API loading time mpList will be empty */}
        <div className="page-wrapper d-flex">
          <SideMenu
            active="Leader"
            profile={mpList && mpList[0]}
            profileData={mpProfileData}
          />
          <div
            className="main-wrapper center-width"
            style={{ paddingLeft: "70px" }}
          >
            <div>
              <Grid container spacing={2}>
                <Grid md={8} lg={8} xl={8}>
                  <div>
                    <div className="d-flex justify-content-between align-items-center">
                      <h1 className="page-title mb-0">MP Leaderboard</h1>
                      <Search />
                    </div>
                    {/* <DateFilter /> */}
                  </div>
                  <div
                    className="filter-btns  no-gutters pt-3"
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginBottom: "20px",
                    }}
                  >
                    {/* {props.user!=="Admin" && */}
                    <ChevronLeft
                      sx={{ color: scrollLeft === 0 ? "grey" : "black", cursor: scrollLeft !== 0 && "pointer" }}
                      onClick={scrollLeftTab}
                    />
                    <Tabs
                      variant="scrollable"
                      scrollButtons={false}
                      aria-label="scrollable auto tabs example"
                      sx={{ width: "94%" }}
                    >
                      <div
                        aria-label="scrollable auto tabs example"
                        ref={containerRef}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          overflowX: "hidden",
                        }}
                        onMouseDown={handleMouseDown}
                        onMouseMove={handleMouseMove}
                        onMouseUp={handleMouseUp}
                        onMouseLeave={handleMouseUp}
                      >
                        <button
                          type="button"
                          className={
                            tabactive === 1
                              ? "btn btn-primary primary-btn mr-3 mt-1 mb-1"
                              : "btn btn-primary normal-btn mr-3 mt-1 mb-1"
                          }
                          onClick={() => {
                            settabactive(1);
                            setCardClick("sevaScore");
                            setFlag(101);
                            scrollLeftTab()
                          }}
                        >
                          MP Seva Score
                        </button>
                        <button
                          type="button"
                          className={
                            tabactive === 2
                              ? "btn btn-primary primary-btn mr-3 mt-1 mb-1"
                              : "btn btn-primary normal-btn mr-3 mt-1 mb-1"
                          }
                          onClick={() => {
                            settabactive(2);
                            setCardClick("initiatives");
                            setFlag(102);
                            scrollLeftTab()
                          }}
                        >
                          Initiatives
                        </button>
                        <button
                          type="button"
                          className={
                            tabactive === 3
                              ? "btn btn-primary primary-btn mr-3 mt-1 mb-1"
                              : "btn btn-primary normal-btn mr-3 mt-1 mb-1"
                          }
                          onClick={() => {
                            settabactive(3);
                            setCardClick("memberAdded");
                            setFlag(103);
                            scrollLeftTab()
                          }}
                        >
                          Members Added
                        </button>
                        <button
                          type="button"
                          className={
                            tabactive === 4
                              ? "btn btn-primary primary-btn mr-3 mt-1 mb-1"
                              : "btn btn-primary normal-btn mr-3 mt-1 mb-1"
                          }
                          onClick={() => {
                            settabactive(4);
                            setCardClick("followers");
                            setFlag(104);
                            scrollLeftTab()
                          }}
                        >
                          Followers
                        </button>
                        <button
                          type="button"
                          className={
                            tabactive === 5
                              ? "btn btn-primary primary-btn mr-3 mt-1 mb-1"
                              : "btn btn-primary normal-btn mr-3 mt-1 mb-1"
                          }
                          onClick={() => {
                            settabactive(5);
                            setCardClick("twitterPerformance");
                            setFlag(105);
                            scrollRightTab()
                          }}
                        >
                          Twitter Performance
                        </button>
                        <button
                          type="button"
                          className={
                            tabactive === 6
                              ? "btn btn-primary primary-btn mr-3 mt-1 mb-1"
                              : "btn btn-primary normal-btn mr-3 mt-1 mb-1"
                          }
                          onClick={() => {
                            settabactive(6);
                            setCardClick("mediaCoverage");
                            setFlag(106);
                            scrollRightTab()
                          }}
                        >
                          Op-ed's & Media Coverage
                        </button>
                        <button
                          type="button"
                          className={
                            tabactive === 7
                              ? "btn btn-primary primary-btn mr-3 mt-1 mb-1"
                              : "btn btn-primary normal-btn mr-3 mt-1 mb-1"
                          }
                          onClick={() => {
                            settabactive(7);
                            setCardClick("donation");
                            setFlag(107);
                            scrollRightTab()
                          }}
                        >
                          Donations
                        </button>
                      </div>
                    </Tabs>
                    <ChevronRight
                      sx={{ color: !scrollRight ? "grey" : "black", cursor: scrollRight && "pointer" }}
                      onClick={scrollRightTab}
                    />
                  </div>
                  <hr className="mt-2 mb-4" />
                  <ThreeCards cardClick={cardClick} />
                  <div className="mt-5 learders-list">
                    {/* <MpTables cardClick={cardClick} mpList={mpList} /> */}
                    <StickyHeadTable
                      cardClick={cardClick}
                      flag={flag}
                      count={1}
                      mpProfileData={mpProfileData}
                    />
                  </div>
                </Grid>
                <Grid
                  item
                  xs={12}
                  md={4}
                  lg={4}
                  xl={4}
                  sx={{ backgroundColor: "#F5F6FA" }}
                >
                  <div className="rtcar">
                    <div className="right-card">
                      <div className="highlights-title">
                        <h1 className="fs-30">Highlights</h1>
                        <p className="mb-0">All India Seva Initiatives</p>
                      </div>

                    <TableHighlights mpList={mpList && mpList[0]} />
                  </div>
                  <div>
                    <ProfileCard profile={mpProfileData ? mpProfileData : {}} />
                  </div>
                </div>
              </Grid>
            </Grid>
          </div>
        </div>
      </div>
    </>
  );
};

export default MpHome;
