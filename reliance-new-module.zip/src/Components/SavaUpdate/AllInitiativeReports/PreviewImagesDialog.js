import React from "react";
import Dialog from "@mui/material/Dialog";
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import playicon from "../../../asserts/images/Play.svg"
import { useState } from "react";
import { IconButton } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import "./Preview.css";
const PreviewImagesDialog = ({ openPreviewImages, handleClosePreviewImages, files, previewImageIndex }) => {
    const handlePreviewThumbs = (file) => {
        if (file.type === "image") {
            return <img src={typeof file === 'string' ? file : file.url} alt="Preview" className="form-img__img-preview-1" />;
        }
        if (file.type === "video") {
            return (
                <video controls className="form-img__img-preview-1">
                    <source src={typeof file === 'string' ? file : file.url} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
            );
        }
        const images = ["jpg", "gif", "png", "svg", "jfif"]
        const videos = ["mp4", "3gp", "ogg"]
        const url = new URL(file)
        const extension = url.search.split(".")[1]
        if (images.includes(extension)) {
            return <img src={file} alt="Preview" className="form-img__img-preview" />;
        }
        if (videos.includes(extension)) {
            return (
                <div>
                    {!isHidden && (
                        <img src={playicon} className="play-buttonthumb" onClick={handleHideImage} />
                    )}
                    <video className="videothumb" >
                        <source src={typeof file === 'string' ? file : file.url} type="video/mp4" />
                        Your browser does not support the video tag.
                    </video>
                </div>

            );
        }
    };

    const [isHidden, setIsHidden] = useState(false);
    function handleHideImage() {
        setIsHidden(true);
    }
    const handlePreview = (file) => {
        // const images = ["jpg", "gif", "png", "svg"]
        // const videos = ["mp4", "3gp", "ogg"]
        // const url = new URL(file)
        // const extension = url.pathname.split(".")[1]
        // if (images.includes(extension)) {
        //     return <img src={file} alt="Preview" />;
        // }
        // else if (videos.includes(extension)) {
        //     return (
        //         <video controls>
        //             <source src={file} type="video/mp4" />
        //             {/* Your browser does not support the video tag. */}
        //         </video>
        //     );
        // }
        if (file.type === "image") {
            return <img src={typeof file === 'string' ? file : file.url} alt="Preview" className="" />;
        }
        if (file.type === "video") {
            return (
                <video controls className="">
                    <source src={typeof file === 'string' ? file : file.url} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
            );
        }
        const images = ["jpg", "gif", "png", "svg", "jfif"]
        const videos = ["mp4", "3gp", "ogg"]
        const url = new URL(file)
        const extension = url.search.split(".")[1]
        if (images.includes(extension)) {
            return <img src={file} alt="Preview" className="form-img__img-preview" style={{ height: "100%" }} />;
        }
        if (videos.includes(extension)) {
            return (
                <>
                    <div className="postabsvideo">
                        {!isHidden && (
                            <img src={playicon} className="play-button" onClick={handleHideImage} />
                        )}
                        <video controls onClick={handleHideImage}>
                            <source src={typeof file === 'string' ? file : file.url} type="video/mp4" style={{ height: "100%" }} />
                            Your browser does not support the video tag.
                        </video>
                    </div>
                </>
            );
        }
    };

    const onChangeEvent = (index) => {
       var element = document.getElementsByClassName("thumb")[index]
       element.scrollIntoView({behavior:"smooth"})
    }


    return (
        <>
            <Dialog open={openPreviewImages} onClose={handleClosePreviewImages}
                PaperProps={{
                    style: {
                        backgroundColor: "#000000bd",
                        mt: "-5px",

                    },
                }}

            >
                {/* <button className="close-button" onClick={handleClosePreviewImages}>
                <CloseIcon />
            </button> */}
                <IconButton
                    aria-label="close"
                    onClick={handleClosePreviewImages}
                    sx={{
                        position: "absolute",
                        right: 8,
                        top: 20,
                        color: (theme) => theme.palette.grey[500],
                        border: "1px solid #9e9e9e",
                        borderRadius: "50%",
                        padding: "2px",
                        cursor: "pointer",
                        marginBottom: 4,
                        zIndex: 1000
                    }}
                >
                    <CloseIcon />
                </IconButton>
                <Carousel className="dialogopac1" selectedItem={previewImageIndex || 0} 
                onChange={onChangeEvent}
                
                renderThumbs={() =>
                    files && files?.map((file, index) =>
                        <div key={index} >{handlePreviewThumbs(file)}</div>
                    )
                }
                
                >
                    {files && files?.map((file, index) =>

                        <div style={{ border: "4px solid #fff", height: "450px" }} key={index}  >{handlePreview(file)}</div>
                    )}
                </Carousel>
            </Dialog >
        </>
    );
};

export default PreviewImagesDialog;