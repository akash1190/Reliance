import { CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllHighlights } from "../../store/action/globalHighlights.js";
import { useLoading } from "../../utils/LoadingContext.js";
import { useNotificationContext } from "../../utils/NotificationContext.js";
import SideMenu from "../SideMenu/SideMenu.js";
import "./Highlights.css";
const TableHighlights = (props) => {
  const { setLoading } = useLoading();
  const { showNotication } = useNotificationContext();
  const dispatch = useDispatch();
  const { data, loading } = useSelector((state) => state?.highlights);
  const [dataLoading, setDataLoading] = useState(loading);
  function createData(heading, value) {
    return { heading, value };
  }

  const keys = {
    InitiativesUndertaken: "Initiatives Undertaken",
    EventsConducted: "Events Conducted",
    memberadded: "Members Added",
    twtterfollowers: "Twitter Followers",
    twittermention: "Twitter Mentions",
    twttertweet: "Twitter Retweets",
    DevelopmentProjects: "Development Projects",
    DonationReceived: "Donation Received",
    MediaCoverage: "Media Coverage",
    Op_Eds: "Op-ed's",
    BookPublished: "Books Published",
  };

  const fetchData = async () => {
    try {
      const response =
        props.mpId > 0
          ? await dispatch(getAllHighlights(props.mpId))
          : await dispatch(getAllHighlights());
      if (response.status !== 200 || response.status !== 201) {
        showNotication("Error", response.data.message, "error");
      }
    } catch (error) {
      showNotication("Error", error, "error");
    } finally {
      // setLoading(false);
      setDataLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  const rows = Object.keys(data ? data : [])?.map((val) => {
    return createData(val, data[val]);
  });

  const abbreviateNumber = (value) => {
    var newValue = value;
    if (value >= 1000) {
      var suffixes = ["", "K", "M", "B", "T"];
      var suffixNum = Math.floor(("" + value).length / 3);
      var shortValue = "";
      for (var precision = 2; precision >= 1; precision--) {
        shortValue = parseFloat(
          (suffixNum != 0
            ? value / Math.pow(1000, suffixNum)
            : value
          ).toPrecision(precision)
        );
        var dotLessShortValue = (shortValue + "").replace(
          /[^a-zA-Z 0-9]+/g,
          ""
        );
        if (dotLessShortValue.length <= 2) {
          break;
        }
      }
      if (shortValue % 1 != 0) shortValue = shortValue.toFixed(1);
      newValue = shortValue + suffixes[suffixNum];
    }
    return newValue;
  };

  return (
    <div className="mt-3" style={{ textAlign: "center" }}>
      {dataLoading ? (
        <CircularProgress />
      ) : (
        rows &&
        rows?.map((row) => {
          return (
            <div className="d-flex justify-content-between border-bottom py-3">
              <span style={{ fontWeight: "600",fontSize:"18px",paddingTop:"5px",paddingBottom:"3px",paddingLeft:"5px",paddingRight:"5px" }}>{keys[row.heading]}</span>
              <span className="seva-nos" style={{ fontWeight: "bold",fontSize:"20px",paddingTop:"5px",paddingBottom:"3px",paddingLeft:"5px",paddingRight:"5px" }}>
                {row.heading === "DonationReceived"
                  ? "₹ " + abbreviateNumber(row?.value?.toLocaleString("en-IN"))
                  : abbreviateNumber(row?.value?.toLocaleString("en-IN"))}
              </span>
            </div>
          );
        })
      )}
    </div>
  );
};

export default TableHighlights;
