import './App.css';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import MpHome from './Components/MpHome/MpHome';
import SevaUpdates from './Components/SavaUpdate/SevaUpdates';
import YourInitiative from './Components/YourIntiative/YourInitiative';
import AdminHome from './Components/AdminHome/AdminHome';
import Login from './Components/Login/Login.js';
import MpSavaUpdate from './Components/SavaUpdate/MpSevaUpdate/MpSavaUpdate';
import AllInitiativeReports from './Components/SavaUpdate/AllInitiativeReports/AllInitiativeReports';
import { useEffect, useState } from 'react';
import SevaInitiatives from './Components/SevaInitiatives/SevaInitiatives';
import CreateInitiatives from './Components/SevaInitiatives/CreateInitiatives/CreateInitiatives';
import MySevaUpdate from './Components/SavaUpdate/MySevaUpdates/MySevaUpdates';
import ViewAllScreen from './Components/SavaUpdate/ViewAllScreen';
import ViewAllOngoingInitiatives from './Components/SavaUpdate/ViewAllOngoingInitiatives';
import { useDispatch } from 'react-redux';
import Constant from './utils/constant';
function App() {
  const CryptoJS = require("crypto-js");
  const [userId, setUserId] = useState(localStorage.getItem("userId") && CryptoJS.AES.decrypt(localStorage.getItem("userId"),Constant.roleKey).toString(CryptoJS.enc.Utf8))
  
  const [paramId,setParamId] = useState()
  // let userid=localStorage.getItem("userId")
  // let userid = 1
  // 1- MP, 2- Admin, 3- Citizen
  
 const dispatch=useDispatch()
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setParamId(params.get('userid'))
    
  },[])

  if (!userId)
    return (<Router forceRefresh={true}>
      <Routes><Route exact path="*" element={<Login paramId={paramId}  />}></Route></Routes></Router>
    )

  return (
    <>
      <div className="App">
        <Router>
          <Routes>
            <Route exact path='/Login' element={<Login />} />
            <Route exact path='/' element={userId == 1 ? <MpHome /> : <AdminHome />} />
            {userId == 1 &&
              <>
                <Route exact path='/MpHome' element={<MpHome />} />
                <Route exact path='/Initiatives' element={<YourInitiative />} />
                <Route exact path='/SevaUpdates' element={<SevaUpdates />} />
                <Route exact path='/SevaUpdates/viewAllSevaEvents' element={<ViewAllScreen />} />
                <Route exact path='/SevaUpdates/viewAllOngoingInitiatives' element={<ViewAllOngoingInitiatives />} />
                <Route exact path='/MySevaUpdates' element={<MySevaUpdate />} />
              </>}
            {userId == 2 &&
              <>
                <Route exact path='/AdminHome' element={<AdminHome />} />
                <Route exact path='/SevaInitiatives' element={<SevaInitiatives />} />
                <Route exact path='/SevaInitiatives/createInitiative' element={<CreateInitiatives />} />
                <Route exact path='/SevaInitiatives/editInitiative/:id' element={<CreateInitiatives />} />
                <Route exact path='/SevaUpdates' element={<SevaUpdates user={"Admin"} />} />
                <Route exact path='/SevaUpdates/viewAllSevaEvents' element={<ViewAllScreen user={"Admin"} />} />
                <Route exact path='/SevaUpdates/viewAllOngoingInitiatives' element={<ViewAllOngoingInitiatives user={"Admin"} />} />
                <Route exact path='/Mp_SevaUpdate' element={<MpSavaUpdate user={"Admin"} />} />
              </>}
            {userId == 3 &&
              <>
                <Route exact path='/SevaUpdates/viewAllSevaEvents' element={<ViewAllScreen user={"Leader"} />} />
                <Route exact path='/SevaUpdates/viewAllOngoingInitiatives' element={<ViewAllOngoingInitiatives user={"Leader"} />} />
                <Route exact path='/AdminHome' element={<AdminHome readonly={true} />} />
                <Route exact path='/SevaUpdates' element={<SevaUpdates readonly={true} user={"Leader"} />} />
                <Route exact path='/SevaUpdates' element={<SevaUpdates user={"Leader"} />} />
                <Route exact path='/SevaUpdates/viewAllSevaEvents' element={<ViewAllScreen user={"Leader"} />} />
                <Route exact path='/Mp_SevaUpdate' element={<MpSavaUpdate readonly={true} user={"Leader"} />} />

              </>}
            <Route exact path='/Mp_SevaUpdate' element={<MpSavaUpdate />} />
            <Route exact path='/SevaUpdates/allInitiativeReports' element={<AllInitiativeReports />} />
            <Route
              path="*"
              element={<Navigate to="" replace />}
            />
          </Routes>
        </Router>
      </div>
    </>
  );
}



export default App;
