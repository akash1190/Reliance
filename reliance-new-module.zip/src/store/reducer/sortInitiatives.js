
import { SORT_FAILURE,SORT_REQUEST,SORT_SUCCESS}  from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const sortInitiative = (state = initialState, action) => {
    switch (action.type) {
        case SORT_REQUEST:
            return {
                state,
            }
        case SORT_SUCCESS:
            return {
                data: action.payload
            }
        case SORT_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}