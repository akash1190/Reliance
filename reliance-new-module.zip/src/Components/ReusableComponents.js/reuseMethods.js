  import React from 'react'
  
  export const validateNotEmpty = (value, fieldName) => {
    if (value.trim() === '') {
      return `Please enter ${fieldName}`;
    }
    return true;
  };
