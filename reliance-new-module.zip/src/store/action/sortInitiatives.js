import axios from "axios"
import Constant from "../../utils/constant"
import { SORT_FAILURE,SORT_REQUEST,SORT_SUCCESS} from "./types"

export const sortInitiativeRequest = () => {
    return {
        type: SORT_REQUEST,
        payload:[]
    }
}
export const sortInitiativeSuccess = value => {
    return {
        type: SORT_SUCCESS,
        payload: value
    }
}
export const sortInitiativeFailure = error => {
    return {
        type: SORT_FAILURE,
        payload: error
    }
}

export const allInitiative = (query) => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");

    dispatch(sortInitiativeRequest)
    await axios.get(Constant.BASE_URL + `/api/initiative/getbymp/${query}`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
    .then(response => {
        const result = response.data.initiative
        dispatch(sortInitiativeSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(sortInitiativeFailure(errorMsg))
    })
}


