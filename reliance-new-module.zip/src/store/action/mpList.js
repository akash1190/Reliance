import axios from "axios"
import Constant from "../../utils/constant"
import { FETCH_MPLIST_FAILURE, FETCH_MPLIST_REQUEST, FETCH_MPLIST_SUCCESS, UPDATE_MPLIST_SUCCESS } from "./types"

export const fetchMpListRequest = () => {
    return {
        type: FETCH_MPLIST_REQUEST
    }
}
export const fetchMpListSuccess = value => {
    return {
        type: FETCH_MPLIST_SUCCESS,
        payload: value
    }
}
export const fetchMpListFailure = error => {
    return {
        type: FETCH_MPLIST_FAILURE,
        payload: error
    }
}
export const updateMpListSuccess = value => {
    return {
        type: UPDATE_MPLIST_SUCCESS,
        payload: value
    }
}


export const getMpList = (flag, page) => async (dispatch) => {
    const tkn =
        localStorage.getItem("tokenDetails");
    dispatch(fetchMpListRequest)
    page && page !== 1 ?
        await axios.get(Constant.BASE_URL + `/api/user/getallmpdata/${flag}?page=${page}`, {
            headers: {
                Authorization: `Bearer ${tkn}`,
            },
        })
            .then(response => {

                const result = response.data.result
                // const result = mpList
                dispatch(updateMpListSuccess(result))
            })
            .catch(error => {
                const errorMsg = error.message
                dispatch(fetchMpListFailure(errorMsg))
            })
        :
        await axios.get(Constant.BASE_URL + `/api/user/getallmpdata/${flag}?page=1`, {
            headers: {
                Authorization: `Bearer ${tkn}`,
            },
        })
            .then(response => {

                const result = response.data.result
                // const result = mpList
                dispatch(fetchMpListSuccess(result))
            })
            .catch(error => {
                const errorMsg = error.message
                dispatch(fetchMpListFailure(errorMsg))
            })
}


