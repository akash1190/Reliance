import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import { MpColumnFilter, MpColumnHeaders } from "./MpTableData";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { useDispatch, useSelector } from "react-redux";
import { getMpList } from "../../store/action/mpList";
import { useNavigate } from "react-router";
import { Hidden } from "@mui/material";
import { useLoading } from "../../utils/LoadingContext";
import { useNotificationContext } from "../../utils/NotificationContext";
import "./MpTables.css";
import Constant from "../../utils/constant";

export default function StickyHeadTable({
  cardClick,
  flag,
  count,
  user,
  mpProfileData,
}) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [page, setPage] = React.useState(count);
  const { setLoading } = useLoading();
  const { showNotification } = useNotificationContext();
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  let keys = [
    "id",
    "icon",
    "user_name",
    "imageSrc",
    "position",
    "constituency_name",
    "sevaScore",
    "initiatives",
    "eventOrganized",
    "citizen",
    "memberAdded",
    "followers",
    "twitterPerformance",
    "opEds",
    "mediaCoverage",
    "donation",
    "dateIssued",
  ];
  const mpList = useSelector((state) => state?.mpList?.data);
  const scrollRef = React.useRef();
  let columnsAll = keys;
  let column = [];

  const fetchMpData = async () => {
    try {
      setLoading(true);
      await dispatch(getMpList(flag, page));
    } catch (error) {
      showNotification("Error", error);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchMpData();
  }, [page]);
  React.useEffect(() => {
    scrollRef.current.scrollTop = 0;
    setPage(1);
  }, [flag]);
  let filteredColumns = MpColumnFilter.filter(
    (s) => s.screenNumber === cardClick
  )[0]?.columns;
  column = columnsAll
    .filter((s) => filteredColumns?.includes(MpColumnHeaders[s]))
    .map((x) => ({ id: x, label: x == "id" ? "Rank" : MpColumnHeaders[x] }));

  const onScroll = () => {
    if (scrollRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;

      if (
        Math.floor(scrollTop) + clientHeight == scrollHeight ||
        Math.floor(scrollTop) + clientHeight + 1 == scrollHeight ||
        Math.ceil(scrollTop) + clientHeight == scrollHeight
      ) {
        setPage(page + 1);
      }
    }
  };

  return (
    <TableContainer>
      <Table style={{ position: "sticky", top: 0, tableLayout: "fixed" }}>
        <TableHead>
          <TableRow>
            {column.map((column) => (
              <TableCell
                key={column.id}
                id={"header" + column.id}
                align={column.align}
                style={{
                  // textTransform: "capitalize",
                  fontWeight: "bold",
                  // textAlign: "center",
                  background: "#E3F5FF",
                  borderBottom: "2px solid #356F92",
                  fontFamily: "HK Grotesk",
                  fontSize: "16px",
                }}
              >
                {column.label}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
      </Table>

      <div
        style={{ height: "350px", overflow: "auto" }}
        ref={scrollRef}
        onScroll={() => onScroll()}
        className="customscroll"
      >
        <Table
          style={{ tableLayout: "fixed", backgroundColor: "#fff" }}
          className="cursorshow"
        >
          <TableBody>
            {/* {tdData()} */}

            <React.Fragment>
              {mpList &&
                mpList.map(
                  (item, index) =>
                    index > 2 && (
                      <TableRow
                        hover
                        role="checkbox"
                        className={"clickable"}
                        tabIndex={-1}
                        key={index + 1}
                        onClick={(e) => {
                          if (!window.getSelection().toString()) {
                            navigate("/Mp_SevaUpdate", {
                              state: {
                                MpName: item.user_name,
                                user: user,
                                mpId: item.id,
                                mpClick: true,
                                mpData: item && item,
                              },
                            });
                          }
                        }}
                        style={{
                          backgroundColor:
                            item?.id === mpProfileData?.id &&
                            "rgb(227, 245, 255)",
                        }}
                      >
                        {column.map((column, key) =>
                          key == 2 ? (
                            <TableCell id={column.id}>
                              <div className="table-name-container">
                                <div>
                                  <p
                                    style={{
                                      color: "#356F92",
                                      fontWeight: "bold",
                                      fontFamily: "HK Grotesk",
                                      fontSize: "16px",
                                    }}
                                  >
                                    {item.user_name}
                                  </p>
                                  <p
                                    style={{
                                      fontFamily: "HK Grotesk",
                                      fontSize: "14px",
                                      marginTop: "-15px",
                                      color: "#797979",
                                    }}
                                  >
                                    {item.party}
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                          ) : (
                            <TableCell
                              key={index + 1}
                              id={column.id}
                              align={column.align}
                              style={{
                                // minWidth: column.minWidth,
                                color: key === 0 ? "#356F92" : "",
                                fontWeight: key === 0 ? "bold" : "",
                                fontFamily: "HK Grotesk",
                                fontSize: "14px",
                              }}
                            >
                              {key == 0 ? (
                                item.dense_rank
                              ) : key == 1 ? (
                                <div>
                                  {item.user_avatar ? (
                                    <img
                                      src={item.user_avatar}
                                      className="img-circle leader-circle-img mr-1"
                                      width="50"
                                      height="50"
                                    />
                                  ) : (
                                    <div>
                                      <AccountCircleIcon
                                        sx={{
                                          fontSize: "xx-large",
                                          width: "50px",
                                          height: "50px",
                                        }}
                                      />
                                    </div>
                                  )}
                                </div>
                              ) : column.id == "donation" ? (
                                "₹ " + item[column.id]?.toLocaleString("en-IN")
                              ) : (
                                item[column.id]
                              )}
                            </TableCell>
                          )
                        )}
                      </TableRow>
                    )
                )}
            </React.Fragment>
          </TableBody>
        </Table>
      </div>
    </TableContainer>
  );
}
