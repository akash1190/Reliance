import React, { useState, useEffect } from "react";
import DialogTitle from "@mui/material/DialogTitle";
import Dialog from "@mui/material/Dialog";
import CloseIcon from "@mui/icons-material/Close";
import "./CreateInitiative.css";
import {
  FormControl,
  IconButton,
  InputLabel,
  Select,
  Grid,
  MenuItem,
  Button,
  Checkbox,
  ListItemText,
  OutlinedInput,
  DialogContent,
  FormLabel,
  InputAdornment,
  TextField,
  InputBase,
  ListItem,
  ListItemAvatar,
  Avatar,
  ListSubheader,
  List,
  FormHelperText,
  Typography,
  Divider,
  Chip
} from "@mui/material";
import { Box } from "@mui/system";
import { useNavigate } from "react-router-dom";
import one from "../../../asserts/images/1.jpg";
import two from "../../../asserts/images/4.jpg";
import three from "../../../asserts/images/2.jpg";
import { useDispatch, useSelector } from "react-redux";
import { getAssignMpList } from "../../../store/action/assignMpList";
import { postIntiative } from "../../../store/action/createInitiative";
import InitiativeDetails from "../../SavaUpdate/AllInitiativeReports/initiativeDetails";
import Search from "@mui/icons-material/Search";
import ClearIcon from '@mui/icons-material/Clear';
import { searchMpList } from "../../../store/action/mpSearch";
import { getStateList } from "../../../store/action/stateList";
import { useNotificationContext } from "../../../utils/NotificationContext";
import { useLoading } from "../../../utils/LoadingContext";
import CancelIcon from '@mui/icons-material/Cancel';
import "./CreateInitiative.css";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
const AssignToMP = ({
  handleCloseAssingToMPDialog,
  openAssingToMPDialog,
  intiativeData,
  id,
  selectedMP,
  createNewClick,
  eventList
}) => {
  const { assignMpList } = useSelector((state) => state?.assignMpList);
  const { statedata } = useSelector((state) => state?.stateList?.data);
  const mpSearchList = useSelector((state) => state?.mpSearchList?.data);
  const [personName, setPersonName] = React.useState([]);
  const [stateName, setStateName] = React.useState([]);
  const [personId, setPersonId] = React.useState([]);
  const [stateId, setStateId] = React.useState([]);
  const [selectAll, setSelectAll] = React.useState(false);
  const [selectAllState, setSelectAllState] = useState(false);
  const [intiativeDetail, setIntiativeDetail] = useState(intiativeData);
  const [confirm, setConfirm] = useState(false);
  const [value, setValue] = useState("");
  const [stateValue, setStateValue] = useState("");
  const [state, setState] = useState("");
  const [diableAssignButton, setDisableAssignButton] = useState(true);
  const [clearIcon, setClearIcon] = useState(false);
  const [clearMPIcon, setClearMPIcon] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { setLoading } = useLoading();
  const { showNotification } = useNotificationContext();
  let stateList = statedata;
  const [rows, setRows] = useState(
    mpSearchList.length > 0 ? mpSearchList : assignMpList
  );
  const [stateRows, setStateRows] = useState(
    stateList?.length > 0 ? stateList : []
  );

  useEffect(() => {
    dispatch(getStateList());
  }, [])

  useEffect(() => {
    if (personName.length === 0) {
      setDisableAssignButton(true);
    }
    else {
      setDisableAssignButton(false);
    }
  }, [personName])
  useEffect(() => {
    if (rows.length > 0) {
      var newNames = personName.filter(function (o1) {
        return rows.some(function (o2) {
          return o1 === o2.user_name;
        });
      });
      var newIds = personId.filter(function (o1) {
        return rows.some(function (o2) {
          return o1 === o2.id;
        });
      });
      // setPersonName(newNames);
      // setPersonId(newIds);
    }
  }, [rows])

  useEffect(() => {
    dispatch(getStateList());
    dispatch(getAssignMpList(state));
    setPersonId([]);
    setPersonName([]);
    setSelectAll(false);
    setStateId([]);
    setStateName([]);
    setSelectAllState(false);
  }, [state]);


  useEffect(() => {
    if (stateName?.length === stateRows?.length) {
      setSelectAllState(true)
    }
    else {
      setSelectAllState(false)
    }
  }, [stateName])
  useEffect(() => {
    if (personName.length === rows.length && rows.length !== 0) {
      setSelectAll(true)
    }
    else {
      setSelectAll(false)
    }
  }, [personName, mpSearchList])
  useEffect(() => {
    if (id && selectedMP) {
      let rowId = [];
      let rowName = [];
      let stateName = [];
      let sName = [];
      let sId = [];

      selectedMP?.map((val) => {
        rowName.push(val.user_name);
        rowId.push(val.id);
        if (val.state_name && stateName?.indexOf(val.state_name) === -1) {
          stateName?.push(val.state_name)
          stateRows?.map((value) => {
            if (val.state_name === value.state_name) {
              sName.push(val.state_name);
              sId.push(value.id);
            }

          });
        }

      });
      setStateId(sId);
      setStateName(sName);
      setPersonId(rowId);
      setPersonName(rowName);
    }
  }, [stateRows]);

  useEffect(() => {
    setRows(assignMpList?.mpAssignData);
  }, [assignMpList]);

  useEffect(() => {
    setStateRows(stateList);
  }, [stateList]);

  useEffect(() => {
    dispatch(getAssignMpList(stateName.map(val => val)));
  }, [stateName])
  const handleDelete = (e, value) => {
    e.preventDefault();
    setStateName((current) => current.filter((name) => name !== value));
    const id = stateName.indexOf(value);
    setStateId((current) => current.filter((name, i) => i !== id));
  };

  const handleDeleteMP = (e, value) => {
    e.preventDefault();
    const id = personName.indexOf(value);
    setPersonName((current) => current.filter((name) => name !== value));
    setPersonId((current) => current.filter((name, i) => i !== id));
  };

  useEffect(() => {
    setRows(mpSearchList);
  }, [mpSearchList]);

  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const handleChange = (event) => {
    // const {
    //   target: { value },
    // } = event;
    setState(event.target.value);
    // if (value?.indexOf("select-all") > -1) {
    //   setSelectAll(!selectAll);
    //   setPersonName(selectAll ? [] : [...rows]);
    // } else {
    //   setPersonName(typeof value === "string" ? value.split(",") : value);
    //   setSelectAll(rows.every((r) => value.includes(r)));
    // }
  };
  const handleSearch = (value) => {
    if (value.length > 0) {
      let resArray = [];
      let searchList = mpSearchList?.length > 0 ? mpSearchList : assignMpList?.mpAssignData;
      for (let element of searchList) {
        if (element.user_name.toUpperCase().includes(value.toUpperCase()) || personName.includes(element.user_name)) {
          resArray.push(element);
        }
      }
      setRows(resArray);
    }
    else {
      setRows(assignMpList?.mpAssignData)
    }
  }

  const handleStateSearch = (value) => {
    if (value.length > 0) {
      let resArray = [];
      for (let element of stateList) {
        if (element.state_name.toUpperCase().includes(value.toUpperCase()) || stateName.includes(element.state_name)) {
          resArray.push(element);
        }
      }
      setStateRows(resArray);
    }
    else {
      setStateRows(stateList)
    }
  }

  const handlePost = async (event) => {
    try {
      setLoading(true);
      const response = await dispatch(postIntiative(intiativeDetail, id));

      if (response.status === 200 || response.status === 201) {
        navigate("/SevaInitiatives")
        showNotification("Success", response.data.message, "success");
      }
    } catch (error) {
      showNotification("Error", "Failed to post the data");
    } finally {
      setLoading(false);
    }
    setConfirm(false);
    handleCloseAssingToMPDialog();
  };

  // const handleSelectAll = () => {
  //   setSelectAll(!selectAll);
  //   setPersonName(selectAll ? [] : rows.map(row => row.name));
  // };

  return (
    <>
      <Dialog
        PaperProps={{ sx: { borderRadius: "15px", height: "550px" } }}
        fullScreen
        onClose={() => {
          setState("");
          handleCloseAssingToMPDialog();
        }}
        open={openAssingToMPDialog}
      >
        <DialogTitle
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2e739c",
            fontWeight: "700",
            textAlign: "center",
            fontSize: "26px",
          }}
        >
          Assign To MP
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleCloseAssingToMPDialog}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
            border: "1px solid #9e9e9e",
            borderRadius: "50%",
          }}
        >
          <CloseIcon />
        </IconButton>

        <div style={{ margin: "0 auto" }}>
          <Grid container>
            <FormControl sx={{ m: 1, width: 400 }} size="small" fullWidth>
              <b
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "16px",
                  display: "flex",
                  justifyContent: "flex-start",
                }}
              >
                Select State
              </b>
              <FormLabel id="demo-multiple-chip-label" className="label"></FormLabel>
              <Select
                labelId="demo-multiple-chip-label"
                id="demo-multiple-chip"
                multiple
                value={stateName}
                input={<OutlinedInput className={"textArea"} />}
                renderValue={(selected) => (
                  <div>
                    {selected?.map((value) => (
                      <Chip
                        key={value}
                        label={value}
                        clickable
                        deleteIcon={
                          <CancelIcon
                            onMouseDown={(event) => event.stopPropagation()}
                          />
                        }
                        onDelete={(e) => handleDelete(e, value)}
                      />
                    ))}
                  </div>
                )}
              >
                <div className="">
                  {clearIcon ? <ClearIcon position="start" sx={{ cursor: 'pointer' }} onClick={() => {
                    dispatch(getStateList())
                    setStateValue("")
                    setClearIcon(false)
                  }} /> : <Search position="start"></Search>}
                  <InputBase
                    onKeyDown={(e) => e.stopPropagation()}
                    onChange={(e) => {
                      setStateValue(e.target.value);
                      handleStateSearch(e.target.value)
                      if (e.target.value !== "") {
                        setClearIcon(true);
                      }
                      else {
                        setClearIcon(false);
                      }
                    }}
                    sx={{ width: "85%" }}
                    value={stateValue}
                    placeholder="Search State Name"
                  />
                </div>

                <div style={{ height: "200px", overflow: "auto" }}>
                  <MenuItem
                    key={"select-all"}
                    value={"select-all"}
                    sx={{ borderBottom: "1px solid #F5F5F5", margin: "0 10px" }}
                    onClick={() => {
                      let select = selectAllState;
                      let rowName = [];
                      let rowId = [];
                      if (select && stateId.length === stateRows?.length) {
                        setSelectAllState(false);
                        setStateId([]);
                        setStateName([]);
                      } else {
                        setSelectAllState(true);
                        stateRows?.map((val) => {
                          rowName.push(val.state_name);
                          rowId.push(val.id);
                        });
                        setStateId(rowId);
                        setStateName(rowName);
                      }
                    }}
                  >
                    <Checkbox
                      sx={{ padding: "2px", transform: "scale(.7)" }}
                      checked={selectAllState}
                    />
                    <ListItemText className="listItem" primary={"All"} />
                  </MenuItem>

                  {stateRows?.length > 0 &&
                    stateRows?.map((row) => (
                      <MenuItem
                        key={row.id}
                        value={row.state_name}
                        sx={{
                          borderBottom: "1px solid #F5F5F5",
                          margin: "0 10px",
                        }}
                        onClick={() => {
                          const newSelection = [...stateName];
                          const newSelectionId = [...stateId];
                          if (stateId.indexOf(row.id) > -1) {
                            newSelection.splice(
                              stateName.indexOf(row.state_name),
                              1
                            );
                            newSelectionId.splice(
                              stateId.indexOf(row.id),
                              1
                            );
                          } else {
                            newSelectionId.push(row.id);
                            newSelection.push(row.state_name);
                          }
                          setStateName(newSelection);
                          setStateId(newSelectionId);

                          setSelectAllState(
                            newSelectionId.length === rows.length &&
                            newSelectionId.length !== 0
                          );
                        }}
                      >
                        <Checkbox
                          sx={{ padding: "2px", transform: "scale(.7)" }}
                          checked={stateId.indexOf(row.id) > -1}
                        />
                        <List sx={{ padding: "0px" }}>
                          <ListItem sx={{ padding: "0px" }}>
                            <ListItemText
                              primary={row.state_name}
                              // className="listItem ecclipseonwidth"
                              className="listItem"
                            />
                          </ListItem>
                        </List>
                      </MenuItem>
                    ))}
                </div>
              </Select>
            </FormControl>
          </Grid>

          <Grid container>
            <FormControl sx={{ m: 1, width: 400 }} size="small" fullWidth>
              <b
                style={{
                  fontFamily: "HK Grotesk",
                  color: "#356F92",
                  fontSize: "16px",
                  display: "flex",
                  justifyContent: "flex-start",
                }}
              >
                Select MP
              </b>
              <FormLabel id="demo-select-small"></FormLabel>
              {/* <Button onClick={handleSelectAll}>Select All</Button> */}
              <Select
                labelId="demo-multiple-checkbox-label"
                id="demo-multiple-checkbox"
                multiple
                value={personName}
                // onChange={handleChange}
                input={<OutlinedInput className={"textArea"} />}
                renderValue={(selected) => (
                  <div >
                    {selected?.map((value) => (
                      <Chip
                        key={value}
                        label={value}
                        clickable
                        deleteIcon={
                          <CancelIcon
                            onMouseDown={(event) => event.stopPropagation()}
                          />
                        }
                        onDelete={(e) => handleDeleteMP(e, value)}
                      />
                    ))}
                  </div>
                )} MenuProps={{
                  getContentAnchorEl: null,
                }}
              >

                  {rows?.length ?
                  <div>
                  {clearMPIcon ? <ClearIcon onClick={() => {
                    dispatch(getAssignMpList(stateName.map(val => val)))
                    setValue("")
                    setClearMPIcon(false);
                  }} /> : <Search position="start"></Search>}
                  <InputBase
                    onKeyDown={(e) => e.stopPropagation()}
                    onChange={(e) => {
                      setValue(e.target.value);
                      handleSearch(e.target.value)
                      if (e.target.value !== "") {
                        setClearMPIcon(true);
                      }
                      else {
                        setClearMPIcon(false);
                      }
                      // dispatch(searchMpList(e.target.value));
                    }}
                    sx={{ width: "85%" }}
                    value={value}
                    placeholder="Search MP Name"
                  // inputProps={{ "aria-label": "search google maps" }}
                  />
                

                <div style={{ height: "200px", overflow: "auto" }}>
                  <MenuItem
                    key={"select-all"}
                    value={"select-all"}
                    sx={{ borderBottom: "1px solid #F5F5F5", margin: "0 10px" }}
                    onClick={() => {
                      let select = selectAll;
                      let rowName = [];
                      let rowId = [];
                      if (select && personId.length === rows?.length) {
                        setSelectAll(false);
                        setPersonId([]);
                        setPersonName([]);
                      } else {
                        setSelectAll(true);
                        rows?.map((val) => {
                          rowName.push(val.user_name);
                          rowId.push(val.id);
                        });
                        personId.map((val) => {
                          if (rowId.indexOf(val) === -1) {
                            rowId.push(val)
                          }
                        })
                        personName.map((val) => {
                          if (rowName.indexOf(val) === -1) {
                            rowName.push(val)
                          }
                        })
                        setPersonId(rowId);
                        setPersonName(rowName);
                      }
                    }}
                  >
                    <Checkbox
                      sx={{ padding: "2px", transform: "scale(.7)" }}
                      checked={selectAll}
                    />
                    <ListItemText className="listItem" primary={"All"} />
                  </MenuItem>

                  {rows?.length > 0 &&
                    rows?.map((row) => (
                      <MenuItem
                        key={row.id}
                        value={row.user_name}
                        sx={{
                          borderBottom: "1px solid #F5F5F5",
                          margin: "0 10px",
                        }}
                        onClick={() => {
                          const newSelection = [...personName];
                          const newSelectionId = [...personId];
                          if (personId.indexOf(row.id) > -1) {
                            newSelection.splice(
                              personName.indexOf(row.user_name),
                              1
                            );
                            newSelectionId.splice(
                              personId.indexOf(row.id),
                              1
                            );
                          } else {
                            newSelectionId.push(row.id);
                            newSelection.push(row.user_name);
                          }
                          setPersonName(newSelection);
                          setPersonId(newSelectionId);

                          setSelectAll(
                            newSelectionId.length === rows.length &&
                            newSelectionId.length !== 0
                          );
                        }}
                      >
                        <Checkbox
                          sx={{ padding: "2px", transform: "scale(.7)" }}
                          checked={personId.indexOf(row.id) > -1}
                        />
                        <List sx={{ padding: "0px" }}>
                          <ListItem sx={{ padding: "0px" }}>
                            <ListItemAvatar sx={{ minWidth: "30px" }}>
                              <Avatar sx={{ height: "25px", width: "25px" }}>
                                {row.user_avatar ? <img src={row.user_avatar}></img> :
                                  <AccountCircleIcon
                                    sx={{
                                      fontSize: "xx-large",
                                      width: "26px",
                                      height: "auto",
                                      border: 0
                                    }}
                                  />}
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText
                              primary={row.user_name}
                              secondary={row.house}
                              // className="listItem ecclipseonwidth"
                              className="listItem"
                            />
                          </ListItem>
                        </List>
                      </MenuItem>
                    ))}
                </div>
                </div> : <p>No mp found</p>}
              </Select>
            </FormControl>
          </Grid>
        </div>
        <React.Fragment>
          <Button
            disabled={diableAssignButton}
            variant="contained"
            sx={{
              p: 1,
              mr: 1,
              mt: 4,
              backgroundColor: "#ef7335",
              borderRadius: 4,
              position: "relative",
              alignSelf: "center",
              width: "300px",
              padding: "8px",
            }}
            className="button-primary-alt-contained"
            onClick={() => {
              let formData = intiativeData;
              Array.from(personId).forEach((row, i) =>
                formData?.append(`mplist[${i}]`, row)
              );
              setIntiativeDetail(formData);
              { createNewClick ? handlePost() : (eventList?.length > 0 ? setConfirm(true) : handlePost()) };
            }}
          // onClick={handleSubmit(onAddDevelopmentProject)}
          >
            CREATE AND ASSIGN INITIATIVE
          </Button>
        </React.Fragment>
      </Dialog>
      <Dialog
        open={confirm}
        PaperProps={{
          sx: {
            borderRadius: "15px",
            position: "fixed",
            minHeight: "250px",
            width: "450px",
          },
        }}
        onClose={() => setConfirm(false)}
      >
        <IconButton
          aria-label="close"
          onClick={() => setConfirm(false)}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
            border: "1px solid #9e9e9e",
            borderRadius: "50%",
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent
          sx={{
            padding: "55px 55px 0 55px",
            fontSize: "20px",
            textAlign: "center",
          }}
        >
          Multiple MPs have created events for this initiative. Are you sure you
          want to update this initiative?
        </DialogContent>
        <Button
          variant="contained"
          sx={{
            p: 1,
            mr: 1,
            width: "300px",
            alignSelf: "center",
            backgroundColor: "#ef7335",
            borderRadius: 4,
            position: "relative",
            margin: "15px 15px 35px 15px",
          }}
          className="button-primary-alt-contained"
          onClick={() => {
            // setIntiativeDetail({...intiativeDetail, mpList: });
            handlePost();
          }}
        >
          {" "}
          Confirm
        </Button>
      </Dialog>
    </>
  );
};

export default AssignToMP;
