
import axios from "axios"
import Constant from "../../utils/constant"
import { GET_STATE_FAILURE,GET_STATE_REQUEST,GET_STATE_SUCCESS} from "./types"

export const fetchStateListRequest = () => {
    return {
        type: GET_STATE_REQUEST
    }
}
export const fetchStateListSuccess = value => {
    return {
        type: GET_STATE_SUCCESS,
        payload: value
    }
}
export const fetchStateListFailure = error => {
    return {
        type: GET_STATE_FAILURE,
        payload: error
    }
}

export const getStateList = () => async (dispatch) => {
    const tkn = localStorage.getItem("tokenDetails");

    dispatch(fetchStateListRequest)
    await axios.get(Constant.BASE_URL + `/api/states/getall/0`,{
        headers: {
          Authorization: `Bearer ${tkn}`,
        },
      })
    .then(response => {
        const result = response.data
        dispatch(fetchStateListSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(fetchStateListFailure(errorMsg))
    })
}


