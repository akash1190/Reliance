import React, { useEffect, useState } from "react";
import leaderboard from "../../asserts/images/leaderboard-icon.png";
import profile from "../../asserts/images/Main Profile Picture@2x.png";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Button } from "@mui/material";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import leaderboard1 from "../../asserts/images/Ic_Leaderboard.svg";
import leaderboard2 from "../../asserts/images/Ic_Logout.svg";
import leaderboard3 from "../../asserts/images/Ic_Seva Updates.svg";
import leaderboard4 from "../../asserts/images/Ic_Your Initiatives.svg";
import leaderboard5 from "../../asserts/images/sevaini.svg";
import WarningMessageDialog from "../SevaInitiatives/WarningMessageDialog";
import profileicon from "../../asserts/images/profile.png";
import LogoutDialog from "../../utils/LogoutDialog";
const SideMenu = (props) => {
  const [active, setactive] = useState(props.active);
  const { profileData, createInitiative } = props;
  const mpProfileData = useSelector((state) => state?.mpProfileData?.data[0]);
  const [openWarningDialog, setOpenWarningDialog] = useState(false);
  const [openLogoutDialog, setOpenLogoutDialog] = useState(false);
  const [checkWarningClick, setCheckWarningClick] = useState(false);
  const [checkLogoutClick, setCheckLogoutClick] = useState(false);
  const [logoutClick, setLogoutClick] = useState(false);
  const userProfile = useSelector((state) => state?.userProfile?.data);
  const handleClickOpenWarningDialog = () => {
    setOpenWarningDialog(true);
  };

  const handleCloseWarningDialog = () => setOpenWarningDialog(false);

  const handleClickOpenLogoutDialog = () => {
    setOpenLogoutDialog(true);
  };

  const handleCloseLogoutDialog = () => setOpenLogoutDialog(false);

  const navigate = useNavigate();
  useEffect(() => {
    if (checkWarningClick) {
      if (active === "Leader") {
        props.user === "Admin" || props.user === "Leader"
          ? navigate("/AdminHome")
          : navigate("/MpHome");
      } else if (active == "SevaInitiative") {
        if (props.user === "Admin")
          navigate("/SevaInitiatives", {
            state: {
              user: props.user,
            },
          });
      } else if (active === "Seva") {
        if (props.user === "Admin") {
          props.user === "Admin" || props.user === "Leader"
            ? navigate("/SevaUpdates", { state: { user: props.user } })
            : navigate("/SevaUpdates");
        }
      }
      // else if (logoutClick && active === "logout") {
      //   localStorage.removeItem("userId");
      //   localStorage.removeItem("tokenDetails")
      //   localStorage.removeItem("mpId")
      //   navigate("/loginusers.html")
      //   window.location.reload();
      // }
    }
  }, [checkWarningClick]);

  useEffect(() => {
    if (checkLogoutClick) {
      localStorage.removeItem("userId");
      localStorage.removeItem("tokenDetails");
      localStorage.removeItem("mpId");
      navigate("/loginusers.html");
      window.location.reload();
    }
  }, [checkLogoutClick]);

  return (
    <div className="left-sidebar-b">
      <div className="d-flex d-flex-C" style={{ gap: "5px" }}>
        <div className="img-circle circularimage3">
          {props.user === "Admin" || props.user === "Leader" ? (
            <img
              src={profileicon}
              className="img-circle mr-1 profile-img"
              width="48"
              height="48"
            />
          ) : (
            <img
              src={
                profileData?.user_avatar
                  ? profileData?.user_avatar
                  : mpProfileData?.user_avatar
                  ? mpProfileData?.user_avatar
                  : profileicon
              }
              className="img-circle mr-1 profile-img"
              width="48"
              height="48"
              onError={(e) => {
                e.target.src = (
                  <AccountCircleIcon sx={{ fontSize: "xx-large" }} />
                );
              }}
            />
          )}
        </div>
        {props.user === "Admin" || props.user === "Leader" ? (
          <div className="align-self-center pr-2 sidebarLeaderName">
            {userProfile?.user_name}
            <br />
          </div>
        ) : (
          <>
            <div className="align-self-center pr-2 sidebarLeaderName d-text-align-c">
              {profileData ? profileData?.user_name : mpProfileData?.user_name}

              <span className="logininfo-ui">
                {profileData
                  ? profileData?.house
                    ? ","
                    : ""
                  : mpProfileData?.house
                  ? ","
                  : ""}{" "}
                {profileData
                  ? profileData?.designation
                    ? ","
                    : ""
                  : mpProfileData?.designation
                  ? ","
                  : ""}
              </span>
              <span className="logininfo-ui">
                {" "}
                {profileData
                  ? profileData?.constituency_name
                    ? profileData?.constituency_name + ","
                    : ""
                  : mpProfileData?.constituency_name
                  ? ","
                  : ""}
                <br/>
                {profileData
                  ? profileData?.state_name
                  : mpProfileData?.state_name}
              </span>
            </div>
          </>
        )}
      </div>

      <nav>
        <ul>
          <li className="justify-content-between">
            <Button
              className={active == "Leader" && "active"}
              onClick={() => {
                setactive("Leader");
                if (createInitiative) {
                  handleClickOpenWarningDialog(true);
                } else {
                  {
                    props.user === "Admin" || props.user === "Leader"
                      ? navigate("/AdminHome")
                      : navigate("/MpHome");
                  }
                }
              }}
            >
              <span>
                <img className="mr-3" src={leaderboard1} width="15" alt="" />
                Leaderboard
              </span>
            </Button>
            {/* <a href="" className="active" onClick={() => navigate('/MpHome')}><span><img className="mr-3" src={leaderboard} width="15" alt=""/>
                        Leaderboard</span></a> */}
          </li>
          {props.user === "Admin" && (
            <li className="justify-content-between">
              <Button
                className={active == "SevaInitiative" && "active"}
                onClick={() => {
                  setactive("SevaInitiative");
                  if (createInitiative) {
                    handleClickOpenWarningDialog(true);
                  } else {
                    navigate("/SevaInitiatives", {
                      state: {
                        user: props.user,
                      },
                    });
                  }
                }}
              >
                <span>
                  <img className="mr-3" src={leaderboard5} width="15" alt="" />
                  Seva Initiatives
                </span>
              </Button>
            </li>
          )}
          <li className="justify-content-between">
            <Button
              className={active == "Seva" && "active"}
              onClick={() => {
                setactive("Seva");
                if (createInitiative) {
                  handleClickOpenWarningDialog(true);
                } else {
                  props.user === "Admin" || props.user === "Leader"
                    ? navigate("/SevaUpdates", { state: { user: props.user } })
                    : navigate("/SevaUpdates");
                }
              }}
            >
              <span>
                <img className="mr-3" src={leaderboard3} width="15" alt="" />
                Seva Updates
              </span>
            </Button>
            {/* <a href=""><span><img className="mr-3" src={leaderboard} width="15" alt="" />
                        Save Updates</span></a> */}
          </li>
          {props.user !== "Admin" && props.user !== "Leader" && (
            <li className="justify-content-between">
              <Button
                className={active == "Initiatives" && "active"}
                onClick={() => {
                  setactive("Initiatives");
                  // if (createInitiative) {
                  //   handleClickOpenWarningDialog(true);
                  // }
                  // else {
                  navigate("/Initiatives")
                    ? navigate("/Initiatives")
                    : navigate(0);
                  // window.location.reload(false);
                  // }
                }}
              >
                <span>
                  <img className="mr-3" src={leaderboard4} width="15" alt="" />
                  Your Initiatives
                </span>
              </Button>
            </li>
          )}
          <li className="justify-content-between">
            <Button
              onClick={() => {
                setLogoutClick(true);
                setactive("logout");
                // if (createInitiative) {
                //   handleClickOpenWarningDialog(true);
                // } else {
                handleClickOpenLogoutDialog();
                // if (checkLogoutClick) {
                // localStorage.removeItem("userId");
                // localStorage.removeItem("tokenDetails")
                // localStorage.removeItem("mpId")
                // navigate("/loginusers.html")
                // window.location.reload();
                // }
                // }
              }}
            >
              <span>
                <img className="mr-3" src={leaderboard2} width="15" alt="" />
                Logout
              </span>
            </Button>
          </li>
        </ul>
      </nav>
      <WarningMessageDialog
        openWarningDialog={openWarningDialog}
        handleCloseWarningDialog={handleCloseWarningDialog}
        setCheckWarningClick={setCheckWarningClick}
      />
      <LogoutDialog
        openLogoutDialog={openLogoutDialog}
        handleCloseLogoutDialog={handleCloseLogoutDialog}
        setCheckLogoutClick={setCheckLogoutClick}
      />
    </div>
  );
};

export default SideMenu;
