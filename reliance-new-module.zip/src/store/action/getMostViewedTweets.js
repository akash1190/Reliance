import axios from "axios";
import Constant from "../../utils/constant";
import {
  FETCH_MOST_VIEWED_TWEETS_FAILURE,
  FETCH_MOST_VIEWED_TWEETS_REQUEST,
  FETCH_MOST_VIEWED_TWEETS_SUCCESS,
} from "./types";

export const fetchMostViewedTweetsRequest = () => {
  return {
    type: FETCH_MOST_VIEWED_TWEETS_REQUEST,
  };
};
export const fetchMostViewedTweetsSuccess = (value) => {
  return {
    type: FETCH_MOST_VIEWED_TWEETS_SUCCESS,
    payload: value,
  };
};
export const fetchMostViewedTweetsFailure = (error) => {
  return {
    type: FETCH_MOST_VIEWED_TWEETS_FAILURE,
    payload: error,
  };
};

export const getMostViewedTweets = () => async (dispatch) => {
  const tkn = localStorage.getItem("tokenDetails");
  dispatch(fetchMostViewedTweetsRequest);
  await axios
    .get(Constant.BASE_URL + "/api/mp/tweets/topMostViewedTweets", {
      headers: {
        Authorization: `Bearer ${tkn}`,
      },
    })
    .then((response) => {
      const result = response.data;
      dispatch(fetchMostViewedTweetsSuccess(result));
    })
    .catch((error) => {
      const errorMsg = error.message;
      dispatch(fetchMostViewedTweetsFailure(errorMsg));
    });
};
