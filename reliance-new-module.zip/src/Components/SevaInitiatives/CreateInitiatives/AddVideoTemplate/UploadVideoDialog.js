import React, { useEffect, useState } from 'react';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import CloseIcon from '@mui/icons-material/Close';
import { IconButton, Grid, Box, Button, DialogContent, Hidden } from '@mui/material';
import DialogActions from '@mui/material/DialogActions';
import closeIconp from "../../../../asserts/images/close-1.png";
import { useNotificationContext } from "../../../../utils/NotificationContext";
import AddIcon from "@mui/icons-material/Add";
import VideoPlayer from '../../../ReusableComponents.js/VideoPlayer';

const UploadVideos = ({ handleCloseUploadDialog, state, setValue, getValue, setVideosNew, initialVideos
    , setInputData, fileFormats, setCheckWarningPopup }) => {
    // const [videos, setVideos] = useState();
    const [videos, setVideos] = useState(initialVideos.length > 0 && initialVideos);
    const [files, setFiles] = useState([]);
    const [uploadMore, setUploadMore] = useState(false);
    const { showNotification } = useNotificationContext();

    const handleVideoChange = (e) => {
        const uploadedFiles = e.target.files;
        if (uploadedFiles.length > 0) {
            setCheckWarningPopup(true);
        }
        setFiles([...files, ...uploadedFiles]);
        let newVideos = [];
        for (let i = 0; i < uploadedFiles.length; i++) {
            const isRightFormat = fileFormats.includes(uploadedFiles[i].type);
            const reader = new FileReader();
            reader.readAsDataURL(uploadedFiles[i]);
            reader.onload = () => {
                newVideos.push({ url: reader.result, file: uploadedFiles[i] });
                if (i === uploadedFiles.length - 1) {
                    if (!isRightFormat) {
                        showNotification("Error", "You can only upload mp4 videos", "error");
                        return;
                    }
                    setVideos([...videos, ...newVideos]);
                    setVideosNew([...videos, ...newVideos]);
                    setUploadMore(true)
                }
            };
        }
    };
    const handleDelete = (index) => {
        setCheckWarningPopup(true);
        const tempImages = [...videos]
        tempImages.splice(index, 1)
        setVideos(tempImages)
    }

    const closeDialog = (event, reason) => {
        if (reason && reason == "backdropClick")
            return;
        // setVideos([])
        setVideos([])
        setInputData(prevState => {
            const newState = [...prevState]; // make a copy of the state array
            delete newState[`${state.for}`].videosData
            // newState[`${state.for}`] = { ...newState[`${state.for}`], imagesData: [] }; // update the i'th object's imagesData

            return newState;
        });
        setValue(`${state.for}.videos`, [])
        handleCloseUploadDialog()
    }

    useEffect(() => {
        setValue(`${state.for}.videos`, videos)
        setInputData(prevState => {
            const newState = [...prevState]; // make a copy of the state array
            newState[`${state.for}`] = { ...newState[`${state.for}`], videosData: videos }; // update the i'th object's imagesData

            return newState;
        });

    }, [videos])

    useEffect(() => {
        setVideos(initialVideos)
    }, [initialVideos])
    useEffect(() => {
        setInputData(prevState => {
            const newState = [...prevState]; // make a copy of the state array
            newState[`${state.for}`] = { ...newState[`${state.for}`], videosData: videos }; // update the i'th object's videosData
            return newState;
        });
        if (videos?.length === 0 && getValue(`${state.for}.videos`)?.length) {

            setValue(`${state.for}`, videos)
        }
    }, [getValue, videos, setValue, state])

    useEffect(() => {
        if (uploadMore) {
            // getValue(`${state.for}`) && setVideos(getValue(`${state.for}`))   
            setUploadMore(false)
        }

    }, [videos])




    return (
        <Dialog onClose={closeDialog} open={state.open} sx={{ borderRadius: "14px"}}
            disableEscapeKeyDown 
            PaperProps={{
                style: {
                  height:"500px",
                  maxHeight:"500px",
                  overflow:"hidden"
                },
              }}>
            <DialogTitle sx={{ fontFamily: 'HK Grotesk', color: "#2e739c", fontWeight: "700", textAlign: "center", fontSize: "26px" }}>Video Preview</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={closeDialog}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                }}
            >
                <CloseIcon />
            </IconButton>
            <DialogContent>
            
                    {/* <span style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "18px", fontWeight: 'bold', marginLeft: "15px", position: "relative", bottom: "10px" }}>Video Preview</span> */}
                 
                        <Box sx={{overflow:"auto"}}>
                            <div className="image-column-align"  ><>
                                {videos && videos.map((video, index) => (
                                      <>
                                    <div key={Date.now() + index}  style={{position:"relative"}}>
                                   

                                        <VideoPlayer
                                            width="200"
                                            height="150"
                                            className="object-video"
                                            // className={`fetchVideo${index}`}
                                            src={video.url ? video.url : video}
                                            controls
                                        />
                                              <img src={closeIconp}
                                            onClick={() => handleDelete(index)}
                                            className="imageclose-video"
                                       
                                        />
                                    </div>
                          
                                     
                                     
                                    </>

                                ))}
                               </>

                            </div>


                            {/* <Button onClick={handleClick} variant="contained" sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                        className="button-primary-alt-contained">Upload Videos</Button> */}
                            {/* Add More Videos */}
                            {/* </Paper> */}
                        </Box>

       
             
            </DialogContent>
            <DialogActions sx={{justifyContent:"start"}} >
      
                    <Button
                        variant="outlined"
                        className="button-tr-citizen-admin"
                        startIcon={<AddIcon sx={{ mt: "5px" }} />}
                        sx={{ml:0}}
                    >
                        <input type="file" multiple onChange={handleVideoChange} accept="video/mp4" style={Styles.input} />
                        Add More
                    </Button>
             
                {/* <Button variant="contained" className='button-tr-2 whtspavc' style={Styles.button}>
                    <input type="file" multiple onChange={handleVideoChange} accept="video/mp4" style={Styles.input} />
                    Upload More</Button> */}
<div style={{display:"flex",marginLeft:"100px"}}>
                    <Button
                        variant="contained"
                        className="button-tr-2"
                        autoFocus
                        onClick={handleCloseUploadDialog}
                        sx={{ backgroundColor: "#ef7335", }}
                    >
                        Save
                    </Button>
          
               
                    <Button
                        variant="outlined"
                        className="button-tr-citizen-cancel"
                        // className="button-tr-2"
                        type="submit"
                        onClick={closeDialog}
                    >
                        Cancel
                    </Button>
                    </div>
          
            </DialogActions>

        </Dialog >
    )
}

const Styles = {
    // button: {
    //     position: 'relative',
    //     overflow: 'hidden',
    //     width: 'fit-content'
    // },
    input: {
        position: 'absolute',
        opacity: '0',
        cursor: 'pointer'
    }
}

export default UploadVideos;